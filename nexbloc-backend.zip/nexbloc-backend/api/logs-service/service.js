import axios from "axios";
import { ProductDomainModel, DomainTransferModel } from "@api/model";
import { logsModel } from "./model.js";
import { updateDomainOwner } from "@api/domain-transfer-service/controller";

const xinfinPollingUrl = "https://xdc.blocksscan.io/api/txs/";

export const getAllLogs = async ({ status = "pending", eventType, userId }) => {
	try {
		if (!eventType) {
			throw new Error("eventType is undefined");
		}
		const queryObj = { transactionStatus: status, eventType: eventType };
		//if we get userId then add this in query
		if (userId) {
			queryObj.userId = userId;
		}
		const logs = await logsModel.find(queryObj);

		return logs;
	} catch (error) {
		return null;
	}
};

export const syncPublishDomainLogs = async (userId) => {
	const publishDomainLogs = await getAllLogs({
		eventType: "publish-domain",
		userId,
	});

	if (publishDomainLogs && publishDomainLogs.length > 0) {
		for (let log of publishDomainLogs) {
			const { _id, transactionHash, domainId, domainOwner } = log;

			const domain = await ProductDomainModel.findById(domainId).populate(
				[
					{
						path: "tld",
					},
				]
			);

			if (!domain) {
				continue;
			}

			let domainNetwork = domain.tld && domain.tld.network;

			if (domainNetwork === "xinfin") {
				const response = await axios.get(
					`${xinfinPollingUrl}${transactionHash}`
				);

				const transaction = response.data.to_model;

				if (transaction.status) {
					let updatedDomain = await ProductDomainModel.findOneAndUpdate(
						{ _id: domainId },
						{
							resolveType: "xdc_address",
							resolveString: transactionHash,
							domainOwner: domainOwner,
							deployedOnChain: true,
						}
					);

					const updatedLog = await logsModel.findByIdAndUpdate(
						_id,
						{ transactionStatus: "confirmed" },
						{ new: true }
					);
				} else {
					const updatedLog = await logsModel.findByIdAndUpdate(
						_id,
						{ transactionStatus: "failed" },
						{ new: true }
					);
				}
			}
		}
		return true;
	}
	return false;
};

export const syncTransferDomainLogs = async (userId) => {
	const transferDomainLogs = await getAllLogs({
		eventType: "transfer-domain",
		userId,
	});

	if (transferDomainLogs && transferDomainLogs.length > 0) {
		for (let log of transferDomainLogs) {
			const { _id, transactionHash, domainId, requestId } = log;

			const domain = await ProductDomainModel.findById(domainId).populate(
				[
					{
						path: "tld",
					},
				]
			);

			if (!domain) {
				continue;
			}

			let domainNetwork = domain.tld && domain.tld.network;

			if (domainNetwork === "xinfin") {
				const response = await axios.get(
					`${xinfinPollingUrl}${transactionHash}`
				);

				const transaction = response.data.to_model;

				if (transaction.status) {
					if (!requestId) {
						continue;
					}

					await updateDomainOwner(requestId);

					await DomainTransferModel.findByIdAndUpdate(requestId, {
						status: "completed",
					});

					const updatedLog = await logsModel.findByIdAndUpdate(
						_id,
						{ transactionStatus: "confirmed" },
						{ new: true }
					);
				} else {
					const updatedLog = await logsModel.findByIdAndUpdate(
						_id,
						{ transactionStatus: "failed" },
						{ new: true }
					);
				}
			}
		}
		return true;
	}
	return false;
};
