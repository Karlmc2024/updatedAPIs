const joi = require("@hapi/joi");

export const validateLog = (req, res, next) => {
	const schema = joi.object({
		domainId: joi.string().required(),
		domainOwner: joi.string().required(),
		transactionHash: joi.string().required(),
		transactionStatus: joi
			.string()
			.valid("pending", "confirmed", "failed")
			.optional(),
		eventType: joi.string().valid("publish-domain", "transfer-domain"),
		requestId: joi.string().optional(),
	});
	const { error } = schema.validate(req.body);
	if (error) {
		return res.status(400).json({ message: error.message });
	} else {
		next();
	}
};
