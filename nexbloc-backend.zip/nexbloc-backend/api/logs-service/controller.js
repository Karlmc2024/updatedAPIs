import errorHandler from "@lib/utils/error";
import { ProductDomainModel } from "@api/model";
import { logsModel } from "./model";
import { syncPublishDomainLogs, syncTransferDomainLogs } from "./service";
//todo add validator. The Request body must be validated before hitting the controller

// todo use result as response key. Not Data
export const createLog = async (req, res) => {
	try {
		const body = { ...req.body };
		body.userId = req.me._id;
		//creating logs
		const log = await logsModel.create(body);
		//updating logid in model
		const updateDomain = await ProductDomainModel.findByIdAndUpdate(
			body.domainId,
			{ logId: log._id }
		);
		return res.status(200).json({ result: log });
	} catch (error) {
		//todo use middleware error handler
		return errorHandler(error, 400, res);
	}
};

// todo add validator. The Request body must be validated before hitting the controller

export const updateLog = async (req, res, next) => {
	try {
		const logId = req.params.id;
		if (!logId) {
			const error = new Error("Please provide log id");
			return errorHandler(error, 400, res);
		}
		const updatedLog = await logsModel.findByIdAndUpdate(
			logId,
			{ ...req.body },
			{ new: true }
		);
		if (!updateLog) {
			const error = new Error("log update failed or no such log exist");
			return errorHandler(error, 400, res);
		}
		return res.status(200).json({ result: updatedLog });
	} catch (error) {
		return errorHandler(error, 400, res);
	}
};

export const syncPendingLogsForXDC = async (req, res) => {
	try {
		let { eventType } = req.body;
		let isSyncSuccess = false;
		if (eventType === "publish-domain") {
			isSyncSuccess = await syncPublishDomainLogs(req.me._id);
		} else if (eventType === "transfer-domain") {
			isSyncSuccess = await syncTransferDomainLogs(req.me._id);
		}

		if (isSyncSuccess) {
			return res
				.status(200)
				.json({ success: true, message: "Sync Successful" });
		}
		return res.status(200).json({ success: false, message: "Sync failed" });
	} catch (error) {
		return errorHandler(error, 400, res);
	}
};
