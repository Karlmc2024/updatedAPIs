"use strict";
import mongoose from "mongoose";
const objectId = mongoose.Schema.Types.ObjectId;

const logSchema = new mongoose.Schema({
	userId: { type: objectId, ref: "User" },
	domainId: { type: objectId, ref: "ProductDomain" },
	domainOwner: { type: String, default: "" },
	transactionHash: { type: String, required: true },
	transactionStatus: {
		type: String,
		enum: ["pending", "confirmed", "failed"],
		default: "pending",
	},
	eventType: {
		type: String,
		enum: ["publish-domain", "transfer-domain"],
		required: true,
	},
	requestId: {
		type: objectId,
		ref: "DomainTransfer",
		default: null,
	},
});
export const logsModel = mongoose.model("Log", logSchema);
