const router = require('express').Router();
import { validateLog } from "./validator";
import {createLog, updateLog,syncPendingLogsForXDC} from "./controller"

router.post('/',validateLog,createLog)
router.put('/sync',syncPendingLogsForXDC);
router.put('/:id',updateLog)


export default router;
