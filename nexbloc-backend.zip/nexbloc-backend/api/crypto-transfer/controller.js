import { CryptoTransferHistoryModel } from "./model";
import errorHandler from "@lib/utils/error";

export const addTransactionHistory = async (req, res) => {
  try {
    const newTransaction = new CryptoTransferHistoryModel({
      userId: req.locals.user._id,
      ...req.body,
    });
    let status = await newTransaction.save();
    return res.status(200).json({ result: status._id });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

export const updateTransactionStatus = async (req, res) => {
  try {
    let transactions = await CryptoTransferHistoryModel.findByIdAndUpdate(
      req.params.id,
      req.body
    );
    return res.status(200).json({ result: transactions });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

export const getTransactionHistory = async (req, res) => {
  try {
    const { skip, limit, ...rest } = req.query;
    let transactions = await CryptoTransferHistoryModel.find({
      userId: req.locals.user._id,
      ...rest,
    })
      .sort({ _id: -1 })
      .skip(skip)
      .limit(limit);
    const totalCount = await CryptoTransferHistoryModel.count({
      userId: req.locals.user._id,
      ...rest,
    });
    return res.status(200).json({ result: transactions, count: totalCount });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};
