"use strict";
import mongoose from "mongoose";
const objectId = mongoose.Schema.Types.ObjectId;

const cryptoTransferHistorySchema = new mongoose.Schema(
  {
    userId: { type: objectId, ref: "User" },
    fromAccount: { type: String },
    toDomain: { type: String },
    toAccount: { type: String },
    asset: { type: String },
    amount: { type: String },
    txHash: { type: String },
    status: { type: String },
    statusMessage: { type: String },
  },
  { timestamps: true, versionKey: false }
);

export const CryptoTransferHistoryModel = mongoose.model(
  "cryptoTransferHistory",
  cryptoTransferHistorySchema
);
