const router = require("express").Router();
import {
  addTransactionHistory,
  updateTransactionStatus,
  getTransactionHistory,
} from "./controller";

router.get("/", getTransactionHistory);
router.patch("/:id", updateTransactionStatus);
router.post("/add", addTransactionHistory);

export default router;
