import {TradeMarkModel} from './model';

export const getAllTradeMarks = async () => {
  return TradeMarkModel.find({});
};


export const getTradeMarkByName = async (domainName) => {

};






