import { TradeMarkModel, trademarkRequestModel } from "./model";
import errorHandler from "@lib/utils/error";
import { TldModel } from "@api/model";
import {
  createTradeMarkTicket,
  updateTradeMarkTicket,
} from "@lib/utils/hubspot";
import { sendEjsEmail } from "../../lib/utils/email";
const path = require("path");
const ejs = require("ejs");
const fs = require("fs");

const submitCreationMail = (userEmail, userName, domainName, siteLink) => {
  const Subject = "New Trademark Request Created";

  let filePathClient = path.resolve(
    __dirname + "../../../lib/mailer/template/client_proposal.ejs"
  );
  const compiledClient = ejs.compile(fs.readFileSync(filePathClient, "utf8"));
  const dataToCompileClient = {
    user: userName,
    message: `Your Trademark Request for ${domainName}, has been Submitted successfully! Please wait for approval.`,
    siteLink,
  };

  let filePathSupport = path.resolve(
    __dirname + "../../../lib/mailer/template/support_proposal.ejs"
  );
  const compiledSupport = ejs.compile(fs.readFileSync(filePathSupport, "utf8"));
  const dataToCompileSupport = {
    message: `Thier is new trademark request for ${domainName}`,
  };

  sendEjsEmail(
    process.env.EMAIL,
    "",
    Subject,
    compiledSupport(dataToCompileSupport)
  );

  sendEjsEmail(userEmail, "", Subject, compiledClient(dataToCompileClient));
};

const submitApproveMail = (userEmail, userName, domainName, siteLink) => {
  const Subject = "New Trademark Request Approved";

  let filePathClient = path.resolve(
    __dirname + "../../../lib/mailer/template/client_proposal.ejs"
  );
  const compiledClient = ejs.compile(fs.readFileSync(filePathClient, "utf8"));
  const dataToCompileClient = {
    user: userName,
    message: `Your Trademark Request for ${domainName}, has been Approved, Please proceed to buy`,
    siteLink,
  };

  sendEjsEmail(userEmail, "", Subject, compiledClient(dataToCompileClient));
};

const submitPurchaseMail = (userEmail, userName, domainName, siteLink) => {
  const Subject = "New Trademark Request Created";

  let filePathClient = path.resolve(
    __dirname + "../../../lib/mailer/template/client_proposal.ejs"
  );
  const compiledClient = ejs.compile(fs.readFileSync(filePathClient, "utf8"));
  const dataToCompileClient = {
    user: userName,
    message: `Your Trademark Domain ${domainName}, has been purchased successfully!`,
    siteLink,
  };

  let filePathSupport = path.resolve(
    __dirname + "../../../lib/mailer/template/support_proposal.ejs"
  );
  const compiledSupport = ejs.compile(fs.readFileSync(filePathSupport, "utf8"));
  const dataToCompileSupport = {
    message: `Trademark domain ${domainName}, has been purchased successfully!`,
  };

  sendEjsEmail(
    process.env.EMAIL,
    "",
    Subject,
    compiledSupport(dataToCompileSupport)
  );

  sendEjsEmail(userEmail, "", Subject, compiledClient(dataToCompileClient));
};

export const trademarks = async (req, res) => {
  try {
    let trade_marks = await TradeMarkModel.find({});
    return res.status(200).json({ result: trade_marks });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

export const trademarkRequest = async (req, res) => {
  try {
    let trade_marks = await TradeMarkModel.find({});
    return res.status(200).json({ result: trade_marks });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};
export const createTradeMarkRequest = async (req, res) => {
  try {
    const [tradeMarkName, tldName] = req.body.domainName.split(".");
    let tld = await TldModel.findOne({ tldName: `.${tldName}` });
    let trademark = await TradeMarkModel.findOne({
      tradeMarkName: new RegExp("^" + tradeMarkName + "$", "i"),
    });
    if (!trademark) {
      const error = new Error("TradeMark is not valid");
      return errorHandler(error, 400, res);
    }
    const tmReqExistByUser = await trademarkRequestModel.findOne({
      domainName: new RegExp("^" + req.body.domainName + "$", "i"),
      userId: req.me._id,
    });
    if (tmReqExistByUser) {
      const error = new Error("TradeMark request already exist");
      return errorHandler(error, 400, res);
    }
    const tradeMarkObj = {
      ...req.body,
      userId: req.me._id,
      trademark: trademark._id,
      tld: `.${tldName}`,
    };
    // const hubspotTicket = await createTradeMarkTicket(tradeMarkObj)
    // if (hubspotTicket) {
    //     tradeMarkObj.hubspotTicketId = hubspotTicket.objectId
    // }

    const newTradeMark = await trademarkRequestModel.create(tradeMarkObj);
    submitCreationMail(
      req.me.email,
      req.me.firstName + " " + req.me.lastName,
      req.body.domainName,
      process.env.DOMAIN
    );
    return res.status(201).json({ result: newTradeMark });
  } catch (error) {
    console.log(error);
    return errorHandler(error, 400, res);
  }
};
//this function gives list of trademarkrequest of one user
export const getTradeMarkRequestByUser = async (req, res) => {
  try {
    const tradeMark = await trademarkRequestModel.find({
      userId: req.params.id,
    });
    return res.status(200).json({ result: tradeMark });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};
//this function will provide detail about single trademark request
export const getSingleTradeMarkRequest = async (req, res) => {
  try {
    const tradeMark = await trademarkRequestModel.findOne({
      _id: req.params.id,
    });
    if (!tradeMark) {
      const err = new Error("tradeMark does not exist");
      return errorHandler(err, 400, res);
    }
    return res.status(200).json({ result: tradeMark });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};
export const updateTradeMarkRequest = async (req, res) => {
  try {
    const tradeMarkRequest = await trademarkRequestModel.findById(
      req.params.id
    );
    //--------check if domain Name is also got updated----
    //if domain name not updated just update the detail as it is
    if (tradeMarkRequest.domainName === req.body.domainName) {
      const updatedTradeMark = await trademarkRequestModel.findByIdAndUpdate(
        req.params.id,
        req.body,
        { new: true, useFindAndModify: false }
      );
      // const updateHubspot = await updateTradeMarkTicket(tradeMarkRequest.hubspotTicketId, updatedTradeMark)
      return res.status(200).json({ result: updatedTradeMark });
    }
    //if the domainName got updated Again check if the tradeMark is valid or not
    const [tradeMarkName, tldName] = req.body.domainName.split(".");
    let trademark = await TradeMarkModel.findOne({
      tradeMarkName: new RegExp("^" + tradeMarkName + "$", "i"),
    });

    if (!trademark) {
      const error = new Error("TradeMark is not valid");
      return errorHandler(error, 400, res);
    }
    const tradeMarkObj = {
      ...req.body,
      trademark: trademark._id,
      tld: `.${tldName}`,
    };
    const updatedTradeMark = await trademarkRequestModel.findByIdAndUpdate(
      req.params.id,
      tradeMarkObj,
      { new: true, useFindAndModify: false }
    );
    submitApproveMail(
      req.me.email,
      req.me.firstName + " " + req.me.lastName,
      req.body.domainName,
      process.env.DOMAIN
    );
    // const updateHubspot = await updateTradeMarkTicket(tradeMarkRequest.hubspotTicketId, updatedTradeMark)
    return res.status(200).json({ result: updatedTradeMark });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};
export const deleteSingleTradeMark = async (req, res) => {
  try {
    const deletedTradeMark = await trademarkRequestModel.findByIdAndDelete(
      req.params.id
    );
    if (!deletedTradeMark) {
      const err = new Error("tradeMark does not exist");
      return errorHandler(err, 400, res);
    }
    return res
      .status(200)
      .json({ result: null, message: "data deleted successfully" });
  } catch (error) {
    return errorHandler(error, 500, res);
  }
};
