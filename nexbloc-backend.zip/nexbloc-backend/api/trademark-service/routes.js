
const router = require('express').Router();
import {trademarks,createTradeMarkRequest,getTradeMarkRequestByUser,getSingleTradeMarkRequest,deleteSingleTradeMark, updateTradeMarkRequest} from './controller';
import {addTMReqValidator} from './validator';
router.get('/',trademarks);
router.post('/request',addTMReqValidator,createTradeMarkRequest);
router.route('/request/:id').get(getSingleTradeMarkRequest).put(addTMReqValidator,updateTradeMarkRequest).delete(deleteSingleTradeMark);
router.route('/request/user/:id').get(getTradeMarkRequestByUser);
export default router;
