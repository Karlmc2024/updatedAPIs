const Joi = require('@hapi/joi');

export const addTMReqValidator = (req, res, next) => {
    const schema = Joi.object({
        name: Joi.string().required(),
        email: Joi.string().required(),
        designation: Joi.string().optional().allow(null,''),
        phoneNumber: Joi.string().optional().allow(null,''),
        message: Joi.string().required().allow(null,''),
        domainName: Joi.string().required(),
        company: Joi.string().optional().allow(null,''),
        status: Joi.string().optional().allow(null,''),
        hubspotTicketId:Joi.string().optional().allow(null,'')
    });

    const {error} = schema.validate(req.body);

    if (error) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        logger.error('error', message);
        return res.status(400).json({error:{message:message}});
    }

    next();
};

