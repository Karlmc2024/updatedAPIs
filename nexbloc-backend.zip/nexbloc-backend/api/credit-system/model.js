'use strict';
import mongoose from 'mongoose';
const objectId = mongoose.Schema.Types.ObjectId;
const AutoIncrement = require('mongoose-sequence')(mongoose);

const creditUsesSchema = new mongoose.Schema({
    initialCredit: {type: Number,required: true,default:0},
    remainingCredit: {type: Number,required: true,default:0},
    usedCredit: {type: Number,required: true,default:0},
    orderId  : {type:String,required:false,},
},{timestamps: true, versionKey: false});

const transactionHistorySchema = new mongoose.Schema({
    purchasedCredit: {type: Number,required: true,default:0},
    allocatedTokens: {type: Number,required: true,default:0},
    transactionId  : {type:objectId,required:false},
    transactionHash: {type:String,required:false},
    influencer      : {type:String,required:false,default:'none'},
    status:  {
        type: String,
        default: 'initiated',
        enum: [
          'initiated',
          'paymentStarted',
          'paymentDone',
          'paymentFailed', 'custom'
        ]
      }
},{timestamps: true, versionKey: false});

const creditSchema = new mongoose.Schema({
    amount: {type: Number,required: true,default:0},
    userId: {type:objectId,required:true,ref:'User'},
    nexbTokens: {type: Number,required: true,default:0},
    tokenOwner: {type: String,required: false,default:null},
    creditUsesHistory: [creditUsesSchema],
    transactionHistory: [transactionHistorySchema]
},{timestamps: true, versionKey: false});

const influencerSchema = new mongoose.Schema({
    name: {type: String,required: false,default:null},
    code: {type: Number,required: false,default:null}
});

influencerSchema.plugin(AutoIncrement, {inc_field: 'code'});

export const CreditModel = mongoose.model('credits', creditSchema);

export const influencerModel = mongoose.model('influencer', influencerSchema);
