const Joi = require('@hapi/joi');

export const addCredit = (req, res, next) => {
    const schema = Joi.object({
        amount: Joi.number().greater(0).required(),
        paymentGateway: Joi.string().required(),
        influencer: Joi.string().optional(),
        tokenOwner: Joi.number().greater(0).optional()
    });

    const {error} = schema.validate(req.body);

    if (error) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        logger.error('error', message);
        return res.status(400).json({error:{message:message}});
    }

    next();
};

export const tokens = (req, res, next) => {
    const schema = Joi.object({
        amount: Joi.number().greater(0).required(),
    });

    const {error} = schema.validate(req.body);

    if (error) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        // eslint-disable-next-line no-undef
        logger.error('error', message);
        return res.status(400).json({error:{message:message}});
    }
    next();
};
