'use strict';

/********************************* DB MODELS   ********************************/
const {ReferModel} = require('./model');
const {UserModel} = require('../user-service/model');

/***********************************  PACKAGES AND LIBRARIES  *******************/

const {getTime} = require('../helpers/index');
const {sendMail} = require('../../lib/mailer/index');
const {SuccessHandler} = require('../handler/success');
const {ErrorHandler} = require('../handler/error');
const bcryptjs = require('bcrypt');
/****************************  Refer User  *******************/
const ReferUser = async (req, res) => {
    try {

        // check whether already refered
        const {email} = req.body;

        const isemailused = await UserModel.findOne({email: email});

        if (isemailused) {
            
            return ErrorHandler({message: 'Email Already in use. '}, res);
        } else {
            const isalreadyrefered = await ReferModel.findOne({email: email, referBy: req.me.referId, belongto: req.me._id});
            let link = `${process.env.URL}/signup/${req.me.referId}`;
            if (isalreadyrefered != null) {
                // only send mail does not make records 
                await sendMail(email, "Let's connect nexBlock", 'refer.ejs', {sendername: req.me.firstName, link: link});
                return SuccessHandler(null, 'Refer Successfull . ', res);
            }
            const newRecord = await ReferModel.create({email: email, referBy: req.me.referId, belongto: req.me._id});
            await sendMail(email, "Let's connect nexBlock", 'refer.ejs', {sendername: req.me.firstName, link: link});
            return SuccessHandler(null, 'Refer done successfully . ', res);
        }
    } catch (error) {
        
        return ErrorHandler(error, res);
    }
};

/***********************************  GET  REFER DETAILS  ***************************/
const getReferDetail = async (req, res) => {
    try {
        const {_id} = req.params;
        const referdetail = await ReferModel.findOne({_id: _id});
        if (referdetail) {
            return SuccessHandler(referdetail, '', res);
        } else {
            return ErrorHandler({message: 'Invalid  Refer Id. '}, res);
        }
    } catch (error) {
        return ErrorHandler(error, res);
    }
};
/************************************** GET ALL REFERS  ***********************/
const getAllRefer = async (req, res) => {
    try {
        const allrefers = await ReferModel.find({belongto: req.me._id});
        return SuccessHandler(allrefers, 'All refers', res);
    } catch (error) {
        return ErrorHandler(error, res);
    }
};


/************************************ GET REFER SERVICE TOKENSE    *********************************/
const getSuccessRefers = async (req, res) => {
    try {
        const allSuccessRefers = await ReferModel.find({belongto: req.me._id, isaccepted: true});
        
        return SuccessHandler(allSuccessRefers, 'Fetch Success refers done . ', res);
    } catch (error) {
        return ErrorHandler(error, res);
    }
};

/******************************************** GET FAILT REFERS  ******************************/
const getFailRefers = async (req, res) => {
    try {
        const allfailRefers = await ReferModel.find({belongto: req.me._id, isaccepted: false});
        return SuccessHandler(allfailRefers, 'Fetch fail refers done. ', res);
    } catch (error) {
        return ErrorHandler(error, res);
    }

};

/*************************************  GET FAIL REFERS  **********************/
const getCountFailRefers = async (req, res) => {
    try {
        const count = await ReferModel.find({belongto: req.me._id, isaccepted: false}).count();
        return SuccessHandler(count, 'Fetch fail count is done. ', res);
    } catch (error) {
        return ErrorHandler(error, res);

    }
};
/*************************************  GET COUNT SUCCESS REFERS  ***************/
const getCountSuccessRefers = async (req, res) => {
    try {
        const count = await ReferModel.find({belongto: req.me._id, isaccepted: true}).count();
        return SuccessHandler(count, 'Fetch success count  done. ', res);
    } catch (error) {
        return ErrorHandler(error, res);
    }
};


/********************************************* GET REFER CODE *******************************/
const generateRefercode = async (firstName) => {
    try {
        const time = Math.abs(new Date().getTime());
        return firstName + time;
    } catch (error) {
        return ErrorHandler(error, res);
    }
};

const handelReferUser = async (body) => {
    try {
        /*********************if user joining by reference  ********/
        /************************** validate that referId is valide or not *********/
        if (body.referBy) {
            const isvaliderefer = await ReferModel.findOne({email: body.email, isaccepted: false, referBy: body.referBy});
            /******************** is not valide refer check referBy is valide or not  *****************/
            if (isvaliderefer == null) {
                const isvalidereferBy = await UserModel.findOne({referId: body.referBy});
                if (isvalidereferBy == null) {
                    return {error : {message : 'Invalid refer id'}};
                } else {
                    await ReferModel.create({email : body.email , isaccepted: true,  status: 'Accepted' , referBy : body.referBy, belongto: null});
             
                    return {error: null};
                }
            } else {
                /******* valide reference  ************/
                await ReferModel.findOneAndUpdate({email : body.email , referBy: body.referBy}, {isaccepted: true, status: 'Accepted'});
                return {error :null};
            }
        } else {
            return {error: null};
        }

    } catch (error) {
        return {error :{message :error.message}};

    }
};
module.exports = {getAllRefer, getFailRefers, getSuccessRefers, getCountFailRefers, getCountSuccessRefers, ReferUser, getReferDetail, generateRefercode , handelReferUser};
