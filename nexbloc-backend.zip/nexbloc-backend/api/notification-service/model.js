'use strict';
import mongoose from 'mongoose';
import uniqueValidator from 'mongoose-unique-validator';
const objectId = mongoose.Schema.Types.ObjectId;

const NotificationSchema = new mongoose.Schema({
  userId                : {type: objectId, ref: 'User'},
  type                  : {type: String, required: true},
  isRead                : {type: Boolean, required: true, default: false},
  metadata              : {}

}, {timestamps: true, versionKey: false});

NotificationSchema.plugin(uniqueValidator, {message: 'Duplicate Entry {PATH}'});

export const NotificationModel = mongoose.model('Notification', NotificationSchema);


//PUSH notification for Web
//It will be followed by Text message
