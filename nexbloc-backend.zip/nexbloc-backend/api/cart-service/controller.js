import {CartModel} from './model';
import {ProductDomainModel} from '../domain-service/model';
import errorHandler from '@lib/utils/error';
import {addToWishlist} from '../wishlist-service/service';
import {addCartPriceAndQuantity} from './services';
import {OrderModel} from '../order-service/model';
import { UserModel } from '../user-service/model';
import sendCartReminder from '../../lib/utils/cartCheckout';
import { LockedDomainModel } from '../order-service/model';
import {resetScheduleCartMailer, cancelScheduleCartMailer} from '@lib/utils/scheduler';


function processCart (items) {
    let obj = {items:[]};
    if (items && items.length){
        items.map(({domainName,price, tld})=>{
            obj.items.push({domainName,price, tld});
       });
       obj.totalQuantity = items.length;
       obj.totalCost =  items.reduce( function(a, b){
           return a + b['price'];
       }, 0);
    }
    return obj;
}

export const getMyCart = async(req,res)=>{
    try {
        let cart =  await CartModel.findOne({userId:req.locals.user._id});
        return res.status(200).json({result:cart});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};

// remove all items
export const clearCart = async(req,res)=>{
    try {
        let cart =  await CartModel.findByIdAndUpdate({userId:req.locals.user._id},{items:[]});
        await cancelScheduleCartMailer(req.me._id)
        return res.status(200).json({result:cart});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};


// add items or remove one item
export const updateCart = async(req,res)=>{
    try {
        let {body} = req;

        // let userDomains = await ProductDomainModel.find({
        //     userId: req.me._id,
        // },{});
        //
        // if (userDomains.length >= process.env.orderLimit) {
        //     res.status(400).json({
        //         error: {
        //         message: 'Exceeded Domain Purchase Limit',
        //         },
        //     });
        // }
        
        let cart =  await CartModel.findOne({userId:req.locals.user._id});
        let obj  = processCart(body);
        let data =  await CartModel.findByIdAndUpdate({_id:cart._id},obj,{new:true});
        if(cart.items.length > 0) {
            await resetScheduleCartMailer(req.me._id)
        } else if(cart.items.length === 0) {
            await cancelScheduleCartMailer(req.me._id)
        }
        return res.status(201).json({result:data});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};


export const deleteCartItem = async(req,res)=>{
    try {
        let {itemId} = req.params;
        let cart =  await CartModel.findOne({userId:req.locals.user._id});
        let index = cart.items.findIndex(item=>item._id.toString() === itemId);
        if (index > -1){
            cart.items.splice(index,1);
            cart.totalQuantity = cart.items.length;
            cart.totalCost =  cart.items.reduce( function(a, b){
                return a + b['price'];
            }, 0);
            let data =  await CartModel.findByIdAndUpdate({_id:cart._id},cart, {new:true});
            if (cart.currentOrderId) {
                await OrderModel.findOneAndUpdate(
                  {_id: cart.currentOrderId},
                  {
                    $set: {
                      cart: {
                        totalQty: cart.items.length,
                        totalCost: cart.items.reduce(
                          (partial_sum, {price}) => partial_sum + Number(price),
                          0
                        ),
                        items: cart.items,
                      },
                      finalAmount: cart.items.reduce(
                        (partial_sum, {price}) => partial_sum + Number(price),
                        0
                      ),
                    },
                  }
                );

                const lockedDomains = cart.items.map(item => ({
                    userId: req.me._id,
                    orderId: cart.currentOrderId,
                    domainName: item.domainName,
                    expireAt: new Date(new Date().getTime() + 30*60000)
                }));
                await LockedDomainModel.deleteMany({orderId: cart.currentOrderId})
                await LockedDomainModel.insertMany(lockedDomains);
              }
              if(cart.items.length > 0) {
                await resetScheduleCartMailer(req.me._id)
              } else if(cart.items.length === 0) {
                await cancelScheduleCartMailer(req.me._id)
              }
            return res.status(200).json({result:data});
        }
        return res.status(200).json({result:cart});

    } catch (error) {
        return errorHandler (error,400,res);
    }
};

export const addItemToCart = async(req,res)=>{
    try {
        let {body} = req;
        let {domainName} = body;

        // let userDomains = await ProductDomainModel.find({
        //     userId: req.me._id,
        // },{});


        let cart =  await CartModel.findOne({userId:req.locals.user._id});

        let index = cart.items.findIndex(item=>item.domainName.toString() === domainName);
        if (index === -1){
            cart.items.push(body);
            cart.totalQuantity = cart.items.length;
            cart.totalCost =  cart.items.reduce( function(a, b){
                return a + b['price'];
            }, 0);
            let data =  await CartModel.findByIdAndUpdate({_id:cart._id},cart, {new:true});
            if(cart.items.length > 0) {
                await resetScheduleCartMailer(req.me._id)
            }
            return res.status(201).json({result:data});
        }
        return res.status(200).json({result:cart});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};

export const moveToWishlist = async(req,res)=>{
    try {
        let {itemId} = req.params;
        let userId = req.locals.user._id;
        let cart =  await CartModel.findOne({userId});
        let index = cart.items.findIndex(item=>item._id.toString() === itemId);
        if (index > -1){
            const newWishlist = await addToWishlist({userId,domain:cart.items[index]});
            cart.items.splice(index,1);
            cart = addCartPriceAndQuantity(cart);
            let data =  await CartModel.findByIdAndUpdate({_id:cart._id},cart, {new:true});
            data = data.toJSON();
            const {items} = newWishlist;
            if(cart.items.length > 0) {
                await resetScheduleCartMailer(req.me._id)
              } else if(cart.items.length === 0) {
                await cancelScheduleCartMailer(req.me._id)
              }
            return res.status(201).json({result:{...data,wishlistItems:items}});
        }
        return res.status(200).json({result:cart});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};

export const executeSchedule = async(req, res)=> {
    try {
        const userId = req.params.userId;
        const {firstName, lastName, email} = await UserModel.findOne({_id: userId}, {firstName: 1, lastName: 1, email: 1});
        const name = firstName + ' ' + lastName;
        let cart =  await CartModel.findOne({userId});
        if(cart.currentOrderId) {
            let order = await OrderModel.findOne({_id: cart.currentOrderId}).populate('discount');
            let items = order.cart.items.length ? cart.items.map(item => {
                return {
                    domainName: item.domainName,
                    actualPrice: item.price,
                    finalPrice: order.discount ? Number(item.price) - (Number(item.price) * (Number(order.discount.discount)/100)) : item.price
                }
            }) : cart.items.map(item => {
                return {
                    domainName: item.domainName,
                    actualPrice: item.price,
                    finalPrice: 0
                }
            });
            sendCartReminder({
                name: name, 
                cartItem: items
            }, null, email);
            return res.send("Success");
        }
        else if(cart.items.length > 0) {
            sendCartReminder({
                name: name, 
                cartItem: cart.items.map(item => {
                    return {
                        domainName: item.domainName,
                        actualPrice: item.price,
                        finalPrice: 0
                    }
                })
            }, null, email);
            return res.send("Success");
        }
        return res.send("Success");
    } catch (error) {
        
        return errorHandler (error,400,res);
    }
}
