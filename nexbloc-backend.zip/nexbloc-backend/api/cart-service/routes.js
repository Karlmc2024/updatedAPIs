const router = require('express').Router();
import {addItemToCart, clearCart, deleteCartItem, getMyCart, updateCart, moveToWishlist,
     executeSchedule} from './controller';

//todo add validation to Api's
let validator = require('./validator');

router.get('/',getMyCart);

router.post('/',addItemToCart);

router.delete('/:itemId',deleteCartItem);
// router.delete('clear-cart/:id',clearCart);

router.put('/',updateCart);
router.put('/:itemId/move-to-wishlist',moveToWishlist);
router.put('/executeCartMail/:userId', executeSchedule);

export default router;
