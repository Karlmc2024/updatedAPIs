// create cart service
import {CartModel} from './model';

export const createCart = (userId) => {
    const cart = {
        userId,
        items: [],
        totalQuantity: 0,
        totalCost:0
    };
    return CartModel.create(cart);
};

export const clearCart = ({userId}) => {
    return CartModel.findOneAndUpdate({userId}, {items: [], totalQuantity: 0, totalCost: 0});
};

export const addToCart = async({userId,domain})=>{
    const {domainName} = domain;
    let cart =  await CartModel.findOne({userId});
        let index = cart.items.findIndex(item=>item.domainName.toString() === domainName);
        if (index === -1){
            cart.items.push(domain);
            cart.totalQuantity = cart.items.length;
            cart.totalCost =  cart.items.reduce( function(a, b){
                return a + b['price'];
            }, 0);
            let data =  await CartModel.findByIdAndUpdate({_id:cart._id},cart, {new:true});
            return data;
        }
    return cart;
};

export const addCartPriceAndQuantity = (cart)=>{
    cart.totalQuantity = cart.items.length;
    cart.totalCost =  cart.items.reduce( function(a, b){
        return a + b['price'];
    }, 0);
    return cart;
};

