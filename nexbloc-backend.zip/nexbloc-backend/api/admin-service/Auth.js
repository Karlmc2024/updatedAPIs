export const AdminAuth = async (req, res, next) => {
    try {
        
        let API_KEY  = req.headers['authorization'];
        
        if (API_KEY) {
            if (API_KEY  === process.env.ADMIN_API_KEY){
                 next();
            } else {
                return res.status(401).send({message: 'Invalid Auth. Pleas Login Again', type :'Admin'});
                
            }
        } else {
            return res.status(401).send({message: 'Invalid Auth. Pleas Login Again', type :'Admin'});
        }
    } catch (err) {
        logger.error('token error', err);
        
        return res.status(401).send({message: 'Invalid Auth. Pleas Login Again', type :'Admin'});
    }
};

