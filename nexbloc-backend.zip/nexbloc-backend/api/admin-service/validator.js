const  joi  = require('@hapi/joi');
import errorHandler from '@lib/utils/error';
/*eslint-disable*/

const validatePagination  = (req, res, next)=>{
    const schema   = joi.object({
        page :  joi.number().min(0).required(),
        limit:  joi.number().min(0).required()
    });
    const {error}  = schema.validate(req.query);
    if (error){
        return errorHandler(error , 400, res);
    } else {
        next();
    }
};
const validateAddPremiumDomain  = (req, res, next)=> {
    const domainschma   = joi.object({
        domainName  :  joi.string().required(),
        price:  joi.string().required(),
        currency :  joi.string().required()
    });
    const schema  = joi.object({
        domains : joi.array().min(1).items(domainschma)
    });
    const {error}  = schema.validate(req.body);
    if (error){
        return errorHandler(error , 400, res);
    } else {
        next();
    }
};
const validateCreateTld  = (req, res, next)=>{
    const schema  = joi.object({
        tldName: joi.string().invalid("").required().label("Tld Name"),
        network: joi.string().optional().label("Network"),
        basePrice: joi.number().greater(-1).required(),
        active: joi.boolean().optional(),
        mintable: joi.boolean().optional(),
        visible: joi.boolean().optional()
    })
    const {error } =  schema.validate(req.body);
    if(error){
        return errorHandler(error , 400, res);
    }
    else{
        next();
    }
}
const validateUpdateTld  = (req, res, next)=>{
    const schema  = joi.object({
        tldName: joi.string().invalid("").optional().label("Tld Name"),
        network: joi.string().optional().label("Network"),
        basePrice: joi.number().greater(-1).optional(),
        active: joi.boolean().optional(),
        mintable: joi.boolean().optional(),
        visible: joi.boolean().optional()
    })
    const {error } =  schema.validate(req.body);
    if(error){
        return errorHandler(error , 400, res);
    }
    else{
        next();
    }
    
}

module.exports  = {validatePagination, validateAddPremiumDomain, validateCreateTld, validateUpdateTld};
