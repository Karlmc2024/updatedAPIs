/************************ EXPRESS MODULES AND LIBRARIES *********************/
/*eslint-disable*/
'use strict';
const express = require('express');
const router = express.Router();

const { getUserReport, getUserDetails, searchUser, getuserDomains, getMonthlyUsersofCurruntyear, getUserCurruntMonthReport, getYearlyusers, getTodayusercount } = require('./controllers/user');
const { searchDomain, getDomainReport, getDomainDetail, gettodaydomaincount, getTotalBookedDoomains } = require('./controllers/domain');
const { addPremiumDomain, getPremiumDomain, searchPremiumDomain, getPremiumDomainDetails, getTotalSoldPremiumDomains } = require('./controllers/premium-domain');
const { getYearlysales, getCurrruntMonthSale, getCurruntyearMonthwiseSale, TotalSale, getSaleReport, TodaysSale } = require('./controllers/sales');
const { getTradeMarkRequests, updateTradeMarkRequestStatus, searchTradeMarkRequest, createTradeMark, getTradeMark, deleteTradeMark ,approveTrademarkRequest} = require('./controllers/trademark');
const { getTlds, createTld, updateTld } = require('./controllers/tld');
const { getAllDiscounts, createDiscount, getDiscountDetail, updateDiscount, deleteDiscount } = require('./controllers/discount');
const { getDashboardSaleReport, getDashboardUserReport } = require('./controllers/dashboard');


/****************************USER AND SALE  DASHBOARD REPORT  ******************/
router.get("/dashboard-sale-report", getDashboardSaleReport);
router.get("/dashboard-user-report", getDashboardUserReport);

/**************************** USER  REPORT *************************************/
router.get('/users', getUserReport);
router.get('/search-user', searchUser);
router.get('/user-detail/:_id', getUserDetails);
router.get('/user-domains/:_id', getuserDomains);
router.get('/currunt-year-monthly-users', getMonthlyUsersofCurruntyear);
router.get('/user-yearly-report', getYearlyusers);
router.get('/currunt-month-users', getUserCurruntMonthReport);
router.get('/today-user-count', getTodayusercount);

/*************************** DOMAIN DETAIL REPORT  *****************************/
router.get('/domains', getDomainReport);
router.get('/domain-detail/:_id', getDomainDetail);
router.get('/search-domain', searchDomain);
router.get('/today-domain-count', gettodaydomaincount);
router.get('/total-book-domain', getTotalBookedDoomains);
router.get('/total-sold-premium-domains', getTotalSoldPremiumDomains);
/*************************** PREMIUM  DOMAIN  REPORT **************************/
router.get('/premium-domains/', getPremiumDomain);
router.post('/add-premium-domain', addPremiumDomain);
router.get('/premium-domain-detail/:_id', getPremiumDomainDetails);
router.get('/search-premium-domain', searchPremiumDomain);

/**************************** SALES REPORT  ****************************************/
router.get('/monthly-sale', getCurruntyearMonthwiseSale);
router.get('/yearly-sale-report', getYearlysales);
router.get('/currunt-month-sale', getCurrruntMonthSale);
router.get('/total-sale', TotalSale);
router.get('/sale-report', getSaleReport);
router.get('/today-sale-count', TodaysSale);

/*****************************TradeMark request */

router.post('/trademarks', createTradeMark);
router.get('/trademarks', getTradeMark);
router.delete('/trademarks/:id', deleteTradeMark);
router.get('/trademarks/request', getTradeMarkRequests);
router.get('/trademarks/request/search', searchTradeMarkRequest);
router.put('/trademarks/request/:id', updateTradeMarkRequestStatus);
router.put('/approve-trademark-request/:id', approveTrademarkRequest)

/****************************** Tld  **********************************/
router.get('/tld', getTlds);
router.put('/tld/:id', updateTld);
router.post('/tld', createTld);

/*************Discounts ************************ */
router.route('/discounts').post(createDiscount).get(getAllDiscounts)
router.route('/discounts/:id').get(getDiscountDetail).put(updateDiscount).delete(deleteDiscount)

/******************************** END *********************************************/
module.exports = router;
