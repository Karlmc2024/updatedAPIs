/*eslint-disable*/
const { TldModel } = require('../../tld-api/model');
import errorHandler from '@lib/utils/error';

const getTlds = async (req, res) => {
    try {
        if (req.query.page && req.query.limit) {
            let {page, limit} = req.query;
            page = Math.max(1, page);
            limit = Math.max(0, limit);         
            const result = await TldModel.find({}).sort({createdAt: -1}).skip(page > 0 ? ((page - 1) * limit) : 0).limit(limit);
            return res.status(200).json({result});
        } else {
            const allusers =  await TldModel.find({}).sort({createdAt: -1});
            return res.status(200).json({result: allusers});
        }
        const result = await TldModel.find({});
        return res.status(200).json({ result });
    }
    catch (error) {
        return errorHandler(error, 400, res);
    }
}

const createTld = async (req, res) => {
    try {
        const tldexist = await TldModel.findOne({ tldName: req.body.tldName });
        if (tldexist) {
            return errorHandler({error: "", message :"Invalid Tld name "}, 400, res);
        }
        else {
            await TldModel.create({ ...req.body });
            return res.status(200).json({ result :{ message :"Tld created successfully"}});
        }
    }
    catch (error) {
        return errorHandler(error, 400, res);
    }
}

const updateTld = async (req, res) => {
    try {
        await TldModel.findOneAndUpdate({ _id: req.params.id }, { ...req.body });
        return res.status(200).json({result :{ message: "Tld updated successfully" }});
    }
    catch (error) {
        return errorHandler(error, 400, res);
    }
}

module.exports = { createTld, updateTld, getTlds }