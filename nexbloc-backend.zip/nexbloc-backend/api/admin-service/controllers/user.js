/**************************************** USER REPORTS *********************************************/

const {UserModel} = require('../../user-service/model');
import errorHandler from '@lib/utils/error';
import {ProductDomainModel} from '../../domain-service/model';

/*********************************** GET TODAY JOINED  USERS *********************/
const getUserReport = async (req, res) => {
    try {
        
        const temp1 = new Date(req.query.start);
        const temp2 = new Date(req.query.end);
        const start = new Date(temp1.getFullYear(), temp1.getMonth(), temp1.getDate());
        const end = new Date(temp2.getFullYear(), temp2.getMonth(), temp2.getDate() + 1);
        
        if (req.query.page && req.query.limit) {
            let {page, limit} = req.query;
            page = Math.max(0, page);
            limit = Math.max(0, limit);

            const result = await UserModel.aggregate([
                {$match: {createdAt: {$gte: start, $lte: end}}},
                {$sort: {createdAt: -1}},
                {$skip: page > 0 ? ((page - 1) * limit) : 0},
                {$limit: limit},
                {
                    $lookup:
                    {
                        from: 'productdomains',
                        localField: '_id',    // field in user collection
                        foreignField: 'userId',
                        pipeline: [], // field in the  domain collection
                        as: 'domains'
                    }
                }
            ]);
            
            return res.status(200).json({result});
        } else {
            const allusers = await UserModel.aggregate([
                {$match: {createdAt: {$gte: start, $lte: end}}},
                {$sort: {createdAt: -1}},
              {
                    $lookup:
                    {
                        from: 'productdomains',
                        localField: '_id',    // field in user collection
                        foreignField: 'userId',
                        pipeline: [], // field in the  domain collection
                        as: 'domains'
                    }
                }
            ]);
            return res.status(200).json({result: allusers});
        }
    } catch (error) {
       

        return errorHandler(error, 400, res);
    }
};


const getUserDetails = async (req, res) => {
    try {
        if (req.params._id) {
            const userid = req.params._id;
            const isuser = await UserModel.findById(userid).select('-password -emailVerifyUrl -secretKey');
            if (isuser) {
                return res.status(200).json({result: isuser});
            } else {
                return errorHandler({message: 'User id required'}, 400, res);
            }
        } else {
            return errorHandler(error, 400, res);
        }
    } catch (error) {
        return errorHandler(error, 400, res);
    }
};

const searchUser = async (req, res) => {
    try {
        if (req.query.email) {
            const email = req.query.email;
            const users = await UserModel.aggregate([
                {$match: {email: {$regex: email}}},
                {$sort: {createdAt: -1}},
                {$limit: 10},
                {
                    $lookup:
                    {
                        from: 'productdomains',
                        localField: '_id',    // field in user collection
                        foreignField: 'userId',
                        pipeline: [], // field in the  domain collection
                        as: 'domains'
                    }
                }
            ]);
            
            
              return res.status(200).json({result: users});
        } else {
            return errorHandler({message: 'Email  required '}, 400, res);
        }
    } catch (error) {
        return errorHandler(error, 400, res);
    }
};
const getuserDomains = async (req, res) => {
    try {
        let {page, limit} = req.query;
        page = Math.max(1, page);
        limit = Math.max(1, limit);
        const result = await ProductDomainModel.find({
            userId: req.params._id
        }).sort({createdAt: -1})
            .skip(page > 0 ? ((page - 1) * limit) : 0)
            .limit(limit);
        return res.status(200).json({result});
    } catch (error) {
        return errorHandler(error, 400, res);
    }
};

/**************************************************  USER REPORTS  ************************************/
const getYearlyusers = async (req, res) => {
    try {
        const {startyear, endyear} = req.query;
        const start = new Date(startyear, 1, 1);
        const end = new Date(endyear, 12, 0);
        const result = await UserModel.aggregate([
            {$match: {createdAt: {$gte: start, $lte: end}}},
            {
                $group: {
                    _id: {
                        year: {$year: '$createdAt'}
                    },
                    count: {$sum: 1}
                }
            },
            {$sort: {'_id.year': 1}}
        ]);
        return res.status(200).json({result});

    } catch (error) {
        
        return errorHandler(error, 400, res);
    }
};



/****************************** monthly joined user in ucrrunt year *******************/
const getMonthlyUsersofCurruntyear = async (req, res) => {
    try {
        const now = new Date();
        const {startmonth, endmonth} = req.query;
        const start = new Date(now.getFullYear(), startmonth, 1);
        const end = new Date(now.getFullYear(), Math.abs(endmonth), 0);
        const result = await UserModel.aggregate([
            {$match: {createdAt: {$gte: start, $lte: end}}},
            {
                $group: {
                    _id: {
                        year: {$year: '$createdAt'},
                        month: {$month: '$createdAt'}
                    },
                    count: {$sum: 1}
                }
            },
            {$sort: {'_id.month': 1}},
        ]);
        return res.status(200).json({result});
    } catch (error) {
        return errorHandler(error, 400, res);
    }
};
/************************************* GET DAY BY DAY USER REPORT OF CURRUNT MONTH  **************/

const getUserCurruntMonthReport = async (req, res) => {
    try {
        const {startdate, enddate} = req.query;
        const now = new Date();
        const start = new Date(now.getFullYear(), now.getMonth() , startdate);
        
        const result = await UserModel.aggregate([
            {$match: {createdAt: {$gte: start}}},
            {
                $project: {
                    dayOfMonth: {$dayOfMonth: '$createdAt'},
                    month: {$month: '$createdAt'},
                    year: {$year: '$createdAt'},
                }
            },
            {
                $group: {
                    _id: {
                        year: '$year',
                        month: '$month',
                        dayOfMonth: '$dayOfMonth'
                    },
                    count: {$sum: 1}
                }
            },
            {$sort: {'_id.dayOfMonth': 1}}
            
        ]);
        
        return res.status(200).json({result});
    } catch (error) {
        
        return errorHandler(error, 400, res);
    }
};

const getTodayusercount  = async (req, res)=>{
    try {
        const now  = new Date();
        const today  = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const result  = await UserModel.find({createdAt: {$gte : today}}).count();
        return res.status(200).json({result});


    } catch (error){
        
    return errorHandler(error, 400, res);
    }
};



module.exports = {getUserReport, getUserDetails, searchUser, getuserDomains, getMonthlyUsersofCurruntyear, getUserCurruntMonthReport, getYearlyusers, getUserCurruntMonthReport , getTodayusercount};
