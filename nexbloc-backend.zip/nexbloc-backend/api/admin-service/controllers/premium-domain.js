/*********************************** PREMIUM DOMAINS *********************************/

/********************************** MODELS AND  LIBRARIES  ***************************/
const { PremiumDomainModel } = require('../../premium-domain/model');
const { ProductDomainModel } = require('../../domain-service/model');
const { TradeMarkModel } = require('../../trademark-service/model');
const { TldModel } = require('../../tld-api/model');

import errorHandler from '@lib/utils/error';

/*********************************** APIES FOR PREMIUM DOMAINS  *************************/
const addPremiumDomain = async (req, res) => {
    try {
        /**************************** CHECK PREMIUM DOMAIN IS TRADEMARK NAME OR NOT ******************************/
        /**************************** CHECK TLD IS VALIDE OR NOT  */


        const domainText = req.body.domainName.split('.');
        if (domainText[1]) {
            /****************************** CHECK TLD IS VALID OR NOT  ******************/
            const isvalidetld = await TldModel.findOne({ tldName: `.${domainText[1]}` });
            if (!isvalidetld) {
                return res.status(400).json({ message: `Invalid domain name` });
            }
        }

        const istrademark = await TradeMarkModel.findOne({ tradeMarkName: domainText[0] });
        if (istrademark) {
            return res.status(400).json({ message: `${req.body.domainName}  is already in use` });

        }


        /***********************check domain name exist or not *******************/

        const domain = await PremiumDomainModel.findOne({
            'domainName': req.body.domainName
        })
        const isnormaldomain = await ProductDomainModel.findOne({ domainName: req.body.domainName });

        if (domain || isnormaldomain) {
            return res.status(400).json({ message: `${req.body.domainName} already in use` });
        }
        else {
            /************ Add domains *************/

            const data = new PremiumDomainModel({ ...req.body });
            await data.save();

            return res.status(200).json({ message: "Domains added successfully", result: data });
        }
    }
    catch (error) {

        return errorHandler(error, 400, res);

    }
}

const getPremiumDomain = async (req, res) => {
    try {
        const temp1 = new Date(req.query.start);
        const temp2 = new Date(req.query.end);
        const start = new Date(temp1.getFullYear(), temp1.getMonth(), temp1.getDate());
        const end = new Date(temp2.getFullYear(), temp2.getMonth(), temp2.getDate() + 1);

        if (req.query.page && req.query.limit) {
            let { page, limit } = req.query;
            page = Math.max(0, page);
            limit = Math.max(0, limit);
            const result = await PremiumDomainModel.find({
                createdAt: {
                    $gte: start,
                    $lte: end
                }
            }).sort({ createdAt: 1 })
                .skip(page > 0 ? ((page - 1) * limit) : 0)
                .limit(limit);

            return res.status(200).json({ result });
        }
        else {
            const allusers = await PremiumDomainModel.find({
                createdAt: {
                    $gte: start,
                    $lte: end
                }
            }).sort({ createdAt: 1 });
            return res.status(200).json({ result: allusers });
        }

    }
    catch (error) {

        return errorHandler(error, 400, res);
    }
}

const searchPremiumDomain = async (req, res) => {
    try {
        if (req.query.domainName) {
            const domains = await PremiumDomainModel.find({ domainName: { $regex: req.query.domainName } });
            return res.status(200).json({ result: domains });
        }
        else {
            return errorHandler({ message: "Domain Name required" }, 400, res);
        }
    }
    catch (error) {
        return errorHandler(error, 400, res);
    }
}

const getPremiumDomainDetails = async (req, res) => {
    try {
        if (req.params._id) {
            const domain = await PremiumDomainModel.findById(req.params._id);
            return res.status(200).json({ result: domain });
        }
        else {
            return errorHandler({ message: "Domain id required" }, 400, res);
        }

    }
    catch (error) {
        return errorHandler(error, 400, res);
    }
}

const getTotalSoldPremiumDomains = async (req, res) => {
    try {
        const count = await PremiumDomainModel.find({ soldOut: true }).count();
        ("total sold domains", count);
        return res.status(200).json({ result: count });


    }
    catch (error) {
        return errorHandler(error, 400, res);
    }
}


module.exports = { addPremiumDomain, getPremiumDomain, searchPremiumDomain, getPremiumDomainDetails, getTotalSoldPremiumDomains };