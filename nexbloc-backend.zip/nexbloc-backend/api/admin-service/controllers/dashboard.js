const { UserModel } = require("../../user-service/model");
const { TransactionModel } = require("../../transaction-service/model");
import errorHandler from '@lib/utils/error';


const getDashboardUserReport = async (req, res) => {
    try {
        const temp1 = new Date(req.query.startdate);
        const temp2 = new Date(req.query.enddate);
        const start = new Date(temp1.getFullYear(), temp1.getMonth(), temp1.getDate());
        const end = new Date(temp2.getFullYear(), temp2.getMonth(), temp2.getDate() + 1);
        const result = await UserModel.aggregate([
            { $match: { createdAt: { $gte: start, $lte: end } } },
            {
                $project: {
                    dayOfMonth: { $dayOfMonth: '$createdAt' },
                    month: { $month: '$createdAt' },
                    year: { $year: '$createdAt' },
                }
            },
            {
                $group: {
                    _id: {
                        year: '$year',
                        month: '$month',
                        dayOfMonth: '$dayOfMonth'
                    },
                    count: { $sum: 1 }
                }
            },
            { $sort: { '_id.dayOfMonth': 1 } }

        ]);

        return res.status(200).json({ result });


    }
    catch (error) {
        return errorHandler(error, 400, res);

    }

}

const getDashboardSaleReport = async (req, res) => {
    try {
        const temp1 = new Date(req.query.startdate);
        const temp2 = new Date(req.query.enddate);
        const start = new Date(temp1.getFullYear(), temp1.getMonth(), temp1.getDate());
        const end = new Date(temp2.getFullYear(), temp2.getMonth(), temp2.getDate() + 1);
        const result = await TransactionModel.aggregate([
            { $match: { createdAt: { $gte: start, $lte: end }, status: "paymentDone" } },
            {
                $project: {
                    dayOfMonth: { $dayOfMonth: "$createdAt" },
                    month: { $month: "$createdAt" },
                    year: { $year: "$createdAt" },
                    amount: 1
                }
            },
            {
                $group: {
                    _id: {
                        year: '$year',
                        month: '$month',
                        dayOfMonth: '$dayOfMonth'
                    },
                    amount: { $sum: '$amount' }
                }
            },
            { $sort: { "_id.dayOfMonth": 1 } }
        ])

        return res.status(200).json({ result });
    }
    catch (error) {
        return errorHandler(error, 400, res);
    }
}

module.exports = {
    getDashboardSaleReport,
    getDashboardUserReport
}