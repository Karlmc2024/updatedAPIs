const {DiscountModel} =require('@api/model');
const { default: errorHandler } = require('@lib/utils/error');
const createDiscount=async(req,res) => {
    try{
        const couponCode=req.body.couponCode.toUpperCase()
        const isDiscountExist=await DiscountModel.findOne({
            couponCode,active:true
        })
        const discount={...req.body}
        if(isDiscountExist){
            return res.status(400).json({message:"coupon code already exist"})
        }
        if(req.body.typeOfCoupon==='oneTime' || req.body.typeOfCoupon==='newuser'){
            discount.applyAuto=false
        }
        const newDiscount=await DiscountModel.create(discount)
        return res.status(201).json({
            result:newDiscount
        })
    }
    catch(error){
        return errorHandler(error,400,res)
    }
}
const getAllDiscounts=async(req,res) => {
    try{
        const coupons=await DiscountModel.find({active:true})
        return res.status(200).json({
            result:coupons
        })
    }
    catch(error){
        return errorHandler(error,400,res)
    }
}
const getDiscountDetail=async(req,res) => {
    try{
        const discountId=req.params.id;
        const discount=await DiscountModel.findById(discountId);
        if(!discount){
            return res.status(400).json({message:"Discount does not exist"})
        }
        return res.status(200).json({result:discount})
    }
    catch(error){
        return errorHandler(error,400,res)
    }
}
const updateDiscount=async(req,res) => {
    try{
        const discountId=req.params.id;
        const updateDiscount=await DiscountModel.findByIdAndUpdate(discountId,req.body,{new:true})
        if(!updateDiscount){
            return res.status(400).json({message:"discount does not exist"})
        }
        return res.status(200).json({result:updateDiscount})
    }
    catch(error){
       return errorHandler(error,400,res)
    }
}
const deleteDiscount=async (req,res) => {
    try{
       const discountId=req.params.id;
       //soft deleting discounts
       const deleteDiscount=await DiscountModel.findByIdAndUpdate(discountId,{active:false})

       if(!deleteDiscount){
        return res.status(400).json({
            message:"Discount Doesn't exists"
        })
       }
       return res.status(203).json({result:deleteDiscount})
    }
    catch(error){
       return errorHandler(error,400,res);
    }
}
module.exports={
    createDiscount,
    getAllDiscounts,
    getDiscountDetail,
    updateDiscount,
    deleteDiscount
}