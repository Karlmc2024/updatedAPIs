/**************************************  DOMAIN REPORTS **********************************/

const { ProductDomainModel } = require('../../domain-service/model');
const mongoose = require('mongoose');
import errorHandler from '@lib/utils/error';

const getDomainReport = async (req, res) => {
    try {
        const temp1 = new Date(req.query.start);
        const temp2 = new Date(req.query.end);
        const start = new Date(temp1.getFullYear(), temp1.getMonth(), temp1.getDate());
        const end = new Date(temp2.getFullYear(), temp2.getMonth(), temp2.getDate() + 1);
        if (req.query.page && req.query.limit) {
            let { page, limit } = req.query;
            page = Math.max(0, page);
            limit = Math.max(0, limit);
            const result = await ProductDomainModel.find({
                createdAt: {
                    $gte: start,
                    $lte: end
                }
            }).sort({ createdAt: -1 })
                .skip(page > 0 ? ((page - 1) * limit) : 0)
                .limit(limit);
            return res.status(200).json({ result });
        } else {
            const allusers = await ProductDomainModel.find({
                createdAt: {
                    $gte: start,
                    $lte: end
                }
            }).sort({ createdAt: -1 });
            return res.status(200).json({ result: allusers });
        }
    } catch (error) {

        return errorHandler(error, 400, res);
    }
};

const searchDomain = async (req, res) => {
    try {
        if (req.query.domainName) {
            const domainName = req.query.domainName;
            const domains = await ProductDomainModel.find({ domainName: { $regex: domainName } }).limit(10);
            return res.status(200).json({ result: domains });
        } else {
            return errorHandler({ message: 'Domain name required' }, 400, res);
        }

    } catch (error) {

        return errorHandler(error, 400, res);
    }
};
const getDomainDetail = async (req, res) => {
    try {
        if (req.params._id) {
            const domain = await ProductDomainModel.aggregate([
                { $match: { _id: mongoose.Types.ObjectId(req.params._id) } },
                {
                    $lookup:
                    {
                        from: 'users',
                        localField: 'userId',    // field in user collection
                        foreignField: '_id',
                        pipeline: [], // field in the  domain collection
                        as: 'user'
                    }
                },
                {
                    $project: { 'user.secretKey': 0, 'user.password': 0, 'user.emailVerifyUrl': 0 }
                }
            ]);
            return res.status(200).json({ result: domain });
        } else {
            return errorHandler({ message: 'Domain id require' }, 400, res);
        }

    } catch (error) {

        return errorHandler(error, 400, res);
    }
};


const gettodaydomaincount = async (req, res) => {
    try {
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

        const result = await ProductDomainModel.find({ createdAt: { $gte: today } }).count();

        return res.status(200).json({ result });

    } catch (error) {
        return errorHandler(error, 400, res);

    }
};

const getTotalBookedDoomains = async (req, res) => {
    try {
        const result = await ProductDomainModel.aggregate([
            { $group: { _id: null, count: { $sum: 1 } } }
        ]);
        if (result.length == 0) {
            return res.status(200).json({ result: 0 });
        }
        return res.status(200).json({ result: result[0].count });

    } catch (error) {

        return errorHandler(error, 400, res);
    }
};
module.exports = { searchDomain, getDomainReport, getDomainDetail, gettodaydomaincount, getTotalBookedDoomains };
