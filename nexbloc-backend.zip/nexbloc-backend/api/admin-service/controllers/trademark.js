const { trademarkRequestModel, TradeMarkModel } = require('../../trademark-service/model');
import errorHandler from '@lib/utils/error';
import { updateTradeMarkTicket } from '@lib/utils/hubspot';
import { createOrder } from '@api/order-service/controller';
export const createTradeMark = async (req, res) => {
    try {
        const newTradeMark = await TradeMarkModel.create({ ...req.body })
        return res.status(201).json({ result: newTradeMark })
    }
    catch (error) {

        return errorHandler(error, 400, res)
    }
}

export const getTradeMark = async (req, res) => {
    try {
        
        if (req.query.page && req.query.limit) {
            const temp1 = new Date(req.query.start);
            const temp2 = new Date(req.query.end);
            const start = new Date(temp1.getFullYear(), temp1.getMonth(), temp1.getDate());
            const end = new Date(temp2.getFullYear(), temp2.getMonth(), temp2.getDate() + 1);

            let { page, limit } = req.query;
            page = Math.max(0, page);
            limit = Math.max(0, limit);
            const result = await TradeMarkModel.aggregate([
                { $match: { createdAt: { $gte: start, $lte: end } } },
                { $sort: { createdAt: -1 } },
                { $skip: page > 0 ? ((page - 1) * limit) : 0 },
                { $limit: limit }
            ]);
            return res.status(200).json({ result });
        }
        else {
            const allTM = await TradeMarkModel.find({
            }).sort({ createdAt: -1 })
            return res.status(200).json({ result: allTM});
        }
    }
    catch (error) {
        return errorHandler(error, 400, res)

    }
}

export const deleteTradeMark = async (req, res) => {
    try {
        const trademarkId = req.params.id;
        const allTradeMarkReq = await trademarkRequestModel.find({ trademark: trademarkId });

        if (allTradeMarkReq.length > 0) {
            await trademarkRequestModel.updateMany({ trademark: trademarkId }, { status: "rejected", message: "TradeMark Not available" })
        }
        const deleteTradeMark = await TradeMarkModel.findByIdAndDelete(trademarkId)
        return res.status(200).json({ result: null, message: 'trademark deleted Successfully' })
    }
    catch (error) {
        return errorHandler(error, 400, res)
    }
}
export const getTradeMarkRequests = async (req, res) => {
    try {
        if (req.query.page && req.query.limit) {
            const temp1 = new Date(req.query.start);
            const temp2 = new Date(req.query.end);
            const start = new Date(temp1.getFullYear(), temp1.getMonth(), temp1.getDate());
            const end = new Date(temp2.getFullYear(), temp2.getMonth(), temp2.getDate() + 1);

            let { page, limit } = req.query;
            page = Math.max(0, page);
            limit = Math.max(0, limit);
            const result = await trademarkRequestModel.aggregate([
                { $match: { createdAt: { $gte: start, $lte: end } } },
                { $sort: { createdAt: -1 } },
                { $skip: page > 0 ? ((page - 1) * limit) : 0 },
                { $limit: limit }
            ]);
            return res.status(200).json({ result });
        }
        else {
            const allTMRequest = await trademarkRequestModel.find({
            }).sort({ createdAt: -1 })
            return res.status(200).json({ result: allTMRequest });
        }
    }
    catch (error) {
        return errorHandler(error, 400, res)

    }
}
export const searchTradeMarkRequest = async (req, res) => {
    try {
        if (req.query.domainName) {
            const domainName = req.query.domainName;
            const tradeMarkRequests = await trademarkRequestModel.find({ domainName: { $regex: domainName } }).limit(10);
            return res.status(200).json({ result: tradeMarkRequests });
        }
        else {
            return errorHandler({ message: "Domain name required", status: 400 }, res);
        }

    }
    catch (error) {

        return errorHandler(error, 400, res);
    }
}
export const updateTradeMarkRequestStatus = async (req, res) => {
    try {

        const updatedTradeMarkRequest = await trademarkRequestModel.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true })
        //if hubspot ticket exist update it
        if (updatedTradeMarkRequest.hubspotTicketId) {
            await updateTradeMarkTicket(updatedTradeMarkRequest.hubspotTicketId, updatedTradeMarkRequest)
        }
        return res.status(200).json({ result: updatedTradeMarkRequest });
    }
    catch (error) {

        return errorHandler(err, 400, res)
    }
}


export const approveTrademarkRequest = async(req,res) => {
    try{
    console.log("----admin------")
    const tradeMarkRequestId = req.params.id;
    if(!tradeMarkRequestId){
        const error = new Error("Please provide id of tm request")
        return errorHandler(error,400,res)
    }
    //find the tradeMark Request
    await trademarkRequestModel.findByIdAndUpdate(tradeMarkRequestId,{status:"accepted"})
    return res.status(200).json({
        message:"Accepted Successfully"
    })
  }
    catch(err){
        return errorHandler(err,400,res)
    }

}