import {PremiumDomainModel} from './model';
import errorHandler from '@lib/utils/error';


export const addPremiumDomain = async (req, res) => {
  try {
    let {body} = req;
    let domain = await PremiumDomainModel(body).save();
    return res.status(201).json({data: domain});
  } catch (error) {
    return errorHandler (error,400,res);
  }
};

export const getPremiumDomain = async (req, res) => {
  try {
    let {body} = req;
    let domain = await PremiumDomainModel.find({soldOut: {$ne: true}});
    return res.status(201).json({data: domain});
  } catch (error) {
    return errorHandler (error,400,res);
  }
};

export const deletePremiumDomain = async (req, res) => {
  try {
    let {id} = req.params;
    let domain = await PremiumDomainModel.findByIdAndDelete(id);
    return res.status(200).json({data: domain});
  } catch (error) {
    return errorHandler (error,400,res);

  }
};
