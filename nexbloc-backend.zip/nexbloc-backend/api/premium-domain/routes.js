const router = require('express').Router();
import {
  getPremiumDomain,
  addPremiumDomain,
  deletePremiumDomain,
} from './controller';

router.get('/', getPremiumDomain);
router.post('/', addPremiumDomain);
router.delete('/:id', deletePremiumDomain);

export default router;
