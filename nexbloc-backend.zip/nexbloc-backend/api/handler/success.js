const SuccessCreated  = (data,message ,res)=>{
    if (data){
        return res.status(201).json({message:message , data: data});
    }
    return res.status(201).json({message});
};

const SuccessHandler = (data, message, res)=>{
    return res.status(200).json({message: message , data: data});

};

module.exports  = {SuccessCreated , SuccessHandler};
