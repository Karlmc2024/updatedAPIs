import { ProductDomainModel,PremiumDomainModel } from '@api/model';
import errorHandler from '@lib/utils/error';
import { AssetsModel } from '@api/assets-service/model';
import { IpfsDataModel} from './model';
import { addWebsiteContentOnIPFS,uploadMetaDataImage } from './service';



const fs = require('fs');
const {create} = require('ipfs-http-client');
const {promisify} =require('util')
const {AbortController} = require('node-abort-controller')
const {unzipFolderAndValidate} = require('./service');
//without this ipfs http client module do not works
global.AbortController = AbortController;


async function ipfsClientCreate() {
  try{
  const ipfs = await create(
      {
          host: "localhost",
          port: 5001,
          protocol: "http"
      }
  );
  return ipfs;
    }
  catch(error){
    console.log(error)
  }
}


export const uploadMetaDataOnIpfs = async (req,res,next) => {
  try{
    const isMetaDataExist = await AssetsModel.findOne({domainName:req.body.name,resolveType:"ipfs_url"})

    if(isMetaDataExist){
      const error = new Error("Meta data already exist for this domain")
      //if metadata exist and we got image in request need to delete from our storage
      if(req.file){
        fs.unlink(req.file.path,(err) => {
          if(err){
            console.log(err)
          }
        });
      }
      return errorHandler(error,400,res);
    }

    const ipfsDataQueryObj = IpfsDataModel.find({type:["folderHash","defaultImageUrl"]})
    const isPremiumQueryObj = PremiumDomainModel.findOne({domainName:req.body.name})
  

    const [ipfsData,isPremium] = await Promise.all([ipfsDataQueryObj,isPremiumQueryObj])
    const isPremiumDomain = isPremium ? true:false;

    //array method find not db method
    const folderIpfs = ipfsData.find(element => element.type ==='folderHash')
    const [folderIpnsHash,folderHash] = [folderIpfs.value,folderIpfs.cid]

    const ipfsClient = await ipfsClientCreate();

    //image upload
    const imageGatewayUrl = await uploadMetaDataImage(req,ipfsClient,ipfsData)

      //create json
    let body ={...req.body};
    body.image = imageGatewayUrl,
    body.description = body.description || "";
    body.external_url = body.external_url || ""
    body.attributes = [{
    "trait_type":"length",
    "value":body.name.split('.')[0].length
    },
    {
      "trait_type":"isPremium",
      "value":isPremiumDomain
    }]
    body.discordLink = body.discordLink || ""
    body.twitterLink = body.twitterLink || ""
    body.linkedinLink = body.linkedinLink || ""
    body.githubLink = body.githubLink || ""
    body.redditLink = body.redditLink || ""
    //converting body into string to save it into ipfs
    body = JSON.stringify(body)
    
    
    const tokenId = req.body.tokenId 
    
  //move the content generated into root directory

  const result =  await ipfsClient.files.write(`/${tokenId}`,body,{create:true})

  const folderUpdate = await ipfsClient.files.stat(`/`)

  //this line should not block response as it takes too much time if we use awaits.  we need to republish to ipns after files added everytime
  const publish = ipfsClient.name.publish(folderUpdate.cid).catch(err => console.log(err))
  const domain = await ProductDomainModel.findOne({domainName:req.body.name});

  //creating assets obj 
  const assetsObj = {
      domainName:domain.domainName,
      domainId:domain._id,
      resolveType:"ipfs_url",
      resolveString:`https://ipfs.io/ipns/${folderIpnsHash}/${tokenId}`,
      userId:req.me._id
  }

  await AssetsModel.create(assetsObj);
  return res.status(200).json({success:true ,result : assetsObj.resolveString});

}
catch(error){
  if(req.file){
    fs.unlink(req.file.path,(err) => {
      if(err){
        console.log(err)
      }
    });
  }
  console.log(error)
  return errorHandler(error,400,res)
}

}

export const uploadWebsiteOnIPFS = async(req,res,next) => {
  try{
    const domain = await ProductDomainModel.findById(req.params.domainId);
    if(!domain){
      const error = new Error("No such domain exist")
      return errorHandler(error,400,res)
    }
   
    const extractedFiles = await unzipFolderAndValidate(req.file.path,domain.domainName);

    if(!extractedFiles){
      //fs.unlink(req.file.path,(err) => console.log(err));
      return res.status(400).json({message:"You should have index.html inside your root directory"})
    }
    const ipfsClient = await ipfsClientCreate();
   
    let indexHTMLResponse = await addWebsiteContentOnIPFS(ipfsClient,extractedFiles,domain);

    indexHTMLResponse = `https://ipfs.io/ipfs/${indexHTMLResponse}`
    console.log("hello")
    
    //after uploading website to ipfs create a asset containing website_url
    const assetObject = {
      domainId:req.params.domainId,
      resolveType:"website_url",
      resolveString:indexHTMLResponse,
      userId:req.me._id,
      domainName:domain.domainName
    }
    const asset = await AssetsModel.create(assetObject)
    return res.status(200).json({result:asset})
 
}
catch(error){
  console.log(error)
  return errorHandler(error,400,res)
}
}
