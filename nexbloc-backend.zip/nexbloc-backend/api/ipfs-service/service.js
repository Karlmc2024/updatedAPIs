
const decompress = require('decompress')
const fs = require('fs')
const {promisify} = require('util');
export const unzipFolderAndValidate = async(path,destination)=> {
    try{
    console.log(path)
    const zipFile= await decompress(path,`./temp/${destination}`)
    //deleting the extracted folder from disk storage
    fs.rmdir(`./temp/${destination}`, { recursive: true }, err => {
      if (err) {
        console.log(err,"hello")
      }
      console.log(`extracted folder is deleted!`)
    })
    //deleting the original zip file from disk storage
    fs.unlink(path,err => {
      if(err){
        console.log(err)
      }
      console.log("file is Deleted")
    });
    let isIndexHTMLExist = false;
    //checking if index.html exist in extracted array of object and set to true if exist
    for(let start=0;start<=zipFile.length-1;start++){
      if(zipFile[start].path === 'ipfs-website/index.html')
      {
        isIndexHTMLExist = true
        break;
      }
    }
    // if not exist return false
    if(!isIndexHTMLExist){
        return isIndexHTMLExist
      }
    
    return zipFile;
    }
    catch(error){
        console.log(error)
    }
}
export const addWebsiteContentOnIPFS = async (ipfsClient,extractedFiles,domain) => {
  try{
 
    let indexHTMLResponse;
    const files = extractedFiles.map(element => {return {content:element.data,
      path:`/${domain.domainName}/${element.path}`

    }})
    for await (const result of ipfsClient.addAll(files,{wrapWithDirectory:true})){
      if(result.path ===`${domain.domainName}/ipfs-website`){
        indexHTMLResponse = result.cid
      }
    }
    return indexHTMLResponse
  
  }
  catch(err){
    console.log(err)
  }
}

export const uploadMetaDataImage = async(req,ipfsClient,ipfsData) => {

    let imageGatewayUrl ;
   
    let imagePromise = promisify(fs.readFile);

    //if image is present in req then only upload the files otherwise use default image gateway url

    if(req.file){
      let image = await imagePromise(req.file.path)
      const ipfsImage = await ipfsClient.add({
        path:'/image/'+req.file.filename,
        content:image
      })
      imageGatewayUrl = `https://ipfs.io/ipfs/${ipfsImage.cid}/${req.file.filename}`
      fs.unlink(req.file.path,(err) => {
        if(err){
          console.log(err)
        }
      });
    }
    else {
      //array method find not db method
      imageGatewayUrl = ipfsData.find(element => element.type === 'defaultImageUrl').value
    }

    return imageGatewayUrl
}

