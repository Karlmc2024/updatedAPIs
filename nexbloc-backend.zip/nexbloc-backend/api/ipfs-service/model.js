'use strict';
const mongoose = require('mongoose');

const IpfsDataSchema = new mongoose.Schema(
  {
    type:{type:String,required:true,enum:['folderHash','defaultImageUrl']},
    value:{type:String,required:true},
    cid:{type:String,required:true}
  },
  {timestamps: true, versionKey: false}
);

const IpfsDataModel = mongoose.model(
  'IpfsData',
  IpfsDataSchema
);

module.exports = {IpfsDataModel}