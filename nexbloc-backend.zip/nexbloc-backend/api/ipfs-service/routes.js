const router = require('express').Router();
import {uploadMetaDataOnIpfs,uploadWebsiteOnIPFS} from "./controller"
import { uploadIPFSImage } from "@lib/utils/upload";
import { validateMetaData } from "./validator";
import { uploadIPFSWebsite } from "@lib/utils/upload";
import { unzipFolderAndValidate } from "./service";

router.post('/upload',uploadIPFSImage,validateMetaData,uploadMetaDataOnIpfs);
router.post('/upload/website/:domainId',uploadIPFSWebsite,uploadWebsiteOnIPFS)
export default router;
