const joi = require("@hapi/joi");

export const validateMetaData = (req, res, next) => {
	const schema = joi.object({
		name: joi.string().required(),
		external_url: joi.string().optional(),
		description: joi.string().optional(),
        tokenId: joi.string().required(),
		linkedinLink: joi.string().optional(),
		twitterLink : joi.string().optional(),
		githubLink :joi.string().optional(),
		redditLink:joi.string().optional(),
		discordLink:joi.string().optional()
        },
	);
	const { error } = schema.validate(req.body);
	if (error) {
		return res.status(400).json({ message: error.message });
	} else {
		next();
	}
};
