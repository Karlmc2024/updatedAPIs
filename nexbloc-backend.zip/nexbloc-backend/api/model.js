// /**
//  * Import All  Mongoose Model Here
//  */

/**
 * Import All  Mongoose Model Here
 */
 import {CartModel} from './cart-service/model';
 import {ProductDomainModel,DomainHistoryModel} from './domain-service/model';
 import {NotificationModel} from './notification-service/model';
 import {UserModel} from './user-service/model';
 import {TransactionModel} from './transaction-service/model';
 import {WalletModel} from './wallet-service/model';
 import {TldModel} from './tld-api/model';
 import {TradeMarkModel} from './trademark-service/model';
 import {CreditModel} from './credit-system/model';
 import {influencerModel} from './credit-system/model';
 import {trademarkRequestModel} from './trademark-service/model';
 import { OrderModel} from './order-service/model';
 import { DiscountModel } from './discount-service/model';
 import { DomainTransferModel } from './domain-transfer-service/model';
 import { PremiumDomainModel } from './premium-domain/model';
 import { IpfsDataModel } from './ipfs-service/model';

export {
   CartModel,
   ProductDomainModel,
   NotificationModel,
   UserModel, DomainHistoryModel,
   TransactionModel,
   WalletModel, TldModel, CreditModel, TradeMarkModel,influencerModel,trademarkRequestModel,
   OrderModel,DiscountModel,DomainTransferModel,PremiumDomainModel,IpfsDataModel
 };
 
 
