import { OrderModel,UserModel } from "@api/model"
import { DiscountModel } from "./model"
export const isCouponValid=async (coupon,userId) => {
    const userCouponObject=await UserModel.findById(userId)
       //step 1 check if the coupon is expired
        const {couponCode,expireAt,typeOfCoupon}=coupon
       
        if((new Date(expireAt).getTime()) < Date.now()){
          return {status:false,message:'coupon expired'}
        }
       //step2- check if the coupon is of type one time then check if that is already used by that user
       if(typeOfCoupon === 'oneTime'){
         const isUsed=await OrderModel.findOne({status:'paymentDone',
           discount:coupon._id,userId:userId.toString()
         })
         if(isUsed){
           return {status:false,message:'Coupon already used'}
         }
         return {status:true}
       }
       

       //step3 if the coupon type is unlimited simply return valid coupon
       else if(typeOfCoupon === 'unlimited'){
           return {status:true}
       }
       //step 4 if the coupon type is limited
       else if(typeOfCoupon==='many'){
         const isUsed=await OrderModel.find({status:"paymentDone",discount:coupon._id,userId:userId.toString()})
         console.log(isUsed.length);
         if(isUsed.length >=coupon.manyCouponValidity){
          return {status:false,message:"coupon is already used"}
         }
         return {status:true}
       }

       //step 5 if the coupon type is fornewuser check if the user creation Date is not greater than 2 weeks

       else if(typeOfCoupon==='newuser'){
         
           const [userCreation,currentTime]=[new Date(userCouponObject.createdAt).getTime(),new Date().getTime()]
           const timeToCheckInMS=(coupon.newuserCouponValidity)*24*1000*1000 || 7*24*1000*1000
           const timeDiff=currentTime-userCreation
           if(timeDiff>=timeToCheckInMS){
                 return {status:false,message:'Coupon is valid for new users only'};
             }
           else{
             const isUsed=await OrderModel.findOne({
               status:'paymentDone',
               discount:coupon._id,
               userId:userId.toString()
             })
             if(isUsed){
               return {status:false,message:"coupon already used"}
             }
             return {status:true}
           }
           
       }
 return {status:false,message:'coupon invalid'};
}

export const removeDiscount = async (orderId) => {
  try {
    let order=await OrderModel.findById(orderId);
    let updatedOrder = await OrderModel.findByIdAndUpdate(
      orderId,
      {
        finalAmount: order.cart.totalCost,
        discount: null,
      },
      { new: true }
    ).populate('discount');
    return updatedOrder
  } catch (e) {
    console.log(e)
  }
}
