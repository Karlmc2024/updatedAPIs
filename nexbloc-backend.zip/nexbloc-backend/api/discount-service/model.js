'use strict';
import mongoose from 'mongoose';
const objectId = mongoose.Schema.Types.ObjectId;

export const DiscountModel = mongoose.model(
    'DiscountCoupons',
    new mongoose.Schema({
        couponCode: {type: String,required:true,uppercase:true,maxLength:20},
        discount: {type: Number,min:1,max:100,required:true},
        applyTo: {type: mongoose.Schema.Types.Mixed},
        applyAuto: {type: Boolean},
        typeOfCoupon:{type:String,enum:['oneTime','unlimited','newuser',"many"],required:true},
        expireAt:{type:Date,required:true},
        couponAppliedCount:{type:Number,default:0,required:false},
        visible:{type:Boolean,required:false,default:true},
        active:{type:Boolean,required:false,default:true},
        newuserCouponValidity:{type:Number,required:false},
        manyCouponValidity:{type:Number,required:false}
    })
);