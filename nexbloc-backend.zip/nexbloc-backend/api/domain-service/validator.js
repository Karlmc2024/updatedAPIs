const Joi = require("@hapi/joi");

const params = (req, res, next) => {
	const schema = Joi.object({
		userId: Joi.string().required(),
	});
	const { error } = schema.validate(req.params);
	if (error) {
		return res
			.status(400)
			.json({ error: { message: "User Id is missing" } });
	}

	next();
};

const domainSearch = (req, res, next) => {
	const schema = Joi.object({
		domainName: Joi.string().required(),
	});
	const { error } = schema.validate(req.query);
	if (error) {
		return res
			.status(400)
			.json({ error: { message: "Domain name is missing" } });
	}
	next();
};

module.exports = {
	domainSearch,
};
