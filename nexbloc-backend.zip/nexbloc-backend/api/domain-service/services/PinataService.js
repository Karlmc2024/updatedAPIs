require('dotenv').config();
const pinataSDK = require('@pinata/sdk'); // basic Imports of Dependencies
const fs = require('fs');
const ejs = require('ejs');
const ApiKey = process.env.PINATA_API_KEY; //Api Key and Secret Are Available in .env file
const SecretKey = process.env.PINATA_SECRET;
const path = require('path').resolve('./lib/utils/templates/'); // path to the templates html file ./nexbloc-backend/templates/home.html

const pinata = pinataSDK(ApiKey, SecretKey); // Initialization of pinataSDK by npm

let PinataService = {};





PinataService.createDefaultPage = async function (domainName) {
    try {
        const compiled = ejs.compile(fs.readFileSync(path + '/default-website.ejs', 'utf8'));

        const html = compiled({domainName : domainName});
        const websiteTemplate = path + '/default-website.html';
        fs.writeFileSync(websiteTemplate, html);  

        const options = {
            pinataMetadata: {
                name: `NexBloc Welcomes ${domainName}`,
                keyvalues: {
                    customKey: '',
                    customKey2: ''
                }
            },
            pinataOptions: {
                cidVersion: 0
            }
        };
        const hash = await pinata.pinFromFS(websiteTemplate, options);
        return hash;

    } catch (error) {
        
    }
};



module.exports = PinataService;
