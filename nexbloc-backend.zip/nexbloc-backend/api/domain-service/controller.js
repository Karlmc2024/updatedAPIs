/* eslint-disable max-statements */
import { ProductDomainModel } from "./model";
import { PremiumDomainModel } from "../premium-domain/model";
import { LockedDomainModel, OrderModel } from "../order-service/model";
import { TldModel } from "../tld-api/model";
import errorHandler from "@lib/utils/error";
import { TradeMarkModel } from "../trademark-service/model";
import HDWalletProvider from "@truffle/hdwallet-provider";
import XDC3 from "xdc3";
import registrarContract from "../../contracts/RootRegistry.json";

const calculateValue = async (text, domainName, tld) => {
	if (!text) {
		return {};
	}

	let ifPremiumDomain = await PremiumDomainModel.find({
		domainName: domainName,
	});
	if (ifPremiumDomain.length > 0) {
		return { price: ifPremiumDomain[0].price, isPremium: true };
	}

	if (tld.basePrice === 0) {
		return { price: 0, isPremium: false };
	}

	let price = tld.basePrice || 50;

	let domainLength = text.length;
	let isDomainMeaningful = false;
	// await ud
	// 	.autocomplete(text)
	// 	.then((results) => {
	// 		isDomainMeaningful = true;
	// 	})
	// 	.catch((error) => {
	// 		console.error(`autocomplete (promise) - error ${error.message}`);
	// 	});

	if (domainLength < 6) {
		price = price * 1;
	} else if (domainLength < 9) {
		price = price - 15;
	} else if (domainLength < 12) {
		price = price - 20;
	} else if (domainLength < 15) {
		price = price - 25;
	} else {
		price = price - 30;
	}

	if (isDomainMeaningful) {
		price = price + 10;
	}

	return { price: price, isPremium: false };
};

export const createDomain = async (req, res) => {
	try {
		let { body } = req;
		let domain = await ProductDomainModel(body).save();
		return res.status(201).json({ data: domain });
	} catch (error) {
		return errorHandler(error, 400, res);
	}
};

const searchDomainHandler = async (domainText, tldName, domainName) => {
	let tld = await TldModel.findOne({ tldName: "." + tldName }, {});
	if(!tld){
		return {
			success:true,
			status:200,
			result:{
				available:false,
				tldMissing:true
			}
		}
	}

	let domainNameRegex = `^${domainName}$`;
	let domain = await ProductDomainModel.findOne({
		domainName: { $regex: domainNameRegex, $options: "i" },
	});
	let isAvaliable = domain ? false : true;
	if (!isAvaliable) {
		return {
			success: true,
			status: 200,
			result: { domainName, available: isAvaliable },
		};
	}
	let tradeMark = await TradeMarkModel.findOne({
		tradeMarkName: new RegExp("^" + domainText + "$", "i"),
	});

	if (tradeMark) {
		tradeMark.searchCount = tradeMark.searchCount + 1;
		await tradeMark.save();
		return {
			success: true,
			status: 200,
			result: {
				domainName,
				isDomainTradeMarked: true,
				available: true,
				price:100,
				wishlisted: false,
		        premiumObj: {},
			},
		};
		//var isTradeMarked = true
	}

	let ifDomainLocked = await LockedDomainModel.findOne({
		domainName: { $regex: domainNameRegex, $options: "i" },
	});
	if (ifDomainLocked) {
		return {
			success: true,
			status: 200,
			result: { domainName, available: false },
		};
	}
	let domainValue = await calculateValue(domainText, domainName, tld);

	//todo generate a productID
	let obj = {
		isPremium: domainValue.isPremium, // will be done on Blockchain API
		domainName,
		price: domainValue.price,
		available: isAvaliable,
		wishlisted: false,
		premiumObj: {},
	};

	return { success: true, status: 200, result: obj };
};

export const searchDomain = async (req, res) => {
	try {
		let domainText = req.query.domainName.split(".")[0];
		let tldName = req.query.domainName.split(".")[1];
		let domainName = req.query.domainName;

		const resultObj = await searchDomainHandler(
			domainText,
			tldName,
			domainName
		);

		const { success, status, result } = resultObj;
		if(result.tldMissing){
			const error = new Error("We are not serving this tld.Please choose from available one")
			return errorHandler(error,400,res)
		}
		if (!success) {
			throw new Error();
		}

		return res.status(status).json({ result });
	} catch (error) {
		return errorHandler(error, 400, res);
	}
};

export const searchDomainForMultipleTLDs = async (req, res) => {
	try {
		let domainText = req.body.domainText;

		const tldArray = await TldModel.find({
			active: true,
		});

		const domainsAvailable = [];

		for (let tld of tldArray) {
			const domainName = domainText + tld.tldName;
			const tldName = domainName.split(".")[1];

			const resultObj = await searchDomainHandler(
				domainText,
				tldName,
				domainName
			);

			const { success, result } = resultObj;

			if (success && result.available) {
				domainsAvailable.push(result);
			}
		}

		return res.status(200).json({ result: domainsAvailable });
	} catch (error) {
		return errorHandler(error, 400, res);
	}
};

export const getDomainById = async (req, res) => {
	try {
		let { id } = req.params;
		let domain = await ProductDomainModel.findById(id).populate("logId");
		return res.status(200).json({ data: domain });
	} catch (error) {
		return errorHandler(error, 400, res);
	}
};

export const deleteDomain = async (req, res) => {
	try {
		let { id } = req.params;
		let domain = await ProductDomainModel.deleteOne({ _id: id });
		return res.status(200).json({ data: domain });
	} catch (error) {
		return errorHandler(error, 400, res);
	}
};

export const updateDomain = async (req, res) => {
	try {
		let { body, params } = req;
		let { id } = params;
		let domain = await ProductDomainModel.updateOne({ _id: id }, body);
		return res.status(200).json({ data: domain });
	} catch (error) {
		return errorHandler(error, 400, res);
	}
};

export const getMyDomains = async (req, res) => {
	try {
		let userId = req.me._id;
		let domain = await ProductDomainModel.find({ userId: userId }, null, {
			sort: { _id: -1 },
		}).populate("tld logId");
		return res.status(200).json({ data: domain });
	} catch (error) {
		return errorHandler(error, 400, res);
	}
};

const xdcPrivateKey = process.env.XDC_PRIVATE_KEY;

const xdcRegistrarContractAddress = process.env.XDC_REGISTRAR_CONTRACT_ADDRESS;

export const mintDomain = async (req, res) => {
	try {
		const { order, signature, domainNetwork } = req.body;

		if (!order || !signature || !domainNetwork) {
			return res
				.status(400)
				.json({ message: "Wrong parameters provided!" });
		}

		if (domainNetwork === "xinfin") {
			const ourWalletProvider = new HDWalletProvider({
				privateKeys: [xdcPrivateKey],
				providerOrUrl: "https://rpc.xinfin.network",
				chainId: 50,
				pollingInterval: 60000,
			});

			const xdc3Instance = new XDC3(ourWalletProvider);

			const account = xdc3Instance.eth.accounts.privateKeyToAccount(
				xdcPrivateKey
			);

			xdc3Instance.eth.accounts.wallet.add(account);

			const ourWalletAddress =
				xdc3Instance.eth.accounts.wallet[0].address;

			const registrarInstance = new xdc3Instance.eth.Contract(
				registrarContract.abi,
				xdcRegistrarContractAddress
			);

			const txResponse = await registrarInstance.methods
				.mintDomain(order, signature, true)
				.send({ gas: 100000000, from: ourWalletAddress });

			const transactionHash = txResponse.transactionHash;

			if (!transactionHash) {
				throw new Error("transactionHash not found");
			}

			return res.status(200).json({ success: true, transactionHash });
		}
	} catch (error) {
		return errorHandler(error, 400, res);
	}
};
