const router = require("express").Router();
import {
	updateDomain,
	getDomainById,
	searchDomain,
	getMyDomains,
	searchDomainForMultipleTLDs,
	mintDomain,
} from "./controller";
import { domainSearch } from "./validator";

router.get("/", getMyDomains);
router.post("/search", domainSearch, searchDomain);
router.post("/searchMultipleTlds", searchDomainForMultipleTLDs);
router.post("/mint", mintDomain);
router.get("/:id", getDomainById);
router.put("/:id", updateDomain);
// router.delete("/:id", deleteDomain);
export default router;
