'use strict';
import mongoose from 'mongoose';
const objectId = mongoose.Schema.Types.ObjectId;


const walletSchema = new mongoose.Schema({
  walletAddress		                  : {type: String, required: true},
  BlockchainNetworkType		                   : {type: String, required: true},
  userId                  : {type: objectId, required: true, ref:'User'},

}, {timestamps: true, versionKey: false});

export const WalletModel = mongoose.model('wallet', walletSchema);



