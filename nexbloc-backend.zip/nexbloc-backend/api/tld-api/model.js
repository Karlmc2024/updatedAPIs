"use strict";
import mongoose from "mongoose";

const tldSchema = new mongoose.Schema({
	tldName: { type: String, required: true },
	active: { type: Boolean, required: false, default: false },
	mintable: { type: Boolean, required: false, default: false },
	network: { type: String, required: false, default: null },
	basePrice: { type: Number, required: true, default: 0 },
	visible: { type: Boolean, required: false, default: true },
	scAddress: { type: String, required: false, default: null },
});

export const TldModel = mongoose.model("Tld", tldSchema);
