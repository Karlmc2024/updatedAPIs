const Joi = require('@hapi/joi');

const mitableTld = (req, res, next) => {
    const schema = Joi.object({
        tldName:  Joi.string().required()
    });
    const {error} = schema.validate(req.params);
    if (error) {
        return res.status(400).json({error: {message:'tld name is missing'}});
    }
    next();
};


module.exports = {
    mitableTld
};



