
const router = require('express').Router();
import {getTld,isMintable} from './controller';
import {mitableTld} from  './validator';


router.get('/',getTld);
router.get('/mintable',mitableTld,isMintable);

export default router;
