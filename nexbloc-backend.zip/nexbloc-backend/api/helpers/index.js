const getTime  = (days)=>{
    const date = new Date();
    const  time =  Math.abs(date.getTime()) + (days * 24 * 60 * 60 * 1000);
    return time; 
    
};


module.exports  = {getTime};
