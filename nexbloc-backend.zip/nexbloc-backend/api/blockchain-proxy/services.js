import {ethers} from 'ethers';

export const sendTransaction = async ({address,abi, privateKey,value}) => {
  try {
    const provider = new ethers.providers.JsonRpcProvider();
    const wallet = new ethers.Wallet(privateKey,provider);
    const contract = new ethers.Contract(address,abi,wallet);
    
    const transaction = await contract.setValue(value);
    return transaction; 
  } catch (error) {
    
    throw error;
  }
};
