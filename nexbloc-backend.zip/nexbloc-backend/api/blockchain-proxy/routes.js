
const router = require('express').Router();
import {getResolveURL, getResolveAddress, createResolveAddress, createResolveURL, greeter} from './controller';

// get all cart items
// clear items
// delete one item
// add one item
router.get('/resolve-url',getResolveURL);
router.post('/resolve-url',createResolveAddress);
router.get('/resolve-address',createResolveURL);
router.post('/resolve-address',getResolveAddress);
router.post('/greeter',greeter);

export default router;
