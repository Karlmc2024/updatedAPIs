import {addToCart} from '../cart-service/services';
import {WishlistModel} from './model';
import errorHandler from '@lib/utils/error';


export const getMyWishlist = async(req,res)=>{
    try {
        let cart =  await WishlistModel.findOne({userId:req.locals.user._id});
        return res.status(200).json({result:cart});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};

// remove all items
export const clearWishlist = async(req,res)=>{
    try {
        let cart =  await WishlistModel.findByIdAndUpdate({userId:req.locals.user._id},{items:[]});
        return res.status(200).json({result:cart});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};

// add items or remove one item

export const updateWishlist = async(req,res)=>{
    try {
        let {body} = req;
        let wishlist =  await WishlistModel.findOne({userId:req.locals.user._id});
        let data =  await WishlistModel.findByIdAndUpdate({_id:wishlist._id},body,{new:true});
        return res.status(201).json({result:data});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};


export const deleteWishlistItem = async(req,res)=>{
    try {
        let {itemId} = req.params;
        let wishlist =  await WishlistModel.findOne({userId:req.locals.user._id});
        let index = wishlist.items.findIndex(item=>item._id.toString() === itemId);
        if (index > -1){
          wishlist.items.splice(index,1);
          
            let data =  await WishlistModel.findByIdAndUpdate({_id:wishlist._id},wishlist, {new:true});
            return res.status(201).json({result:data});
        }
        return res.status(200).json({result:wishlist});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};

export const addItemToWishlist = async(req,res)=>{
    try {
        let {body} = req;
        let {domainName} = body;
        let wishlist =  await WishlistModel.findOne({userId:req.locals.user._id});
        let index = wishlist.items.findIndex(item=>item.domainName.toString() === domainName);
        if (index === -1){
          wishlist.items.push(body);
            let data =  await WishlistModel.findByIdAndUpdate({_id:wishlist._id},wishlist, {new:true});
            return res.status(201).json({result:data});
        }
        return res.status(200).json({result:wishlist});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};

export const moveToCart = async(req,res)=>{
    try {
        let {itemId} = req.params;
        let userId = req.locals.user._id;
        let wishlist =  await WishlistModel.findOne({userId});
        let index = wishlist.items.findIndex(item=>item._id.toString() === itemId);
        if (index > -1){
            const newCart = await addToCart({userId,domain:wishlist.items[index]});
            wishlist.items.splice(index,1);
            let data =  await WishlistModel.findByIdAndUpdate({_id:wishlist._id},wishlist, {new:true});
            data = data.toJSON()
            const {items} = newCart;
            return res.status(201).json({result:{cartItems:items,...data}});
        }
        return res.status(200).json({result:wishlist});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};
