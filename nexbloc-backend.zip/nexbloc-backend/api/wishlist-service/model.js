'use strict';
import mongoose from 'mongoose';
const objectId = mongoose.Schema.Types.ObjectId;

const itemSchema = new mongoose.Schema({
    domainName: {type: String,required: true},
    productId: {type: objectId, required: false},
    price: {type: Number,default:true}
});

const WishlistSchema = new mongoose.Schema({
  items                 : [itemSchema],
  userId                : {type: objectId, required: false,unique:true, ref:'User'}
}, {timestamps: true, versionKey: false});

export const WishlistModel = mongoose.model('Wishlist', WishlistSchema);
