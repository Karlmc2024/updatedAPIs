import {WishlistModel} from './model';

export const createWishlist = (userId) => {
  const cart = {
      userId,
      items: [],
      totalQuantity: 0,
      totalCost:0
  };
  return WishlistModel.create(cart);
};

export const addToWishlist = async({userId,domain})=>{
  const {domainName} = domain;
  let wishlist =  await WishlistModel.findOne({userId});
      let index = wishlist.items.findIndex(item=>item.domainName.toString() === domainName);
      if (index === -1){
        wishlist.items.push(domain);
          let data =  await WishlistModel.findByIdAndUpdate({_id:wishlist._id},wishlist, {new:true});
          return data;
      }
  return wishlist;
};
