"use strict";

import errorHandler from "@lib/utils/error";
import {
	ProductDomainModel,
	DomainHistoryModel,
	DomainTransferModel,
} from "../model";

export const createDomainTransferRequest = async (req, res) => {
	try {
		let { body } = req;

		body.userId = req.locals.user._id;
		body.status = "pending";

		// same user can not request domain transfer to multiple users
		let verify = await DomainTransferModel.find(
			{
				userId: body.userId,
				domain: body.domain,
				status: { $nin: ["rejected", "completed"] },
			},
			{}
		);

		if (verify.length > 0) {
			return res.status(400).json({
				error: "This domain transfer request is already pending",
			});
		}

		let request = await DomainTransferModel(body).save();
		return res.status(201).json({ result: request });
	} catch (error) {
		return errorHandler(error, 400, res);
	}
};

export const getDomainTransferRequest = async (req, res) => {
	try {
		//todo pagination
		let sentRequests = await DomainTransferModel.find(
			{ userId: req.locals.user._id },
			{}
		).populate([
			{
				path: "receiverId",
				select: ["firstName", "lastName", "email"],
			},
			{
				path: "domain",
				select: ["domainName", "domainOwner", "logId"],
				populate: { path: "logId", select: "transactionStatus" },
			},
		]);

		let receivedRequests = await DomainTransferModel.find(
			{ receiverId: req.locals.user._id },
			{}
		).populate([
			{
				path: "userId",
				select: ["firstName", "lastName", "email"],
			},
			{
				path: "domain",
				select: ["domainName"],
			},
		]);

		let data = { sentRequests, receivedRequests };

		return res.status(200).json({ result: data });
	} catch (error) {
		return errorHandler(error, 400, res);
	}
};

export const getDomainTransferRequestById = async (req, res) => {
	try {
		let data = await DomainTransferModel.find({ _id: req.params.id }, {});
		return res.status(200).json({ result: data });
	} catch (error) {
		return errorHandler(error, 400, res);
	}
};

//todo Domain update function

export const updateDomainOwner = async (id) => {
	let domainTransferInfo = await DomainTransferModel.findOne({ _id: id }, {});

	let domainInfo = await ProductDomainModel.findOne(
		{ _id: domainTransferInfo.domain },
		{}
	);

	let history = {};
	history.domainId = domainTransferInfo.domain;
	history.domainOwner = domainInfo.domainOwner;
	history.userId = domainTransferInfo.userId;

	if (domainInfo && domainInfo.userId) {
		let obj = {};
		obj.domainOwner = domainTransferInfo.receiverWalletAddress;
		obj.userId = domainTransferInfo.receiverId;
		await ProductDomainModel.findByIdAndUpdate(domainInfo._id, obj);
		await DomainHistoryModel(history).save();
	}
};

export const updateDomainTransferRequest = async (req, res) => {
	try {
		const { id } = req.params;
		const { status, receiverWalletAddress } = req.body;
		let body = {};
		body.status = status;
		if (status === "accepted") {
			body.receiverWalletAddress = receiverWalletAddress;
		}

		// TODO: we have to sync transfer with blockchain
		if (status === "completed") {
			let updateOwner = await updateDomainOwner(id);
		}

		await DomainTransferModel.findByIdAndUpdate(id, body);
		return res.status(200).json({ result: { success: true } });
	} catch (error) {
		return errorHandler(error, 400, res);
	}
};

export const deleteDomainTransferRequest = async (req, res) => {
	try {
		const { id } = req.params;

		await DomainTransferModel.findByIdAndDelete(id);
		return res.status(200).json({ result: { success: true } });
	} catch (error) {
		return errorHandler(error, 400, res);
	}
};
