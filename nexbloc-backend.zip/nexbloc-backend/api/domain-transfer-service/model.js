"use strict";
import mongoose from "mongoose";
import { UserModel } from "../user-service/model";
import { ProductDomainModel } from "../domain-service/model";
const objectId = mongoose.Schema.Types.ObjectId;

const DomainTransferSchema = new mongoose.Schema(
	{
		userId: { type: objectId, required: true, ref: "User" },
		receiverId: { type: objectId, required: true, ref: "User" },
		receiverWalletAddress: { type: String, required: false,default:'0x0' },
		status: {
			type: String,
			required: true,
			enum: ["pending", "rejected", "accepted", "completed"],
			default: "pending",
		},
		domain: { type: objectId, required: true, ref: "ProductDomain" },
		createdAt: {
			type: Date,
			default: Date.now,
		},
	},
	{ timestamps: true, versionKey: false }
);

export const DomainTransferModel = mongoose.model(
	"DomainTransfer",
	DomainTransferSchema
);
