const Joi = require("@hapi/joi");

const validateDomainTransferRequest = (req, res, next) => {
	const schema = Joi.object({
		domain: Joi.string().required(),
		receiverId: Joi.string().required(),
	});

	let { error } = schema.validate(req.body);
	if (error && error.details) {
		const { details } = error;
		const message = details.map((i) => i.message).join(",");
		return res.status(400).json({ error: message });
	}
	next();
};

const validateUpdateDomainTransferRequest = (req, res, next) => {
	const validStatus = ["pending", "rejected", "accepted", "completed"];

	const schema = Joi.object({
		domain: Joi.string().optional(),
		receiverId: Joi.string().optional(),
		receiverWalletAddress: Joi.string().optional(),
		status: Joi.string()
			.valid(...validStatus)
			.required(),
	});

	let { error } = schema.validate(req.body);

	if (error && error.details) {
		const { details } = error;
		const message = details.map((i) => i.message).join(",");
		return res.status(400).json({ error: message });
	}
	next();
};

const params = (req, res, next) => {
	const schema = Joi.object({
		id: Joi.string().required(),
	});
	const { error } = schema.validate(req.params);
	if (error) {
		return res.status(400).json({
			error: { message: "Domain transfer request id is missing" },
		});
	}

	next();
};

module.exports = {
	validateDomainTransferRequest,
	validateUpdateDomainTransferRequest,
	params,
};
