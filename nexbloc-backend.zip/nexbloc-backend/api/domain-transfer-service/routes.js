const router = require("express").Router();
import {
	createDomainTransferRequest,
	deleteDomainTransferRequest,
	getDomainTransferRequest,
	getDomainTransferRequestById,
	updateDomainTransferRequest,
} from "./controller";

import {
	validateDomainTransferRequest,
	validateUpdateDomainTransferRequest,
	params,
} from "./validator";

router.post("/", validateDomainTransferRequest, createDomainTransferRequest);
router.get("/", getDomainTransferRequest);
router.get("/:id", getDomainTransferRequestById);
router.put(
	"/:id",
	params,
	validateUpdateDomainTransferRequest,
	updateDomainTransferRequest
);
router.delete("/:id", params, deleteDomainTransferRequest);

export default router;
