'use strict';
import mongoose from 'mongoose';
const objectId = mongoose.Schema.Types.ObjectId;

const ForgotPasswordSchema = new mongoose.Schema({
  userId: {type: objectId, ref: 'User'},
  token: {type: String, required: true},
  createdAt: {
    type: Date,
    default: Date.now,
    expires: 3600,
  },
}, {timestamps: true, versionKey: false});

export const ForgotPasswordModel = mongoose.model('ForgotPassword', ForgotPasswordSchema);


