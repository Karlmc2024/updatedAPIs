const router = require("express").Router();
const {
	validateUserSignUp,
	validateUserLogin,
	verifyAccount,
} = require("./validator");
const { UserController } = require("@api/controllers");
const { profilePicUpload } = require("../../lib/utils/upload");
const { validate } = require("./apivalidator");

router.post("/signup", validateUserSignUp, UserController.userSignup);
router.post("/login", validateUserLogin, UserController.userLogin);
router.get(
	"/verify-account/:userId/:token",
	verifyAccount,
	UserController.verifyAccount
);
router.get("/verify", UserController.verify);
router.put("/user", UserController.userUpdate);
router.post("/find-user", UserController.findUserByEmail);
router.get("/user", UserController.userProfile);
router.put("/enabletwofa", UserController.enableTwoFactorAuth);
router.post("/twofalogin", UserController.multiFactorLogin);
router.put(
	"/reset-password/:userId/:token",
	verifyAccount,
	UserController.resetPassword
);
router.put("/change-password", UserController.changePassword);
router.post("/forgot-password", UserController.forgotPassword);
router.post("/resend-verification-email", UserController.resendVerifyEmail);

router.post("/google-signup", UserController.googleSignup);

router.post("/google-login", UserController.googleLogin);

router.put(
	"/set-profile-pic",
	profilePicUpload,
	UserController.updateProfilePic
);

router.get("/get-profile-pic", profilePicUpload, UserController.getProfilePic);

module.exports = router;
