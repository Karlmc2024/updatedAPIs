import {CreditModel} from '../credit-system/model';
const jwt = require('jsonwebtoken');
import {CartModel} from '../cart-service/model';

const generateAccessToken = (payload)=>{
    return     jwt.sign(payload, process.env.TOKEN_SECRET, {
        algorithm: 'HS256',
        expiresIn: process.env.JWT_TOKEN_EXPIRY_MIN
    });
  };

const addNexbToeknsOnSignup = async(userId)=>{
    try {

        let obj = {};
        obj.userId = userId;
        obj.amount = 0;
        obj.nexbTokens = 50;
        const transaction  = {
            purchasedCredit: 0,
            allocatedTokens: 50,
            status:'custom',
            influencer:'none',
            transactionHash: ''
        };

        await CreditModel.findOneAndUpdate({userId:userId},{...obj ,
            $push:{
                transactionHistory:transaction
            }
        },{upsert:true, new : true});

    } catch (error) {
        logger.error(error);
    }
};


const getLoginDetails = async(user)=>{
  let cart = await CartModel.findOne({userId:user._id});
  cart = cart.toJSON();
  user = user.toJSON();
  delete user.password;
  delete user.emailVerifyUrl;
  user.cartId = cart._id;
  const token = generateAccessToken({_id:user._id, email:user.email});
  return {token,user};
};

  module.exports = {
    generateAccessToken,
    getLoginDetails,
    addNexbToeknsOnSignup
    
  };
