"use strict";
import mongoose from "mongoose";
const bcrypt = require("bcrypt");
const crypto = require("crypto-js");
const objectId = mongoose.Schema.Types.ObjectId;

const UserSchema = new mongoose.Schema(
	{
		firstName: { type: String, required: true },
		lastName: { type: String, required: true },
		profilePicUrl: { type: String, required: false },
		twoFA: { type: Boolean, required: false },
		secretKey: {
			secret: String,
			required: false,
			authenticated: {
				type: Boolean,
				default: false,
			},
		},
		phone: { type: Number, required: false, unique: false, default: false },
		email: {
			type: String,
			unique: true,
			lowercase: true,
			trim: false,
			required: true,
		},
		password: { type: String, required: true },
		verified: { type: Boolean, default: false },
		address: [],
		emailVerifyUrl: { type: String },
		emailNotifications: { type: Boolean, default: false },
		newsLetterSubscribed: { type: Boolean, default: false },
		secretTwoFactor: { type: String, required: false },
		firstLogin: { type: Boolean, default: true },
	},
	{ timestamps: true, versionKey: false }
);

UserSchema.pre("save", async function(next) {
	//Replace the plain text password with the hash
	let salt = await bcrypt.genSalt(parseInt(process.env.HASH_COST));
	this.password = await bcrypt.hash(this.password, salt);
	next();
});
UserSchema.pre("save", async function(next) {
	if (this.twoFA) {
		this.secretTwoFactor = crypto.AES.encrypt(
			this.secretTwoFactor,
			"secret key for crypto"
		).toString();
	}
	next();
});

UserSchema.methods.isValidPassword = async function(password) {
	const doc = await this.model("User").findOne({ _id: this._id }, "password");
	return await bcrypt.compare(password, doc.password);
};

UserSchema.methods.getOriginalSecretTwoFA = async function(key) {
	const bytes = crypto.AES.decrypt(key, "secret key for crypto");
	const originalText = bytes.toString(crypto.enc.Utf8);
	return originalText;
};

export const UserModel = mongoose.model("User", UserSchema);
