const {ReferModel} = require('../refer-service/model');
const  {ErrorHandler} = require('../handler/error');

const validateIsReferjoin = async (req, res, next)=>{
    try {
        if (req.body.referId ){
            const validReferid  = await ReferModel.findOne({_id : referId});
            if (validReferid){
                next();
            } else {
                return ErrorHandler({message :'Invalid Refer Id'}, res); 
            }
        } else {
            next();
        }

    } catch (error){
        return ErrorHandler(error, res);
    }
};

module.exports  = {validateIsReferjoin};
