'use strict';
import mongoose from 'mongoose';
const uniqueValidator = require('mongoose-unique-validator');
const objectId = mongoose.Schema.Types.ObjectId;
const AssetsSchema = new mongoose.Schema(
  {
    domainName: {type: String, required: true},
    domainId:{type: objectId, ref:"ProductDomain",required: true},
    userId: {type: String, required: true},
    resolveType: {type: String, required: true,enum:['ipfs_url','BTC','ETH','XDC','website_url']},
    resolveString: {type: String, required: true},
    assetOf:{type: String, required: false},
    parentId:{type:String}
  },
  {timestamps: true, versionKey: false}
);

AssetsSchema.plugin(uniqueValidator, {
  message: 'Duplicate Entry {PATH}',
});
export const AssetsModel = mongoose.model(
  'Assets',
  AssetsSchema
);
