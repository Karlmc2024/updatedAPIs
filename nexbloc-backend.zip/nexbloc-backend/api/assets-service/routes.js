const router = require('express').Router();
import {createAsset,updateAddressAsset,getAddressAssetOfDomain,getSingleAsset,getAssetByResolveType} from "./controller"
import {createAssetValidator,updateAssetValidator} from "./validator"
router.post('/domain',createAssetValidator,createAsset)
router.get('/domain/:domainId',getAddressAssetOfDomain)
router.get('/type/:domainId',getAssetByResolveType)
router.get('/:assetId',getSingleAsset)
router.put('/:assetId',updateAssetValidator,updateAddressAsset)
export default router;