import {AssetsModel} from './model';

import {ProductDomainModel} from '../domain-service/model';
import errorHandler from '@lib/utils/error';


// const PinataService = require('../domain-service/services/PinataService');


// export const addAssets = async (req, res) => {
//   try {
//     let {body} = req;
//     let domain = await OrderModel(body).save();
//     return res.status(201).json({data: domain});
//   } catch (error) {
//     return errorHandler (error,400,res);
//   }
// };


//create Assets
   export const createAsset = async(req,res) => {
    try{
        const body ={...req.body}
        const domainId = body.domainId;
        const domain = await ProductDomainModel.findById(domainId)
        const isAssetExist = await AssetsModel.findOne({domainId,resolveType:body.resolveType})
        if(isAssetExist){
            const error = new Error(`${body.resolveType} already exist for this domain.Please update the existing one`)
            return errorHandler(error,400,res)
        }
        const assetObj = {
            resolveType:body.resolveType,
            resolveString:body.resolveString,
            userId:req.me._id,
            domainName:domain.domainName,
            domainId
        };
        const asset = await AssetsModel.create(assetObj);
        return res.status(200).json({
            result:asset
        })

      
   }
   catch(error){
        return errorHandler(error,400,res)
    }
}


//update Assets
 export const updateAddressAsset = async (req,res,next) => {
    try{
        const {assetId} = req.params;
        if(!assetId){
        const error = new Error("Please provide assetId");
        return errorHandler(error,400,res)
        }
        const updatedAsset = await AssetsModel.findByIdAndUpdate(assetId,req.body,{new:true})
        return res.status(200).json({result:updatedAsset})
    }
    catch(error){
        return errorHandler(error,400,res)
    }
}


//get Crypto Address of a domain

export const getAddressAssetOfDomain = async(req,res,next) => {
    try{
        const {domainId} = req.params;
        if(!domainId){
            const error = new Error("Please provide domain Id");
            return errorHandler(error,400,res)
        }
        const assets = await AssetsModel.find({domainId,resolveType:{$nin :["ipfs_url","website_url"]}})
        return res.status(200).json({result:assets})
    }
    catch(error){
        return errorHandler(error,400,res)
    }
}

//get Asset Detail
export const getSingleAsset = async (req,res,next) => {
    try{
        const {assetId} = req.params;
        if(!assetId){
            const error = new Error("Please provide asset id");
            return errorHandler(error,400,res)
        }
        const asset = await AssetsModel.findById(assetId);
        if(!asset){
            const error = new Error("No such assets exist");
            return errorHandler(error,400,res)
        }
        return res.status(200).json({result:asset})
    }
    catch(error){
        return errorHandler(error,400,res)
    }
}

export const getAssetByResolveType = async(req,res,next) => {
    try{
        const domainId = req.params.domainId;
        const resolveType = req.query.type
        if(!domainId){
            const error = new Error("Please provide domain Id");
            return errorHandler(error,400,res)
        }
        if(!resolveType){
            const error =new Error("Please provide type of asset")
            return errorHandler(error,400,res)
        }
        const asset = await AssetsModel.findOne({domainId,resolveType})
        if(!asset){
            return res.status(200).json({success:false,message:"No such asset exist for this domain"})
        }
        return res.status(200).json({success:true,result:asset})    
    }
    catch(error){
        return errorHandler(400,error,res)
    }
}