const joi = require('@hapi/joi');
const WAValidator = require('multicoin-address-validator');

export const createAssetValidator = (req, res, next) => {
  try{
        const schema = joi.object({
            resolveString: joi.string().required(),
            resolveType:joi.string().required(),
            domainId:joi.string().required(),
        }
        );
        const {error} = schema.validate(req.body);
        if (error) {
            return res.status(400).json({ message: error.message });
        }
        if(["BTC","ETH","XDC"].includes(req.body.resolveType)){
        const validWalletAddress = WAValidator.validate(req.body.resolveString,req.body.resolveType)
        console.log(validWalletAddress)
            if(!validWalletAddress){
                return res.status(400).json({message:"Wallet Address is Invalid"})
            }
        }
        next();
    }
    catch(e){
        console.log(e)
    }
};

export const updateAssetValidator = (req,res,next) => {
    try{
        const schema = joi.object({
            resolveString: joi.string().required(),
            resolveType:joi.string().required(),
        }
        );
        const {error} = schema.validate(req.body);
        if (error) {
            return res.status(400).json({ message: error.message });
        }
        if(["BTC","ETH","XDC"].includes(req.body.resolveType)){
        const validWalletAddress = WAValidator.validate(req.body.resolveString,req.body.resolveType)
        console.log(validWalletAddress)
            if(!validWalletAddress){
                return res.status(400).json({message:"Wallet Address is Invalid"})
            }
        }
        next();
    }
    catch(e){
        console.log(e)
    }
}


