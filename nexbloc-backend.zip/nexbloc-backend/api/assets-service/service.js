// import {AssetsModel} from './model';

// export const addAssets = async (data) => {
//       let asset = await AssetsModel(data).save();
//       return asset;
// };
