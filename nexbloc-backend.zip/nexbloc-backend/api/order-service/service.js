import { OrderModel } from './model';
import { UserModel, DiscountModel } from '@api/model';
import { date } from '@hapi/joi';
export const checkIfDomainIsAlreadyBought = (domainName) => {
  return OrderModel.findOne({ 'cart.items.domainName': domainName });
};

export const GetautoApplyCoupon = async () => {
  try {
    const availableCoupons = await DiscountModel.find({});
    if (availableCoupons.length > 0) {
      let coupons = availableCoupons.sort((a, b) => b.discount - a.discount).sort((a, b) => b.applyAuto - a.applyAuto);
      if (coupons.length) {
        const autoapplyCoupon = coupons.find((ele) => ele.applyAuto === true);
        if (autoapplyCoupon) {

          return autoapplyCoupon;
        }

      }
    }
    return null;
  } catch (error) {
    return null;
  }

}