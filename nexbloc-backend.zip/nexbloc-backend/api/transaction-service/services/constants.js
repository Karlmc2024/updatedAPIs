module.exports = {
  paymentStatus: {
    CREATED: 'created',
    CANCELED: 'canceled',
    CONFIRMED: 'confirmed',
    FAILED: 'failed',
    DELAYED: 'delayed',
    PENDING: 'pending',
    PROCESSING: 'processing',
    REQUIRES_ACTION: 'requires_action',
  },
  stripe_key: process.env.STRIPE_SECRET_KEY
    ? process.env.STRIPE_SECRET_KEY
    : 'sk_test_51KgMm6SEY531WZgM0B7jUxpGrvKJ7Dhjk5GGDw6XkxPGyjeLMrbuHVEPa5QtD57fsHW0vpmJD8BWsclA0ORMMDsY009NFVN3w8',

  stripe_webhook_secret: process.env.stripe_webhook_secret
    ? process.env.stripe_webhook_secret
    : '',
  coinbase_key: process.env.coinbase_key
    ? process.env.coinbase_key
    : 'd7d3a404-1b18-4c7d-ad8d-056bacd47c2e',
  coinbaseWebhookSecret: process.env.coinbaseWebhookSecret
    ? process.env.coinbaseWebhookSecret
    : '349c87da-fee6-46c6-8915-fc5340e6d5c4',
  paypal_key: process.env.paypal_key ? process.env.paypal_key : '',
};
