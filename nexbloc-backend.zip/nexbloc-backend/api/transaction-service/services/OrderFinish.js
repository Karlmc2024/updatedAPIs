/* eslint-disable semi */
/* eslint-disable max-statements */
import {OrderModel} from '../../order-service/model';
import {ProductDomainModel} from '../../domain-service/model';
import {PremiumDomainModel} from '../../premium-domain/model';
import {TransactionModel} from '../model';
import {LockedDomainModel} from '../../order-service/model';
import {UserModel} from '../../user-service/model';

import {cancelScheduleCartMailer} from '@lib/utils/scheduler';
import sendOrderConfirmation from '@lib/utils/orderConfirmation';
import {CartModel} from '../../cart-service/model';
import {trademarkRequestModel } from '@api/model';

const transactionOrderStatusMapping = {
  confirmed: 'paymentDone',
  failed: 'paymentFailed',
  cancelled: 'paymentFailed',
};

module.exports = async ({txHash, status}) => {
  try {
    if (!txHash) {
return
}
    let transaction = await TransactionModel.findOne({txHash}).exec();
    let order = await OrderModel.findOneAndUpdate(
        {_id: transaction.orderId},
        {
          $set: {
            status: transactionOrderStatusMapping[status]
                ? transactionOrderStatusMapping[status]
                : 'paymentStarted',
          },
        }
    );
    if (status === 'confirmed') {
      let domains = order.cart.items.map( (domain) => ({
        domainName: domain.domainName,
        domainOwner: domain.domainOwner,
        purchaseDate: new Date(),
        userId: order.userId,
        orderId: order._id,
        productId: domain._id,
        tld: domain.tld
      }));
      await ProductDomainModel.insertMany(domains);
      let domainNames = domains.map((d) => d.domainName);
      try{
        await trademarkRequestModel.updateMany({domainName:{$in:domainNames}},{$set:{status:'completed'}})
      }
      catch(e){
        console.log("error while updating trademark status in transactions -->")
        console.log(e.message)
      }
      await PremiumDomainModel.updateMany({domainName: {$in: domainNames}}, {$set: {soldOut: true}});

      await LockedDomainModel.deleteMany({orderId: transaction.orderId});
      await cancelScheduleCartMailer(order.userId);

    // await CartModel.findOneAndUpdate(
    //   {currentOrderId: order._id},
    //   {
    //     $set: {
    //       items: [],
    //       totalQuantity: 0,
    //       totalCost: 0,
    //       currentOrderId: null,
    //     },
    //   }
    // );
      let {firstName, lastName, email} = await UserModel.findOne({_id: order.userId});
      await sendOrderConfirmation({
        name: firstName + ' ' + lastName,
        orderId: order._id,
        price: transaction.currency.toUpperCase() + ' ' + order.finalAmount
      },null,email);
    }
    return;
  } catch (e) {
    
    logger.error(e,'transaction confirmation');
  }
};
