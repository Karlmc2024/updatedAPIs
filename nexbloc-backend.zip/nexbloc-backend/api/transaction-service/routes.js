const router = require('express').Router();
import {
  createTransaction,
  updatePaypalTransaction,
  getTransactionById,
  deleteTransaction,
  updateTransaction,
  coinBaseWebhook,
  stripeWebhook,
  paypalWebhook,
  paymentStatusSubscribe,
  testEvent,
  getTotalTransaction
} from './controller';

const {CoinbaseService} = require('./services');

router.get('/');
router.post('/', createTransaction);
router.get('/paymentStatusSubscribe/:txHash', paymentStatusSubscribe);
router.get('/test/:id/:status', testEvent);
router.post('/updatePaypal/:transactionId', updatePaypalTransaction);
router.get('/total', getTotalTransaction);
router.get('/:id', getTransactionById);
router.put('/:id', updateTransaction);
router.delete('/:id', deleteTransaction);
router.post('/coinbase-webhook', CoinbaseService.parseHook, coinBaseWebhook);
router.post('/stripe-webhook', stripeWebhook);
// router.post('/paypal-webhook', paypalWebhook);

export default router;
