import { TransactionModel } from './model';
import { OrderModel } from '../order-service/model';
import { CartModel as CartModelTrue } from '../cart-service/model';
import errorHandler from '@lib/utils/error';
import { cancelScheduleCartMailer } from '@lib/utils/scheduler';

import { ProductDomainModel } from '../domain-service/model';
import { LockedDomainModel } from '../order-service/model';
import { burnCredits, creditHistoryStatus } from '../credit-system/services';

const {
  CoinbaseService,
  StripeService,
  PaypalService,
  OrderFinish,
} = require('./services');
const { stripe_key, paymentStatus } = require('./services/constants');
const stripe = require('stripe')(stripe_key);

const events = require('events');
var eventEmitter = new events.EventEmitter();

export const createTransaction = async (req, res) => {
  try {
    let transaction_info = null;
    let transaction_id = null;
    let status = null;
    let { body } = req;
    let { paymentGateway, orderId } = body;
    let order = await OrderModel.findById(orderId);
    if (!order) {
      res.status(404).json({
        error: 'Order Details Not Found'
      });
    }

    if(paymentGateway === "zeroPayment") {
      if(order.finalAmount !== 0) {
        return errorHandler({error: "Payment method not supported"}, 400, res);
      }
    }

    const { cart } = order;
    let blockedDomain = [];
    let domainBlockCheck = cart.items.map(async item => {
      let domainNameRegex = `^${item.domainName}$`;
      let domain = await ProductDomainModel.findOne({ domainName: { '$regex': domainNameRegex, '$options': 'i' } });
      let isAvaliable = domain ? false : true;
      if (!isAvaliable) {
        return item.domainName;
      }

      let ifDomainLocked = await LockedDomainModel.findOne({ domainName: { '$regex': domainNameRegex, '$options': 'i' } });
      if (ifDomainLocked && ifDomainLocked.userId.toString() != req.me._id.toString()) {
        return item.domainName;
      }
      return null;
    })

    for await (let val of domainBlockCheck) {
      if (val) {
        blockedDomain.push(val)
      }
    }

    if (blockedDomain.length > 0) {
      return errorHandler({ "error": blockedDomain.join(',') + " not available now" }, 400, res);
    }
    switch (paymentGateway) {
      case 'coinbase':
        transaction_info = await CoinbaseService.charge({
          name: 'Domain Purchase ',
          description: 'Transaction for domain purchase -' + orderId,
          local_price: {
            amount: order.finalAmount,
            currency: cart.currency,
          },
          pricing_type: 'fixed_price',
          metadata: {
            user: req.locals.user,
          },
        });
        transaction_id = transaction_info.id;
        break;
      case 'stripe':
        const customer = await stripe.customers.create({
          name: req.me.firstName + ' ' + req.me.lastName,
          address: req.me.resAddress
        });
        transaction_info = await stripe.paymentIntents.create({
          amount: order.finalAmount *100, //fo usd it take value in cents
          currency: cart.currency ,
          customer:customer.id,
          description: 'Software as services',
          payment_method_types: ['card'],
        });

        transaction_id = transaction_info.id;
        break;
      case 'paypal':
        transaction_info = {};
        transaction_id = '';
        break;
      case 'zeroPayment':
        transaction_info = {};
        transaction_id = new Date().getTime();
        break;
      case 'credits':
        transaction_info = await burnCredits(order.finalAmount, orderId, req, res);
        transaction_id = transaction_info.creditUsesHistory[transaction_info.creditUsesHistory.length - 1]._id;
        break;
    }

    let domain = await TransactionModel({
      userId: req.me._id,
      amount: order.finalAmount,
      currency: cart.currency,
      paymentMode: paymentGateway,
      txHash: transaction_id,
      status: (paymentGateway == 'zeroPayment' || paymentGateway == 'credits' ) ? 'paymentDone' : 'initiated',
      paymentStatus: (paymentGateway == 'zeroPayment' || paymentGateway == 'credits' ) ? 'confirmed' : 'created',
      transactionDate: new Date().getUTCDate(),
      orderId: orderId,
      transactionInfo: transaction_info,
      itemsStatus: [],
    }).save();
    await OrderModel.updateOne(
      { _id: orderId },
      {
        $set: {
          status:
              (paymentGateway == 'zeroPayment' || paymentGateway == 'credits' )? 'paymentDone' : 'paymentStarted',
          transactionId: domain._id,
        },
      }
    );
    await CartModelTrue.findOneAndUpdate(
      { currentOrderId: orderId },
      {
        $set: {
          items: [],
          totalQuantity: 0,
          totalCost: 0,
          currentOrderId: null,
        },
      }
    );
    cancelScheduleCartMailer(req.me._id);
    await res.status(201).json({ data: domain });

    if (paymentGateway == 'zeroPayment' || paymentGateway == 'credits') {
      await OrderFinish({
        txHash: domain.txHash,
        status: 'confirmed',
      });
      setTimeout(function () {
        eventEmitter.emit('paymentStatusChanged', {
          txHash: domain.txHash,
          status: 'confirmed',
        });
      }, 500);
    }
    return;
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

export const updatePaypalTransaction = async (req, res) => {
  try {
    let { transactionInfo } = req.body;
    let { transactionId } = req.params;

    let txHash = transactionInfo.purchase_units[0].payments.captures[0].id;
    let paymentStatus = PaypalService.events['CHECKOUT.ORDER.APPROVED'];

    let domain = await TransactionModel.updateOne(
      { _id: transactionId },
      {
        $set: {
          transactionInfo,
          txHash,
          paymentStatus,
          status: 'paymentStarted',
        },
      }
    );
    return res.status(200).json({ data: domain });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

export const getTransactionById = async (req, res) => {
  try {
    let { id } = req.params;
    let domain = await TransactionModel.findById(id);
    return res.status(200).json({ data: domain });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

export const deleteTransaction = async (req, res) => {
  try {
    let { id } = req.params;
    let domain = await TransactionModel.deleteOne({ _id: id });
    return res.status(200).json({ data: domain });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

export const getTotalTransaction = async (req, res) => {
  try {
    let total = await TransactionModel.aggregate([{
      $match: {
        $and: [
          { userId: req.locals.user._id },
          { paymentStatus: "confirmed" }
        ]
      }
    },
      { $group: { _id: 12, sum: { $sum: "$amount" } } }]);

    if(total.length > 0){
      return res.status(200).json({ result : {total:'$'+ total[0].sum }});
    }

    return res.status(200).json({ result: {total:0} });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

export const updateTransaction = async (req, res) => {
  try {
    let { body, params } = body;
    let { id } = params;
    let domain = await TransactionModel.updateOne({ _id: id }, body);
    return res.status(200).json({ data: domain });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

export const coinBaseWebhook = async (req, res) => {
  try {
    const transactionId = req.body.event.data.id
    const transaction = await TransactionModel.findOneAndUpdate(
      { txHash: req.body.event.data.id },
      {
        $set: {
          paymentStatus: CoinbaseService.events[req.body.event.type],
          status:
            CoinbaseService.events[req.body.event.type] ===
              paymentStatus.CONFIRMED
              ? 'paymentDone'
              : 'paymentStarted',
        },
      }
    );
    if (transaction && transaction.orderId) {
      await OrderFinish({
        txHash: req.body.event.data.id,
        status: CoinbaseService.events[req.body.event.type],
      });
    } else {
      await creditHistoryStatus(transactionId, CoinbaseService.events[req.body.event.type]);
    }
    eventEmitter.emit('paymentStatusChanged', {
      txHash: req.body.event.data.id,
      status: CoinbaseService.events[req.body.event.type]
    });

    return res.status(200).json({});
  } catch (e) {
    return errorHandler(e, 400, res);
  }
};

// bodyParser.raw({ type: "application/json" }),
export const stripeWebhook = async (req, res) => {
  try {
    let event = req.body;
    const transaction =  await TransactionModel.findOneAndUpdate(
      { txHash: event.data.object.payment_intent },
      {
        $set: {
          paymentStatus: StripeService.events[event.type],
          status:
            StripeService.events[event.type] === paymentStatus.CONFIRMED
              ? 'paymentDone'
              : 'paymentStarted',
        }
      }

    );


    if (transaction && transaction.orderId) {

      await OrderFinish({
        txHash: event.data.object.payment_intent,
        status: StripeService.events[event.type],
      });
    } else {
      await creditHistoryStatus(event.data.object.payment_intent, StripeService.events[event.type]);
    }


    eventEmitter.emit('paymentStatusChanged', {
      txHash: event.data.object.payment_intent,
      status: StripeService.events[event.type],
    });

    res.json({ received: true });

  } catch (e) {
    return errorHandler(e, 400, res);
  }
};

export const paypalWebhook = async (req, res) => {
  try {
    let event = req.body;
    await TransactionModel.findOneAndUpdate(
      { txHash: event.resource.id },
      {
        $set: {
          paymentStatus: PaypalService.events[event.event_type],
          status:
            PaypalService.events[event.event_type] === paymentStatus.CONFIRMED
              ? 'paymentDone'
              : 'paymentStarted',
        },
      }
    );
    await OrderFinish({
      txHash: event.resource.id,
      status: PaypalService.events[event.event_type],
    });
    eventEmitter.emit('paymentStatusChanged', {
      txHash: event.resource.id,
      status: PaypalService.events[event.event_type],
    });
    return res.status(200).json({});
  } catch (e) {
    return errorHandler(e, 400, res);
  }
};

export const paymentStatusSubscribe = (req, res) => {
  try {
    let thisRes = res;
    eventEmitter.on('paymentStatusChanged', ({ status, txHash }) => {
      try {
        if (status == 'confirmed' && req.params.txHash === txHash) {
          thisRes.json({ data: status });
          // res.end();
        }
      } catch (e) {
        return errorHandler(e, 400, res);

      }
    });
  } catch (e) {
    res.end();
  }
};

export const testEvent = (req, res) => {
  eventEmitter.emit('paymentStatusChanged', {
    txHash: req.params.id,
    status: req.params.status,
  });
  res.send('Done');
};
