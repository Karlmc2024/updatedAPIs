'use strict';
import mongoose from 'mongoose';
const objectId = mongoose.Schema.Types.ObjectId;
const mixed = mongoose.Mixed;

const TransactionSchema = new mongoose.Schema(
  {
    userId: {type: objectId, required: true, ref: 'User'},
    amount: {type: Number, required: true},
    currency: {type: String, required: true},
    paymentMode: {type: String, enum: [], required: false},
    txHash: {type: String},
    status: {
      type: String,
      default: 'initiated',
      enum: [
        'initiated',
        'paymentStarted',
        'paymentDone',
        'domainInitiated',
        'domainDone',
      ],
    },
    paymentStatus: {
      type: String,
      default: 'created',
      enum: [
        'created',
        'canceled',
        'confirmed',
        'failed',
        'delayed',
        'pending',
        'processing',
        'requires_action',
      ],
    },
    message: {type: Boolean, default: false},
    transactionDate: {type: Date},
    transactionCompleteDate: {type: Date},
    orderId: {type: objectId, required: false},
    transactionInfo: {type: mixed},
    itemsStatus: {type: mixed},
  },
  {timestamps: true, versionKey: false}
);

export const TransactionModel = mongoose.model(
  'Transaction',
  TransactionSchema
);
