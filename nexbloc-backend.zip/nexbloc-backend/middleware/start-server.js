'use strict';

/**
 * Module dependencies.
 */

const mongoose    = require('../lib/mongoose/index').connect();
const http        = require('http');
const port        = process.env.PORT || 9000;


module.exports = app => {
    mongoose.connection.on('connected', listen);
    mongoose.connection.on('error', dbError).on('disconnected', mongoose.connect);
    
    function listen() {
        setTimeout(() => {
            app.set('port', port);
            const server = http.createServer(app);

            server.listen(port);
            console.log('Express app started on port ' + port);
            logger.info('Express app started on port ' + port);
            // Currently you can kill ports running on TCP or UDP protocols
        }, 200);
    }
    // listen();

    function dbError(err) {
        console.log(err);
        logger.error('Mongo connection error:', err);
    }
};
