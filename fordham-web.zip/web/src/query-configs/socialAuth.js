export const googleSignup = data => {
  return {
    url: `/api/google-signup`,
    body: data,
    transform: responseBody => {
      const { data, result } = responseBody || {};
      const res = data || result;
      return { registerData: res };
    },
    update: {
      registerData: (oldValue, newValue) => newValue,
    },
  };
};

export const gitSignup = data => {
  return {
    url: `/api/git-signup`,
    body: data,
    transform: responseBody => {
      const { data, result } = responseBody || {};
      const res = data || result;
      return { registerData: res };
    },
    update: {
      registerData: (oldValue, newValue) => newValue,
    },
  };
};

export const facebookSignup = data => {
  return {
    url: `/api/facebook-signup`,
    body: data,
    transform: responseBody => {
      const { data, result } = responseBody || {};
      const res = data || result;
      return { registerData: res };
    },
    update: {
      registerData: (oldValue, newValue) => newValue,
    },
  };
};

export const googleLogin = data => {
  return {
    url: `/api/google-login`,
    body: data,
    transform: responseBody => {
      const { data, result } = responseBody || {};
      const res = data || result;
      if (res?.token) {
        let { token, user, refreshToken } = res || {};
        localStorage.setItem('token', token);
        localStorage.setItem('user', JSON.stringify(user));
        localStorage.setItem('refreshToken', JSON.stringify(refreshToken));
      }
      return res;
    },
    update: {
      authData: (oldValue, newValue) => newValue,
    },
  };
};

export const gitLogin = data => {
  return {
    url: `/api/git-login`,
    body: data,
    transform: responseBody => {
      const { data, result } = responseBody || {};
      const res = data || result;
      if (res?.token) {
        let { token, user, refreshToken } = res || {};
        localStorage.setItem('token', token);
        localStorage.setItem('user', JSON.stringify(user));
        localStorage.setItem('refreshToken', JSON.stringify(refreshToken));
      }
      return res;
    },
    update: {
      authData: (oldValue, newValue) => newValue,
    },
  };
};

export const facebookLogin = data => {
  return {
    url: `/api/facebook-login`,
    body: data,
    transform: responseBody => {
      const { data, result } = responseBody || {};
      const res = data || result;
      if (res?.token) {
        let { token, user, refreshToken } = res || {};
        localStorage.setItem('token', token);
        localStorage.setItem('user', JSON.stringify(user));
        localStorage.setItem('refreshToken', JSON.stringify(refreshToken));
      }
      return res;
    },
    update: {
      authData: (oldValue, newValue) => newValue,
    },
  };
};
