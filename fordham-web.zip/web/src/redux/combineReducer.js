import { combineReducers } from 'redux';
// import { reducer as forms } from 'redux-form';
import userReducer from '../reducers/userReducer';
const rootReducer = combineReducers({
  // form: forms,
  userReducer
});

export default rootReducer;
