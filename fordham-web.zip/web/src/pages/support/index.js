import React from 'react'
import {Stack, Text,Flex,Spacer, SimpleGrid} from '@chakra-ui/react'

export default function UserGuide() {

    return (
        <Flex  bg="gray.50" p="12" minH="lg" >
            <SimpleGrid  alignItems="center" justifyContent="center" columns={{ base: 1, lg: 4 }} minHeight="60" bg="white">
                <Spacer />
                <Stack justifyContent="center"  bg="white">
                    <Text fontWeight="bold" fontSize="4xl">
                        Need any help?
                    </Text>
                    <Text maxWidth="sm" color="gray.500">
                        Decentralised naming for wallets, websites, & more.
                    </Text>
                </Stack>
                <Stack   justifyContent="center" alignItems="center">
                    <Text> Email to : support@fordham.edu</Text>
                </Stack>
            </SimpleGrid>
        </Flex>

    )
}
