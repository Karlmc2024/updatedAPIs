import React, { useState } from 'react';
import {
  Stack,
  Text,
  Button,

  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  useDisclosure,
  Box
} from '@chakra-ui/react';
import { Th, Td, Tr, Table } from 'components/common/Table';

import { Link, useLocation } from 'react-router-dom';

import { useSelector } from 'react-redux';
import { useRequest } from 'redux-query-react';

import * as transactionQueryConfig from '../../query-configs/transaction';
import * as transactionSelectors from '../../selectors/transaction';

function toTitleCase(string) {
  let sentence = string.toLowerCase().split('_');
  for (let i = 0; i < sentence.length; i++) {
    sentence[i] = sentence[i][0].toUpperCase() + sentence[i].slice(1);
  }
  return sentence.join(' ');
}


export default function MyDomains() {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [manageDomain, setManageDomain] = useState(null);

  const [queryStateMyDomain, getMyDomains] = useRequest(
    transactionQueryConfig.getMyDomains(),
  );

  // const location = useLocation();

  // React.useEffect(() => {
  //   getMyDomains();
  // }, [location]);

  const myDomains = useSelector(transactionSelectors.getMyDomains);

  const openMangeDialog = id => {
    setManageDomain(myDomains.filter(domain => domain._id === id)[0]);
    onOpen();
  };

  const closeManageDialog = () => {
    setManageDomain(null);
    onClose();
  };

  return (
    <>
      {manageDomain && (
        <Modal isOpen={isOpen} onClose={closeManageDialog} size="2xl">
          <ModalOverlay />
          <ModalContent>
            <ModalHeader>Manage {manageDomain.domainName}</ModalHeader>
            <ModalCloseButton />
            <ModalBody>
              <Stack direction="column">
                <Stack direction="row">
                  <Text>
                    <b>Type:</b>{' '}
                    {manageDomain.resolveType
                      ? toTitleCase(manageDomain.resolveType)
                      : 'Not Yet Configured'}
                  </Text>
                  <Text>
                    <b>Value:</b> {manageDomain.resolveString}
                  </Text>
                </Stack>
                <Text>
                  <b>Purchase Date:</b>{' '}
                  {new Date(manageDomain.purchaseDate).toLocaleDateString()}
                </Text>
                <Text>
                  <b>Domain Owner:</b> {manageDomain.domainOwner}
                </Text>
                <Text>
                  <b>Order Id :</b>{' '}
                  <Link to={'/order/' + manageDomain.orderId}>
                    #{manageDomain.orderId}
                  </Link>
                </Text>
              </Stack>
            </ModalBody>
            <ModalFooter>
              <Button colorScheme="blue" mr={3} onClick={closeManageDialog}>
                Close
              </Button>
            </ModalFooter>
          </ModalContent>
        </Modal>
      )}
      <Stack p="8" background="gray.50" minH="lg">
        <Text textAlign="left" fontSize="2xl" fontWeight="bold">
          Your domains
        </Text>
        <Stack overflowX="scroll">
        <Table bg="white">
          <thead>
            <Tr>
              <Th>Domain Name</Th>
              <Th>Domain Owner Address</Th>
              <Th>bDNS On</Th>
              <Th>SmartContract Address</Th>
              <Th>Created At</Th>
              <Th>Action</Th>
            </Tr>
          </thead>
          <tbody>

            {myDomains.length ?
              myDomains.map(domain => {
                const { domainName,tld, domainOwner, dns, purchaseDate, orderId, deployedOnChain, _id: domainId, } = domain;
                let mintableColor = domain.tld && domain.tld.mintable === false ?'yellow.50':false;
                let mintedColor = domain.domainOwner && domain.domainOwner === '0x0' ?false:'green.50';

                return (
                  <Tr backgroundColor={mintableColor || mintedColor} key={domainName}>
                    <Td color="brand.500" fontWeight="semibold">
                      {
                        !mintableColor ? (  <Link to={'/domains/' + domainId}>
                          {domainName}
                        </Link>):<div title='Not Mintable Now' style={{color:'black'}}>{domainName}</div>
                      }

                    </Td>
                    <Td>
                      {domainOwner !== '0x0' ? (
                        domainOwner
                      ) : "Not Set"}
                    </Td>
                    <Td>{tld?.network || dns}</Td>
                    <Td>
                      {!mintableColor ?'0x3c4AB9fe3714A561FdcD5Da62e8b73cb683Cc33E':'' }
                      <i ></i>
                    </Td>
                    <Td>{new Date(purchaseDate).toLocaleDateString()}</Td>
                    <Td color="brand.500" fontWeight="semibold">
                      {
                        domainOwner !== '0x0' ?
                        <Link to={'/manage-domains/' + domainId}>
                        Manage your domain
                      </Link>
                        :
                            (   <>
                              {
                                !mintableColor ? (  <Link to={'/domains/' + domainId}>
                                  Publish your domain
                                </Link>):<div title='Not Mintable Now' style={{color:'black'}}>Coming Soon</div>
                              }
                              </>
                              )
                        // <Link to={'/domains/' + domainId}>
                        //   Publish your domain
                        // </Link>
                      }
                      </Td>
                  </Tr>
                );
              }) :
              <Tr>
                <Td colSpan="5">
                  <Text textAlign="center">
                    No domains exist
                    <Link to={'/'}> search for domain</Link>
                  </Text>
                </Td>
              </Tr>

            }
          </tbody>
        </Table>
        </Stack>
      </Stack>
    </>
  );
}
