import React from 'react';
import Layout from 'pages/Layout';
import { Switch } from 'react-router-dom';
import FullPageLoader from 'components/common/FullPageLoader';
import HomeRoutes from './routes';

export default function Home() {
  return (
    <Layout>
      <React.Suspense fallback={<FullPageLoader />}>
        <Switch>
          {HomeRoutes()}
        </Switch>
      </React.Suspense>
    </Layout>
  );
}
