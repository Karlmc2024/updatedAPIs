import React from 'react';
import { Route } from 'react-router-dom';

export default function HomeRoutes(props) {
  const Login = React.lazy(() => import('pages/auth/Login'));
  const Signup = React.lazy(() => import('pages/auth/Signup'));
  const Hero = React.lazy(() => import('pages/Hero'));
  const Cart = React.lazy(() => import('pages/Cart'));
  const PrivacyPolicy = React.lazy(() => import('pages/PrivacyPolicy'));
  return (
    <>
      <Route exact path="/app" render={() => <Hero {...props} />} />
      <Route exact path="/app/login" render={() => <Login {...props} />} />
      <Route exact path="/app/signup" render={() => <Signup {...props} />} />
      <Route exact path="/app/cart" render={() => <Cart {...props} />} />
      <Route path="/app/privacy-policy" render={() => <PrivacyPolicy {...props} />} />
    </>
  );
}
