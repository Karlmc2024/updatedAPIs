import React, { useMemo } from 'react';
import { Stack, Text, Button, Heading } from '@chakra-ui/react';
import { BsArrowRight } from 'react-icons/bs';
import { IoReceiptOutline } from 'react-icons/io5';
import { useSelector } from 'react-redux';
import { getUser } from 'pages/User/userEntity';

const getButtonMessage = (isLoggedIn,isVerified) => {
  if(isLoggedIn && isVerified){
    return "Checkout"
  }
  else if(!isLoggedIn){
    return "Login to checkout"
  }
  else if(!isVerified){
    return "Verify your email to checkout"
  }
}

export default function Checkout({ data, handleRemoveFromCart, onCheckoutClick,isLoggedIn }) {
  const user = useSelector(getUser) || {}
  const price = useMemo(() => {
    return data.reduce((acc, curr) => acc + parseFloat(curr.price), 0);
  }, [data]);

  const isVerified = (user?.email && user.verified);

  return (
    <Stack
      p="4"
      boxShadow="md"
      borderRadius="md"
      bg="brand.900"
      mb="4"
      color="white"
      spacing="8"
    >
      <Stack>
        <Stack direction="row" alignItems="center">
          <IoReceiptOutline />
          <Text fontSize="xl" fontWeight="semibold" textAlign="left">
            Order details
          </Text>
        </Stack>

        <Stack mt="2">
          <Text fontSize="sm" textAlign="left">Your order total amount is</Text>
          <Heading fontWeight="semibold">${`${price.toFixed(2)}`}</Heading>
        </Stack>
      </Stack>
      <Button disabled={data.length === 0 || (!isVerified && isLoggedIn) } colorScheme="gray" color="brand.500" rightIcon={<BsArrowRight size="20px" />} onClick={onCheckoutClick}>
      {getButtonMessage(isLoggedIn,isVerified)}
      </Button>
    </Stack>
  );
}
