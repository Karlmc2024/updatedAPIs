import React from 'react';
import { Stack, Text, OrderedList, ListItem, UnorderedList, Kbd } from '@chakra-ui/react';

export default function WalletSetupInstructions() {
  return <Stack bg="white" boxShadow="lg" p="4" textAlign="left" fontSize="sm">
    <Text fontSize="md" fontWeight="semibold">
      Add XinFin(XDC) to Metamask Wallet
    </Text>
    <OrderedList px="4">
      <ListItem>
        Open metamask wallet and choose the account you want to proceed with.
      </ListItem>
      <ListItem>
        Go to networks and click <b>Add Network</b>
      </ListItem>
      <ListItem>
        Enter the following details:
      </ListItem>
      <UnorderedList>
        <ListItem>
          Network Name:<Kbd>XinFin</Kbd>
        </ListItem>
        <ListItem>
          New RPC URL:<Kbd>https://rpc.xinfin.network</Kbd>
        </ListItem>
        <ListItem>
          Chain ID:<Kbd>50</Kbd>
        </ListItem>
        <ListItem>
          Currency Symbol : <Kbd>XDC</Kbd>
        </ListItem>
        <ListItem>
          Block Explorer URL : <Kbd>https://explorer.xinfin.network/</Kbd>
        </ListItem>
      </UnorderedList>
      <ListItem>
        Save these details.
      </ListItem>
    </OrderedList>
    {/*<Text fontSize="md" fontWeight="semibold">*/}
    {/*  Import Tokens in your Metamask Wallet*/}
    {/*</Text>*/}
    {/*<OrderedList px="4">*/}
    {/*  <ListItem>*/}
    {/*    Go to metamask and press import tokens*/}
    {/*  </ListItem>*/}
    {/*  <ListItem>*/}
    {/*    Add the zone contract address and press add custom token*/}
    {/*  </ListItem>*/}
    {/*</OrderedList>*/}
  </Stack>;
}
