import React, { useState } from 'react';
import {
  Input,
  Stack,
  Button,
  Text,
  Heading,
  FormErrorMessage,
  FormControl,
} from '@chakra-ui/react';
import {
  CardNumberElement,
  CardCvcElement,
  CardExpiryElement,
  Elements,
} from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useStripe, useElements } from '@stripe/react-stripe-js';

import { STRIPE_PK } from '../../../../constants/keys';
import { getTransactionById } from 'query-configs/transaction';

import { BsFillPatchCheckFill } from 'react-icons/bs';
import { IoIosCloseCircle } from 'react-icons/io';

import './stripe.css';
import { useRequest } from 'redux-query-react';
import { useSelector } from 'react-redux';
import { useParams, useHistory } from 'react-router-dom';
import { useQuery } from 'utils/Hooks/useQuery';

const ELEMENT_OPTIONS = {
  style: {
    base: {
      fontSize: '18px',
      color: '#424770',
      letterSpacing: '0.025em',
      '::placeholder': {
        color: '#aab7c4',
      },
    },
    invalid: {
      color: '#9e2146',
    },
  },
};

export default function StripeComponent() {
  const stripePromise = loadStripe(STRIPE_PK);
  const params = useParams();
  const history = useHistory();
  const { id } = params;
  const query = useQuery();
  useRequest(getTransactionById(id));
  const transactionInfo = useSelector(
    state => state.entities.getTransactionByIdInfo,
  );
  const closePayment = () => {
    const redirectUrl = query.redirect;
    if (redirectUrl) {
      history.push(redirectUrl);
    } else {
      history.push(`/order/${transactionInfo.orderId}`);
    }
  };
  return (
    <Stack bg={'gray.50'} p="4" minH="lg">
      <Heading mb="4">Payment Amount ${transactionInfo?.amount}</Heading>
      <Elements stripe={stripePromise}>
        <Stripe
          clientSecret={transactionInfo?.transactionInfo?.client_secret || ''}
          closePayment={closePayment}
        />
      </Elements>
    </Stack>
  );
}

function Stripe(props) {
  const [succeeded, setSucceeded] = useState(false);
  const [error, setError] = useState(null);
  const [processing, setProcessing] = useState('');
  const [disabled, setDisabled] = useState(true);
  const stripe = useStripe();
  const elements = useElements();
  const [postalCode, setPostalCode] = useState('');
  const [stripeValues, setStripeValues] = useState({
    cardNumber: true,
    expiry: true,
    cvc: true,
  });
  const [inputValidationError, setInputValidationError] = useState(false);

  const handleChange = async event => {
    // Listen for changes in the CardElement
    // and display any errors as the customer types their card details
    setDisabled(event.empty);
    setError(event.error ? event.error.message : '');
  };

  const checkInputAreValid = () => {
    if (stripeValues.cardNumber || stripeValues.expiry || stripeValues.cvc) {
      return false;
    }
    return true;
  };

  const handleSubmit = async ev => {
    ev.preventDefault();
    if (!checkInputAreValid()) {
      setInputValidationError(true);
      return;
    }
    setProcessing(true);

    const payload = await stripe.confirmCardPayment(props.clientSecret, {
      payment_method: {
        card: elements.getElement(CardNumberElement),
        billing_details: {
          address: {
            postal_code: postalCode,
          },
        },
      },
    });
    if (payload.error) {
      setError(`Payment failed ${payload.error.message}`);
      setProcessing(false);
      // dispatch(stripeStatus('failed'));
    } else {
      setError(null);
      setProcessing(false);
      setSucceeded(true);
      // dispatch(stripeStatus('success'));
    }
  };

  const handleCloseMe = () => {
    props.closePayment();
  };

  if (succeeded) {
    return (
      <Stack align="center">
        <Stack
          align="center"
          maxW="lg"
          margin="auto"
          background="white"
          boxShadow="lg"
          p="4"
          minW="lg"
          minH="64"
        >
          <BsFillPatchCheckFill size="108" color="#4BB543" />
          <Text>Payment is successful</Text>
          <Button onClick={handleCloseMe}>Close</Button>
        </Stack>
      </Stack>
    );
  }

  if (error) {
    return (
      <Stack align="center">
        <Stack
          align="center"
          maxW="lg"
          margin="auto"
          background="white"
          boxShadow="lg"
          p="4"
        >
          <IoIosCloseCircle size="108" color="red" />
          <Text>Error has occured</Text>
          <Text>{error}</Text>
          <Button onClick={handleCloseMe}>Close</Button>
        </Stack>
      </Stack>
    );
  }

  return (
    <form
      className="stripe"
      id="payment-form"
      onSubmit={handleSubmit}
      style={{ margin: 'auto' }}
    >
      <label htmlFor="cardNumber">Card Number</label>
      <CardNumberElement
        id="cardNumber"
        options={ELEMENT_OPTIONS}
        onChange={value => {
          console.log(value.complete);
          setStripeValues({
            ...stripeValues,
            cardNumber: value.empty || !value.complete,
          });
        }}
      />
      {inputValidationError && stripeValues.cardNumber && (
        <Text color="red">Please enter a valid card number</Text>
      )}
      <label htmlFor="expiry">Card Expiration</label>
      <CardExpiryElement
        id="expiry"
        options={ELEMENT_OPTIONS}
        onChange={value => {
          setStripeValues({
            ...stripeValues,
            expiry: value.empty || !value.complete,
          });
        }}
      />
      {inputValidationError && stripeValues.expiry && (
        <Text color="red">Please enter a valid expiry</Text>
      )}
      <label htmlFor="cvc">CVC</label>
      <CardCvcElement
        id="cvc"
        options={ELEMENT_OPTIONS}
        onChange={value => {
          setStripeValues({
            ...stripeValues,
            cvc: value.empty || !value.complete,
          });
        }}
      />
      {inputValidationError && stripeValues.cvc && (
        <Text color="red">Please enter a valid cvc</Text>
      )}
      <label htmlFor="postal">Postal Code</label>
      <Input
        mb="4"
        bg="white"
        padding="2"
        variant="unstyled"
        boxShadow="md"
        id="postal"
        placeholder="12345"
        value={postalCode}
        onChange={event => {
          setPostalCode(event.target.value);
        }}
      />
      <button
        className="stripe"
        // disabled={processing || disabled || succeeded}
        id="submit"
      >
        <span id="button-text">
          {processing ? <div className="spinner" id="spinner" /> : 'Pay'}
        </span>
      </button>
      {/* Show any error that happens when processing the payment */}
      {error && (
        <div className="card-error" role="alert">
          {error}
        </div>
      )}
      <Text
        textAlign="start"
        style={{ margin: 'auto' }}
        color="red.500"
        mt="4"
      >
        {' '}
        Please do not close or navigate back. It will cancel the transaction.
      </Text>
 
    </form>
  );
}
