import React from 'react';
import { useMutation } from 'redux-query-react';
import { Dialog, DialogTitle, DialogActions, Button } from '@material-ui/core';
import * as transactionQueryConfig from '../../../../query-configs/transaction';

export default function PaypalComponent({
  closePayment,
  transactionInfo,
  setPaypalTxHash,
}) {
  const [queryState, updatePaypalTransaction] = useMutation(data =>
    transactionQueryConfig.updatePaypal(transactionInfo._id, data),
  );
  document.getElementById('paypal-button-container') &&
    (document.getElementById('paypal-button-container').innerHTML = '');
  React.useEffect(() => {
    window.paypal
      .Buttons({
        createOrder: (data, actions) => {
          return actions.order.create({
            purchase_units: [
              {
                amount: {
                  currency_code: transactionInfo.currency.toUpperCase(),
                  value: transactionInfo.amount,
                },
              },
            ],
          });
        },
        onApprove: (data, actions) => {
          return actions.order.capture().then((details) => {
            setPaypalTxHash(
              details.purchase_units[0].payments.captures[0].id,
            );
            updatePaypalTransaction({
              transactionInfo: details,
            });
          });
        },
        onCancel: data => {
          // toast.error('Payment cancelled');
          closePayment();
        },
        onError: err => {
          console.error(err);
          // closePayment();
          // toast.error('Error with Payment please try again');
        },
      })
      .render('#paypal-button-container');
  }, []);
  // document.getElementById('paypal_button').style.display = 'none';
  return (
    // <Dialog
    //   onClose={closePayment}
    //   open={transactionInfo ? true : false}
    //   disableBackdropClick
    // >
    //   <DialogTitle>Select to proceed</DialogTitle>
    //   {/* <div
    //     id="paypal-button-container"
    //     style={{ padding: '10px', paddingBottom: '0px' }}
    //   /> */}
    //   <DialogActions>
    //     <Button onClick={closePayment} color="primary">
    //       Close
    //     </Button>
    //   </DialogActions>
    // </Dialog>
    <div />
  );
}
