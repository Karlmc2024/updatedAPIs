import React, { useState } from 'react';
import { Button, Stack } from '@chakra-ui/react';
import {
  getDomainTokenId,
  getWeb3,
  mintDomain,
} from 'utils/Common/BlockChain/web3';
import { useMutation } from 'redux-query-react';
import * as transactionQueryConfig from '../../../query-configs/transaction';
import {customToast} from 'components/common/Toast'
import PublishDomainSuccess from './PublishDomainSuccess';
export default function PublishDomain({ domain = {}, account, setCurrentIndex }) {
  const { domainName, _id:id } = domain;
  const [loading, setLoading] = useState(false);
  const [mintDomainResponse, setMintDomainResponse] = useState();

  const [{isFinished, status,isLoading}, updateDomain] = useMutation(({deployedOnChain, resolveString}) =>
    transactionQueryConfig.updateDomainResolver(id, 
      {
        resolveType: 'xdc_address',
        resolveString: resolveString,
        domainOwner: account,
        deployedOnChain,
    }),
  );

  const handlePublishDomian = async () => {
    const web3 = getWeb3();
    if (web3 && account) {
      setLoading(true);
      const gas = 100000000;
      try {
        const mintDomainRes = await mintDomain({
          web3,
          sender: account,
          gas,
          domain: domainName,
        });
        const tokenId = await getDomainTokenId({domain:domainName,gas})
        console.log(tokenId)
        setMintDomainResponse(mintDomainRes);
        updateDomain({resolveString: mintDomainRes.transactionHash, deployedOnChain: true});
      } catch (error) {
        console.log(error)
        customToast({description:error?.message,status:"error"})
      }
      setLoading(false);
    }
  };


  const { transactionHash } = mintDomainResponse || {};
  return (
    <Stack
        mr="8"
        background="white"
        direction="column"
        maxWidth="700px"
        margin="auto"
        minW="lg"
        borderRadius="sm"
        padding="8" spacing="8"
        alignItems="center">
      {
        mintDomainResponse? <PublishDomainSuccess transactionHash={transactionHash}/> : <Button onClick={handlePublishDomian} isLoading={loading||isLoading} loadingText='Publishing domain...'>Publish Your Domain</Button>  
      }
    </Stack>
  );
}
