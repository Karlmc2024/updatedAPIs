import React from 'react';
import {
  Stack, Text, Button, Flex,
} from '@chakra-ui/react';
import { AiOutlineDelete } from 'react-icons/ai';

export default function CheckoutItem({
  name, price, handleRemoveFromCart, id,
}) {
  return (
    <Stack p="2" boxShadow="lg" borderRadius="sm" bg="white" color="brand.500" spacing="0">
      <Stack justifyContent="space-between" direction="row" width="full">
        <Text fontSize="md" textAlign="left" fontWeight="semibold">
          {name}
        </Text>
        <Text fontSize="md" textAlign="left">
          {price}
        </Text>
      </Stack>
      <Flex>
        <Button leftIcon={<AiOutlineDelete />} variant="ghost" p="0" fontSize="sm" onClick={() => handleRemoveFromCart(id)}>Delete</Button>
      </Flex>

    </Stack>
  );
}
