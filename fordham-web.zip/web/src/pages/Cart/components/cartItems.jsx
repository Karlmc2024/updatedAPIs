import React, { useState } from 'react';
import { Stack, Text } from '@chakra-ui/react';
import CartItem from './CartItem';
export default function CartItems({
  data,
  handleRemoveFromCart,
  handleMovetoWishlist,
  attachOwner,
}) {
  const [wallet, setwallet] = useState({});

  return (
    <Stack mr={{base:"0",md:"8"}}>
      <Stack>
        { data && data.length > 0 ? (
          data.map((website, i) => (
              <div key={i}>
            <CartItem
              {...website}
              handleRemoveFromCart={handleRemoveFromCart}
              handleMovetoWishlist={handleMovetoWishlist}
              userAddresses={wallet}
            />
              </div>
          ))
        ) : (
          <Text textAlign="left" fontSize="md" fontWeight="bold">
            No domains in the cart.
          </Text>
        )}
      </Stack>
    </Stack>
  );
}
