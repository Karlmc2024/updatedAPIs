import React from 'react';
import { Stack, Text } from '@chakra-ui/react';
import PublishDomainButton from './PublishDomainButtons'
import { FcApproval } from 'react-icons/fc';

export default function PublishDomainSuccess({transactionHash}) {

  return  <Stack maxW="72">
  <Stack alignItems="center" spacing="4" my="4">
    <FcApproval size="72px"/>
    <Text>Your domain has been published successfully</Text>
  </Stack>
  <PublishDomainButton transactionHash={transactionHash}/>
</Stack>
}
