import React from 'react';
import { Stack, Text, IconButton, Button} from '@chakra-ui/react';
import { AiOutlineDelete } from 'react-icons/ai';
import DeleteCartDialogExample from './DelectCartModal';
import { FaGlobeAmericas } from 'react-icons/fa';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { getWishlist } from 'pages/Wishlist/entities';


export default function CartItem({
  domainName,
  price,
  _id,
  handleRemoveFromCart,
  domainOwner,
    key,
  handleMovetoWishlist,
  userAddresses,
}) {
  const [isDeleteModalOpen, setIsDeleteModalOpen] = React.useState(false)
  const onCloseDeleteModal = () => setIsDeleteModalOpen(false)
  const wishlist = useSelector(getWishlist)
  const existsInWishlist = wishlist?.some(item => item.domainName === domainName);

  return (
    <Stack
        key={domainName}
      alignItems="flex-start"
      p="4"
      boxShadow="sm"
      borderRadius="lg"
      bg="white"
      justifyContent="space-between"
      spacing="4"
      direction={{base:"column",md:"row"}}
    >
      <Stack
        direction={{base:"column",md:"row"}}
        alignItems={{base:"center",md:"flex-start"}}
        justifyContent="space-between"
        width="full"
        spacing="4"
      >
        <Stack direction="column">
          <Stack direction="row" alignItems="center" spacing="4">
         <FaGlobeAmericas/>
            <Text fontSize="3xl" fontWeight="semibold" color="brand.500">
              {domainName}
            </Text>
          </Stack>
        </Stack>
        <Stack direction={{base:"column",md:"row"}}>
          <Stack alignItems={{md:"flex-end"}}>
            <Text fontSize="3xl" fontWeight="semibold" color="brand.600">
              ${price}
            </Text>
            <Text color="gray.600" maxW="xs" fontSize="xs" textAlign="right">
              Reserve your {domainName} domain  with just ${price}
            </Text>
            <Button variant="link"  onClick={()=>handleMovetoWishlist(_id)} disabled={existsInWishlist}> 
              Move to Wishlist
            </Button>
          </Stack>
          <DeleteCartDialogExample
           isOpen={isDeleteModalOpen}
           onClose={onCloseDeleteModal}
           onDelete={() => {
            handleRemoveFromCart(_id);
            onCloseDeleteModal()
          }}
          >
          <IconButton
            p="0"
            icon={<AiOutlineDelete fontSize="20px" />}
            colorScheme="red"
            variant="ghost"
            onClick={()=>setIsDeleteModalOpen(true)}
          >
            Delete
          </IconButton>
          </DeleteCartDialogExample>
        </Stack>
      </Stack>
    </Stack>
  );
}
