import React from 'react';
import { Stack, Text, Button } from '@chakra-ui/react';
import ConnectToWallet from './ConnectToWallet';
import PublishDomain from './PublishDomain';
import PublishDomainSuccess from './PublishDomainSuccess';
import { useHistory } from 'react-router-dom';

const DomainConfigurationMap = [ConnectToWallet, PublishDomain];

export default function DomainConfiguration({
  currentIndex,
  setCurrentIndex,
  domain,
}) {
  const [account, setAccount] = React.useState();
  const history = useHistory();


  const Component = DomainConfigurationMap[currentIndex];

  if (!domain) return <Text>No domain to configure.</Text>;

  if (domain.domainOwner !== '0x0') {
  }

  return (
    <Stack alignItems="center">
      <Text fontSize="lg" fontWeight="semibold">
        Domain : {domain.domainName}
      </Text>
      {domain.domainOwner !== '0x0' ? (
        <PublishDomainSuccess transactionHash={domain.resolveString} />
      ) : (
        <Component
          domain={domain}
          setAccount={setAccount}
          account={account}
          setCurrentIndex={setCurrentIndex}
        />
      )}
      <Button variant="outline" onClick={() => { history.push("/my-domains") }}>
        Back to My Domains
      </Button>
    </Stack>
  );
}
