import React from 'react';
import { Stack, Text, Button } from '@chakra-ui/react';
import {
  getWeb3,
  getWeb3Account,
} from 'utils/Common/BlockChain/web3';
import { customToast } from 'components/common/Toast'
import MetaMaskIcon from 'components/common/Icons/Metamask';
import { Table, Tr, Td, Th } from 'components/common/Table';


export default function ConnectToWallet({ setAccount, setCurrentIndex }) {
  const handleConnectToWallet = async () => {
    const web3 = getWeb3();
    const web3Account = await getWeb3Account(web3);
    if (web3Account && web3Account.length) {
      customToast({ description: "Connected to wallet", status: "success" })
      setAccount(web3Account[0]);
      setCurrentIndex(1);
    }
  };


  return (
    <Stack>
      <Stack alignItems="center">
      <Table width="md">
        <thead>

        <Tr>
          <Th>Wallet</Th>
          <Th>Action</Th>
        </Tr>
        <Tr>
          <Td>Metamask</Td>
          <Td><Button onClick={handleConnectToWallet}>Connect to wallet</Button></Td>
        </Tr>
        </thead>
          </Table>
        <Text fontSize="xs" color="gray.500">
          <b>Note:</b> You need to connect to wallet to publish domain. You can connect to wallet by clicking on the wallet icon above.
        </Text>
      </Stack>
    </Stack>
  );
}
