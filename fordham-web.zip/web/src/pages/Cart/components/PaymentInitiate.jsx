import React from 'react';
import {
  Dialog,
  DialogTitle,
  List,
  ListItem,
  DialogActions,
  Button,
} from '@material-ui/core';

import './paymentInitiate.css';

import cards_icon from '../images/cards.png';
import paypal_icon from '../images/paypal.png';
import crypto_icon from '../images/crypto.png';

export default function PaymentInitiate({
  openPayment,
  closePayment,
  setPaymentMode,
}) {
  const selectPaymentGateway = gateway => {
    setPaymentMode(gateway);
  };

  return (
    <div>
      <Dialog onClose={closePayment} open={openPayment} disableBackdropClick>
        <DialogTitle>Select to proceed</DialogTitle>
        <List>
          <ListItem button onClick={() => selectPaymentGateway('stripe')}>
            <span className="p_icon">
              <img src={cards_icon} alt="card_icon" />
            </span>
            <span className="p_title"> Debit/Credit Card</span>
          </ListItem>
          <ListItem button onClick={() => selectPaymentGateway('coinbase')}>
            <span className="p_icon">
              <img src={crypto_icon} alt="crypto_icon" />
            </span>
            <span className="p_title"> Coinbase</span>
          </ListItem>
          <ListItem
            id="paypal_button"
            button
            onClick={() => selectPaymentGateway('paypal')}
          >
            <span className="p_icon">
              <img src={paypal_icon} alt="paypal_icon" />{' '}
            </span>
            <span className="p_title"> Paypal</span>
            <br />
          </ListItem>
        </List>
        <div
          id="paypal-button-container"
          style={{ padding: '10px', paddingBottom: '0px', maxWidth: "218px" }}
        />
        <DialogActions>
          <Button onClick={closePayment} color="primary">
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
