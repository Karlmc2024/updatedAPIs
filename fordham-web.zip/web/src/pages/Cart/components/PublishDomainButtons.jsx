import React from 'react';
import { Button } from '@chakra-ui/react';


export default function PublishDomainButton({transactionHash}) {

  return  <>
  <Button as="a" href={`https://explorer.xinfin.network/txs/${transactionHash}`} target='_blank'>
    Track Progress
  </Button>
</>
}
