import React from 'react'
import { Stack, Heading, Text, HStack, Input, Button, Flex } from '@chakra-ui/react'
import { FaEthereum, FaBitcoin } from 'react-icons/fa';
import { Table, Tr, Td } from 'components/common/Table';

const cryptoAddress = [
  {
    label: 'XDC',
    placeholder: 'Enter your Xinfin address',
  },
  {
    icon: <FaBitcoin />,
    label: 'Bitcoin',
    placeholder: 'Enter your Bitcoin address',
  },
  {
    icon: <FaEthereum />,
    label: 'Ethereum',
    placeholder: 'Enter your Ethereum address',
  },
  {
    label: 'Litecoin',
    placeholder: 'Enter your Litecoin address',
  },
  {
    label: 'XRP',
    placeholder: 'Enter your Ripple address',
  },
  {
    label: 'ZIL',
    placeholder: 'Enter your Zilliqa address',
  },
]

export default function Crypto() {
  return (
    <Stack align="center">
      <Heading size="md">
        Add cryptocurrency addresses
      </Heading>
      <Text color="gray">
        Add your cryptocurrency addresses to receive payments.
      </Text>
      <Stack>
      <Table width="lg">
        {
          cryptoAddress.map((item, index) => {
            const { icon, label, placeholder } = item
            return  <Tr key={Math.random()}>
                <Td>
                  <HStack>
                    {icon}
                    <Text fontWeight="semibold">{label}</Text>
                  </HStack>
                </Td>
                <Td>
                  <Input placeholder={"Coming soon..."} disabled />
                </Td>
              </Tr>
          })
        }
          </Table>
          <Flex justify="flex-end">
            <Button> Save </Button>
          </Flex>
      </Stack>
    </Stack>
  )
}
