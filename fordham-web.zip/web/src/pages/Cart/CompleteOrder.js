import React, { useEffect } from 'react';
import { Stack } from '@chakra-ui/react';
import { useParams } from 'react-router-dom';

import { useSelector } from 'react-redux';
import { useRequest } from 'redux-query-react';

import * as transactionQueryConfig from '../../query-configs/transaction';
import * as transactionSelectors from '../../selectors/transaction';

import HorizantalStepper from 'components/common/Stepper';
import DomainConfiguration from './components/DomainConfiguration';
import WalletSetupInstructions from './components/WalletSetupInstructions';
import BackButton from 'components/common/BackButton';

const stepperData = [
  {
    heading: 'Choose wallet',
  },
  {
    heading: 'Publish Domains',
  },
];

export default function CompleteDomainRegistration() {
  const { domainId } = useParams();
  const [{ isPending }, refresh] = useRequest(
    transactionQueryConfig.getOrderToComplete(domainId),
  );
  const domainsToConfigure = useSelector(transactionSelectors.getOrderDomain);
  const [currentIndex, setCurrentIndex] = React.useState(0);

  useEffect(() => {
    refresh();
  }, []);
 

  return (
    <Stack minH="sm">
      <BackButton path="/app/my-domains">Back</BackButton>
      {domainsToConfigure?.tld && !domainsToConfigure?.tld?.mintable ? (
        <div>Domain is not mintable</div>
      ) : (
        <Stack
          padding="50px"
          background="gray.50"
          minH="lg"
          alignItems="center"
        >
          <Stack w="2xl">
            <Stack background="white" boxShadow="md" padding="4">
              <HorizantalStepper
                stepperData={stepperData}
                activeIndex={currentIndex}
                headingDirection={'row'}
                showChecked={true}
                contentWidth="200px"
              />
            </Stack>
            <Stack
              mr="8"
              background="white"
              boxShadow="md"
              direction="column"
              maxWidth="700px"
              margin="auto"
              paddingLeft="40px"
              paddingRight="40px"
              paddingTop="20px"
              paddingBottom="20px"
              borderRadius="sm"
            >
              <DomainConfiguration
                domain={domainsToConfigure}
                currentIndex={currentIndex}
                setCurrentIndex={setCurrentIndex}
              />
            </Stack>
            <WalletSetupInstructions />
          </Stack>
        </Stack>
      )}
    </Stack>
  );
}
