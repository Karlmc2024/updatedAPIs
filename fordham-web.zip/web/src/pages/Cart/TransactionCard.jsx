import React from 'react';
import { Stack, HStack, Text, Button, Heading, Box } from '@chakra-ui/react';
import { HiBadgeCheck } from 'react-icons/hi';
import {
  IoMdGlobe,
  IoIosBicycle,
  IoIosCloseCircleOutline,
  IoIosCard,
} from 'react-icons/io';
import { RiLoader2Fill, RiUploadCloud2Line } from 'react-icons/ri';
import { formatDistance } from 'date-fns';

const paymentStatus = {
  initiated: { status: 'Started', icon: <IoIosBicycle />, color: 'orange' },
  created: { status: 'Started', icon: <IoIosBicycle />, color: 'orange' },
  paymentFailed: {
    status: 'Failed',
    icon: <IoIosCloseCircleOutline />,
    color: 'red',
  },
  paymentStarted: {
    status: 'Waiting for Payment',
    icon: <RiLoader2Fill />,
    color: 'orange',
  },
  paymentDone: {
    status: 'Payment Completed',
    icon: <IoIosCard />,
    color: 'green',
  },
  domainInitiated: {
    status: 'Started Registering Domain',
    icon: <RiUploadCloud2Line />,
    color: 'blue',
  },
  domainDone: {
    status: 'Domain Registered',
    icon: <HiBadgeCheck />,
    color: 'green',
  },
};

function TransactionStatusLabel({ status }) {
  if (!paymentStatus[status]) {
    return null;
  }
  const { status: label, icon, color } = paymentStatus[status] || {};
  return (
    <HStack color={color} fontSize="2xl" fontWeight="semibold">
      {icon}
      <Text>{label}</Text>
    </HStack>
  );
}

export default function TransactionCard({
  orderId,
  items = [],
  totalCost,
  updatedAt,
  currency,
  status,
  finalAmount,
}) {
  return (
    <Stack boxShadow="lg" background="white" padding="8" width={{sm:"sm",md:"xl"}}>
      <Stack direction={{base:"column",md:"row"}} justify="space-between" align="flex-start">
        <Stack>
          <TransactionStatusLabel status={status} />
          <HStack color="gray.500">
            <Text>{orderId}</Text>
          </HStack>
        </Stack>
        <Text color="gray.500">
          {formatDistance(new Date(updatedAt), new Date(), { addSuffix: true })}
        </Text>
      </Stack>
      <HStack justify="space-between">
        <Stack>
          <HStack color="brand.500">
            <IoMdGlobe />
            <Text fontSize="lg" fontWeight="semibold">
              Domains
            </Text>
          </HStack>
          <Stack align="flex-start" pl="4">
            {items.map(domain => (
              <Text key={domain.domainName}>{domain.domainName}</Text>
            ))}
          </Stack>
        </Stack>
        <Stack>
          <Text>Total Cost</Text>
          <HStack align="baseline" color="brand.500">
            {finalAmount != null && finalAmount != totalCost ? (
              <>
                  <Heading fontSize="2xl" textTransform="uppercase">
                    ${finalAmount} 
                  </Heading>{' '}
              </>
            ) : (
              <>
                <Heading>{totalCost}</Heading>
                <Heading
                  fontSize="2xl"
                  fontWeight="bold"
                  textTransform="uppercase"
                >
                  {currency}
                </Heading>
              </>
            )}
          </HStack>
        </Stack>
      </HStack>
      <Box>
        <Button as="a" href={'/order/' + orderId}>
          View Details
        </Button>
      </Box>
    </Stack>
  );
}
