import React from 'react';
import { Stack, Heading } from '@chakra-ui/react';

import { useSelector } from 'react-redux';
import { useRequest } from 'redux-query-react';

import * as transactionQueryConfig from '../../query-configs/transaction';
import * as transactionSelectors from '../../selectors/transaction';
import TransactionCard from './TransactionCard';

export default function Transactions() {
  const [queryStateRequest, getMyOrderQuery] = useRequest(
    transactionQueryConfig.GetMyOrders(),
  );
  

  const myOrders = useSelector(transactionSelectors.getMyOrders);
  
  return (
    <div>
      <Stack
        direction="column"
        borderRadius="lg"
        minH="md"
        spacing="4"
        padding="20px"
        margin="auto"
        alignItems="center"
        marginTop="50px"
        marginBottom="50px"
      >
        <Heading fontSize="2xl" textAlign="left">
          Transactions
        </Heading>
        {myOrders.map(({_id:orderId,cart,updatedAt,status, finalAmount}) => {
          return (
            <TransactionCard orderId={orderId} key={orderId} items={cart?.items} updatedAt={updatedAt} totalCost={cart?.totalCost} currency={cart?.currency} status={status} finalAmount={finalAmount}/>
          );
        })}
      </Stack>
    </div>
  );
}
