import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { useRequest, useMutation } from 'redux-query-react';
import * as transactionQueryConfig from '../../query-configs/transaction';
import * as transactionSelectors from '../../selectors/transaction';
import { Tabs, TabList, TabPanels, Tab, TabPanel } from '@chakra-ui/react'
import SellDomain from './SellDomain';
import Transfer from './Transfer';
import Crypto from './Crypto';
import Website from './Website';

export default function ManageDomain(props){
    const [resolveType, setResolveType] = useState({});
    const [resolveString, setResolveString] = useState({});
    const [queryStateRequest, getOrderQuery] = useRequest(
      transactionQueryConfig.getOrderToComplete(props.match.params.orderId),
    );
    const [queryStateUpdate, updateDomain] = useMutation((id, data) =>
      transactionQueryConfig.updateDomainResolver(id, data),
    );
    const domainsToConfigure = useSelector(transactionSelectors.getOrderDomain);

    const tabs = ["Crypto", "Website","Transfer","Sell domain"]
    const tabPanels = [<Crypto/>,<Website/>,<Transfer/>,<SellDomain/>]

    return <Tabs colorScheme='brand' px="36" py="8" minH="lg">
    <TabList>
      {
        tabs.map((tab, index) => <Tab key={index} _selected={{ color: 'white', bg: 'brand.500', borderRadius:"sm" }} key={index}>{tab}</Tab>)
      }
    </TabList>
    <TabPanels>
      {tabPanels.map((tab, index) => <TabPanel key={index}>{tab}</TabPanel>)}
    </TabPanels>
  </Tabs>
}
