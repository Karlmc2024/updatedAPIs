import React, { useState } from 'react';
import {
  Box,
  Stack,
  Text,
  useRadio,
  useRadioGroup,
  Button,
  Spinner,
  IconButton,
  Flex,
  Tooltip,
} from '@chakra-ui/react';
import { FormControl, InputLabel, Select } from '@material-ui/core';

import { Link, useHistory } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { useRequest, useMutation } from 'redux-query-react';
import store from 'redux/reduxQueryStore';
import { updateEntities } from 'redux-query';

import * as transactionQueryConfig from '../../query-configs/transaction';
import * as transactionSelectors from '../../selectors/transaction';
import { getCartRequest } from 'entities/cartEntity';
import CoinbaseComponent from './components/payments/coinbase';

import cards_icon from './images/cards.png';
import crypto_icon from './images/crypto.png';
import success_icon from './images/success.png';
import './components/paymentInitiate.css';
import { FaGlobeAmericas } from 'react-icons/fa';
import { AiFillDollarCircle, AiOutlineDelete } from 'react-icons/ai';
import { removeFromCart } from 'components/Domain/cartUtils';

import DeleteCartDialogExample from '../Cart/components/DelectCartModal';
import { deleteFromCartMutation } from 'entities/cartEntity';
import { getCartDetails } from 'entities/cartEntity';
import StripeComponent from '../TokenCart/components/payments/stripe';

function RadioCard(props) {
  const { getInputProps, getCheckboxProps } = useRadio(props);

  const input = getInputProps();
  const checkbox = getCheckboxProps();
  return (
    <Stack
      as="label"
      _disabled={{
        opacity: 0.5,
      }}
      disabled={props.isDisabled}
    >
      <input {...input} />
      <Stack
        {...checkbox}
        cursor="pointer"
        borderWidth="1px"
        borderRadius="md"
        boxShadow="md"
        _checked={{
          bg: 'brand.100',
          color: 'white',
          borderColor: 'brand.100',
        }}
        _focus={{
          boxShadow: 'outline',
        }}
        px={5}
        py={3}
      >
        {props.children}
      </Stack>
    </Stack>
  );
}

const OpenPayment = function (props) {
  const history = useHistory();

  const {
    transactionInfo,
    paymentMode,
    closePayment,
    cancelPayment,
    setPaypalTxHash,
  } = props;

  if (paymentMode === 'stripe') {
    history.push('/transactions/stripe/' + transactionInfo._id);
    return null;
  }

  switch (paymentMode) {
    case 'stripe':
      return (
        <StripeComponent
          transactionInfo={transactionInfo}
          closePayment={closePayment}
          cancelPayment={cancelPayment}
        />
      );

    case 'coinbase':
      return (
        <CoinbaseComponent
          transactionInfo={transactionInfo}
          closePayment={closePayment}
        />
      );
    default:
      return <div />;
  }
};

const StripePaymentStatus = ({ transactionInfo }) => {
  const [TXqueryState, getTxStatusQuery] = useRequest(
    transactionQueryConfig.getTransactionStatus(transactionInfo.txHash),
  );
  return <div />;
};

const PaypalPaymentStatus = ({ paypalTxHash }) => {
  const [TXqueryState, getTxStatusQuery] = useRequest(
    transactionQueryConfig.getTransactionStatus(paypalTxHash),
  );
  return <div />;
};

export default function Order(props) {

  // let myCreditsData = useSelector(transactionSelectors.getMyCredits);
  // const myCredits = (myCreditsData && myCreditsData.amount) || 0;
  const order = useSelector(transactionSelectors.getOrder);

  const [paymentGateway, setPaymentGateway] = useState("stripe");
  const [paypalTxHash, setPaypalTxHash] = useState(null);
  const [defaultDiscountApplied, setdefaultDiscountApplied] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = React.useState(false);
  const [deleteId, setDeleteId] = useState(null)
  const onCloseDeleteModal = () => {
    setIsDeleteModalOpen(false)
    setDeleteId(null)
  };

  const cartDetails = useSelector(getCartDetails);
  const [queryDeleteCart, deleteFromCart] = useMutation(deleteFromCartMutation);

  if (queryDeleteCart.status === 200 && queryDeleteCart.isFinished) {
    if (cartDetails.length) {
      window.location.reload();
    } else {
      props.history.push('/cart');
    }
  }

  React.useEffect(() => {
    return () => {
      store.dispatch(
        updateEntities({
          transactionInfo: prevValue => null,
          paymentMode: prevValue => null,
        }),
      );
    };
  }, []);

  const [cartStateRequest, getMyCart] = useRequest(getCartRequest);
  const [queryState, getOrderQuery] = useRequest(
    transactionQueryConfig.GetOrder(props.match.params.orderId),
  );

  const [_, cancelOrderTransaction] = useMutation(data => {
    return transactionQueryConfig.cancelOrderTransaction(data);
  });

  const [queryStateT, createTransaction] = useMutation(data =>
    transactionQueryConfig.InitiateTransaction(data),
  );

  // const [queryStateUserCredits, getUserCredits] = useRequest(
  //   transactionQueryConfig.getUserCredits(),
  // );

  const [queryStateAC, applyDiscountCoupon] = useMutation(discountCoupon =>
    transactionQueryConfig.applyCoupon(
      props.match.params.orderId,
      discountCoupon,
    ),
  );

  const [queryStateC, getAvaialbleCouponRefres] = useRequest(
    transactionQueryConfig.getAvailableCoupons(),
  );

  const transactionInfo = useSelector(transactionSelectors.getTransactionInfo);
  const paymentMode = useSelector(transactionSelectors.getTransactionMode);
  const availableCoupons = useSelector(transactionSelectors.availableCoupons);

  const txStatus = useSelector(transactionSelectors.transactionStatus);
  if (txStatus === 'confirmed') {
    // Need to debug !!!!! Important
    if (window.coinbase_windows) {
      window.coinbase_windows.close();
    }
    getOrderQuery();
    getMyCart();
    store.dispatch(
      updateEntities({
        txStatus: prevValue => null,
      }),
    );
  }

  const handleRemoveFromCart = id => {
    removeFromCart(id, cartDetails, deleteFromCart);
  };

  const onPayClick = () => {
    if (order.finalAmount === 0) {
      setPaymentGateway('zeroPayment');
      createTransaction({
        orderId: order._id,
        paymentGateway: 'zeroPayment',
      });
    } else {
      createTransaction({
        orderId: order._id,
        paymentGateway: paymentGateway,
      });
    }
  };

  const closePaymentTransaction = () => {
    getOrderQuery();
    store.dispatch(
      updateEntities({
        transactionInfo: prevValue => null,
        paymentMode: prevValue => null,
      }),
    );
  };


  const cancelPaymentTransaction = () => {
    if (order?._id) {
      cancelOrderTransaction({ id: order._id });
    }
    // getOrderQuery();
    store.dispatch(
      updateEntities({
        transactionInfo: prevValue => null,
        paymentMode: prevValue => null,
      }),
    );
  };

  if (
    order &&
    order.cart &&
    order.cart.items &&
    availableCoupons.length > 0 &&
    !defaultDiscountApplied
  ) {
    let selectedCoupon;
    let coupons = availableCoupons
      .filter(d => d.applyAuto)
      .sort((a, b) => b.discount - a.discount);
    if (coupons.length) {
      selectedCoupon = coupons[0];
      applyDiscountCoupon(selectedCoupon.couponCode);
    }
    setdefaultDiscountApplied(selectedCoupon.couponCode);
  }

  const { getRootProps, getRadioProps } = useRadioGroup({
    defaultValue:"stripe",
    onChange: data => {
      setPaymentGateway(data);
    },
  });
  const group = getRootProps();


  return (
    <Stack background={'gray.50'}>
      <DeleteCartDialogExample
        isOpen={isDeleteModalOpen}
        onClose={onCloseDeleteModal}
        onDelete={() => {
          if(deleteId){
            handleRemoveFromCart(deleteId);
          }
          
          onCloseDeleteModal();
        }}
      />
      {/*<BackButton path="/"> Go back to home</BackButton>*/}
      <Box p={{ base: 4, md: 16 }} bg="gray.50">
        {transactionInfo && (
          <OpenPayment
            paymentMode={paymentMode}
            transactionInfo={transactionInfo}
            closePayment={closePaymentTransaction}
            cancelPayment={cancelPaymentTransaction}
            setPaypalTxHash={txHash => {
              getOrderQuery();
              setPaypalTxHash(txHash);
            }}
          />
        )}

        {transactionInfo &&
          (paymentMode === 'zeroPayment' ||
            paymentMode === 'coinbase' ||
            paymentMode === 'credits') && (
            <StripePaymentStatus transactionInfo={transactionInfo} />
          )}
        {transactionInfo &&
          transactionInfo.paymentStatus !== 'confirmed' &&
          paymentMode == 'stripe' && (
            <StripePaymentStatus transactionInfo={transactionInfo} />
          )}
        {transactionInfo &&
          transactionInfo.paymentStatus !== 'confirmed' &&
          paypalTxHash &&
          paymentMode == 'paypal' && (
            <PaypalPaymentStatus paypalTxHash={paypalTxHash} />
          )}
        <Stack
          mr={{ base: '0', md: '4' }}
          direction={{ base: 'column', md: 'row' }}
        >
          <Stack p="4" bg="white" width="full">
            <Stack textAlign="left">
              <Text fontSize="2xl" fontWeight="bold">
                Reserve Your Domain
              </Text>
              <Text>Order Id : #{props.match.params.orderId}</Text>
            </Stack>
            {order &&
              order.cart &&
              order.cart.items.map(
                ({ domainName, price, domainOwner, _id }, i) => (
                  <Stack
                    alignItems="flex-start"
                    p="4"
                    key={_id}
                    boxShadow="sm"
                    borderRadius="sm"
                    bg="white"
                    Stack
                    justifyContent="space-between"
                    spacing="4"
                    direction={{ base: 'column', md: 'row' }}
                  >
                    <Stack
                      spacing="4"
                      alignItems="flex-start"
                      justifyContent="space-between"
                      width="full"
                      direction={{ base: 'column', md: 'row' }}
                    >
                      <Stack direction="column">
                        <Stack direction="row" alignItems="center" spacing="4">
                          <FaGlobeAmericas />
                          <Text
                            fontSize="3xl"
                            fontWeight="semibold"
                            color="brand.500"
                          >
                            {domainName}
                          </Text>
                        </Stack>
                      </Stack>
                      <Stack
                        width="full"
                        alignItems={{ base: 'center', md: 'flex-end' }}
                      >
                        <Flex alignItems="center">
                          <Text
                            fontSize="3xl"
                            fontWeight="semibold"
                            color="brand.600"
                            paddingRight="2"
                          >
                            ${price}
                          </Text>
                          
                            {order.status !== 'paymentDone' ? (
                              <IconButton
                                p="0"
                                icon={<AiOutlineDelete fontSize="20px" />}
                                colorScheme="red"
                                variant="ghost"
                                onClick={
                                  () => {
                                    setIsDeleteModalOpen(true)
                                    setDeleteId(_id)
                                  }     
                                }
                              >
                                Delete
                              </IconButton>
                            ) : (
                              ''
                            )}
                        </Flex>
                        <Text
                          color="gray.600"
                          maxW="xs"
                          fontSize="xs"
                          textAlign="right"
                        >
                          {order.status === 'paymentDone' ? (
                            <div>
                              {' '}
                              Your domain <b>{domainName}</b> has been reserved
                            </div>
                          ) : (
                            <div>
                              Reserve your domain <b>{domainName}</b>.
                            </div>
                          )}
                        </Text>
                      </Stack>
                    </Stack>
                  </Stack>
                ),
              )}
            <Text textAlign="left">
              After the domain reservation, you can find the reserved domains
              inside the <b>My Domain</b> tab in side menu. All information related to
              publishing/minting the domain is available there.
            </Text>
          </Stack>
          {order &&
          (order.status === 'created' || order.status === 'paymentFailed') ? (
            <Stack
              direction="column"
              width={{ base: '100%', md: '600px' }}
              alignItems={{ base: 'flex-start', md: 'flex-end' }}
              spacing="4"
            >
              <Stack
                alignItems="flex-start"
                p="4"
                boxShadow="sm"
                borderRadius="lg"
                bg="white"
                justifyContent="space-between"
                spacing="4"
                direction="column"
                width={{ base: '100%', md: '400px' }}
                {...group}
              >
                {order && order.status === 'paymentFailed' && (
                  <Text color="chocolate">
                    Payment Failed, please retry or contact support
                  </Text>
                )}
                <Text textAlign="left" fontSize="2xl" fontWeight="bold">
                  Select Payment
                </Text>
                <Text textAlign="left">
                  <b>Total Items:</b> {order ? order.cart.totalQty : 0}
                </Text>
                <Text textAlign="left">
                  <b>Total Cost:</b>{' '}
                  {order ? (
                    order.finalAmount == order.cart.totalCost ? (
                      order.cart.currency.toUpperCase() +
                      ' ' +
                      order.finalAmount
                    ) : (
                      <>
                        {order.cart.currency.toUpperCase() +
                          ' ' +
                          order.cart.totalCost}
                      </>
                    )
                  ) : (
                    0
                  )}
                </Text>
                <FormControl
                  variant="outlined"
                  style={{ width: '92%', textAlign: 'left' }}
                >
                  <InputLabel htmlFor="native-simple">
                    Select from available coupons for you
                  </InputLabel>
                  <Select
                    value={
                      defaultDiscountApplied
                        ? defaultDiscountApplied
                        : order && order.discount
                        ? order.discount.couponCode
                        : ''
                    }
                    onChange={e => {
                      setdefaultDiscountApplied(e.target.value);
                      applyDiscountCoupon(e.target.value);
                    }}
                    inputProps={{
                      name: 'Select from available Coupons for you',
                      id: 'native-simple',
                    }}
                    label="Select from available Coupons for you"
                  >
                    {availableCoupons.length ? (
                      availableCoupons.map(coupon => (
                        <option
                          key={coupon.couponCode}
                          value={coupon.couponCode}
                        >
                          {coupon.couponCode}
                        </option>
                      ))
                    ) : (
                      <option disabled>
                        Sorry, No available coupon this time!
                      </option>
                    )}
                  </Select>
                </FormControl>
                <Stack width="full">
                  <RadioCard
                    key="stripe"
                    {...getRadioProps({ value: 'stripe' })}
                  >
                      <Stack
                        direction="row"
                        width={{ base: '100%', md: '300px' }}
                      >
                        <span className="p_icon">
                          <img src={cards_icon} alt="card_icon" />
                        </span>
                        <span className="p_title"> Debit/Credit Card</span>
                      </Stack>
                  </RadioCard>
                </Stack>
                <Button
                  isLoading={queryState.isPending || queryStateT.isPending}
                  width={{ base: '100%' }}
                  isDisabled={
                    paymentGateway || (order && order.finalAmount == 0)
                      ? false
                      : true
                  }
                  onClick={onPayClick}
                  size="md"
                >
                  Reserve Your Domain -{' '}
                  {order && order.cart.currency.toUpperCase()}{' '}
                  {order && order.finalAmount}
                </Button>
              </Stack>
            </Stack>
          ) : order && order.status == 'paymentDone' ? (
            <Stack
              direction="column"
              width={{ base: '100%', md: '600px' }}
              alignItems="flex-center"
              p="4"
              boxShadow="lg"
              borderRadius="lg"
              bg="white"
              style={{ alignItems: 'center', paddingTop: '32px' }}
            >
              <Text>
                Payment of{' '}
                <b>
                  {order
                    ? order.cart.currency.toUpperCase() +
                      ' ' +
                      order.finalAmount
                    : 0}{' '}
                </b>
                has been received
              </Text>
              <img src={success_icon} width="115px" />
              <Text>
                Thank you for the booking Domain on Fordham.
                <br />
                <Link
                  to={'/my-domains/'}
                  style={{ color: 'var(--chakra-colors-brand-600)' }}
                >
                  <b>Please proceed to manage your domain.</b>
                </Link>
              </Text>
            </Stack>
          ) : (
            <>
              <Stack
                direction="column"
                width="600px"
                alignItems="flex-center"
                p="4"
                boxShadow="lg"
                borderRadius="lg"
                bg="white"
                style={{ alignItems: 'center', paddingTop: '32px' }}
              >
                <Spinner
                  thickness="4px"
                  speed="0.65s"
                  emptyColor="gray.200"
                  color="blue.500"
                  size="xl"
                />
                <br />
                <Text>
                  Please wait while we are fetching the status of the payment
                </Text>
              </Stack>
            </>
          )}
        </Stack>
      </Box>
    </Stack>
  );
}
