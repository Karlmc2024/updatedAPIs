import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { Text, Box, Stack } from '@chakra-ui/react';
import Checkout from './components/checkout';
import CartItems from './components/cartItems';
import PaymentInitiate from './components/PaymentInitiate.jsx';
import store from 'redux/reduxQueryStore';
import { updateEntities } from 'redux-query';

import { useMutation, useRequest } from 'redux-query-react';

import * as transactionQueryConfig from '../../query-configs/transaction';
import * as transactionSelectors from '../../selectors/transaction';
import { deleteFromCartMutation, moveToWishlistMutation } from 'entities/cartEntity';
import { getCartDetails } from 'entities/cartEntity';

import StripeComponent from './components/payments/stripe';
import PaypalComponent from './components/payments/paypal';
import CoinbaseComponent from './components/payments/coinbase';
import { removeFromCart } from 'components/Domain/cartUtils';
import { useHistory } from 'react-router';
import { isLoggedIn } from 'utils/Auth';
import { getCartRequest } from 'entities/cartEntity';
import { moveToWishlistEntity } from 'utils/Cart/cart';
import EmptyPage from 'components/common/EmptyPage';

// let cartRefresh = false;

export default function Cart() {
  const history = useHistory();
  const [openPayment, setOpenPaymet] = useState(false);
  const cartDetails = useSelector(getCartDetails);
  const [address,setAddress] = useState(null);
  // const [data, setData] = useState(cartDetails);
  const isLogged = isLoggedIn();

  const [queryState, createTransaction] = useMutation(data =>
    transactionQueryConfig.InitiateTransaction(data),
  );

  const [, deleteFromCart] = useMutation(deleteFromCartMutation);
  const [orderQueryState, createOrder] = useMutation(data =>
    transactionQueryConfig.CreateOrder(data),
  );

  const [,moveToWishlist] = useMutation(moveToWishlistMutation)

  // const [cartStateRequest, getMyCart] = useRequest(getCartRequest);

  // useEffect(() => {
  //   if (cartRefresh) return;
  //   cartRefresh = true;
  //   getMyCart();
  // }, []);

  const transactionInfo = useSelector(transactionSelectors.getTransactionInfo);
  const paymentMode = useSelector(transactionSelectors.getTransactionMode);

  const handleRemoveFromCart = id => {
    removeFromCart(id, cartDetails, deleteFromCart);
  };
  const handleMovetoWishlist = id=>{
      moveToWishlistEntity(id,cartDetails,moveToWishlist)
  }
  const onCheckoutClick = () => {
    if (!isLogged) {
      history.push(`/login?redirect=/cart`);
      return;
    }
    let data = cartDetails.map(domain => ({
      ...domain,
      domainOwner: "0x0",//address,
    }));
   createOrder({
          cartBody: data,
        });
  };
  const closePayment = () => {
    setOpenPaymet(false);
  };

  const onOwnerConnected = address => {
    setAddress(address);
  };

  const setPaymentMode = mode => {
    createTransaction({
      orderId: '61551b7aa0b26a3884839d61',
      paymentGateway: mode,
    });
  };

  const closePaymentTransaction = () => {
    closePayment();
    store.dispatch(
      updateEntities({
        transactionInfo: prevValue => null,
        paymentMode: prevValue => null,
      }),
    );
  };

  const OpenPayment = function (props) {
    const { transactionInfo, paymentMode, closePayment } = props;
    switch (paymentMode) {
      case 'stripe':
        return (
          <StripeComponent
            transactionInfo={transactionInfo}
            closePayment={closePayment}
          />
        );
      case 'paypal':
        return (
          <PaypalComponent
            transactionInfo={transactionInfo}
            closePayment={closePayment}
          />
        );
      case 'coinbase':
        return (
          <CoinbaseComponent
            transactionInfo={transactionInfo}
            closePayment={closePayment}
          />
        );
      default:
        return <div />;
    }
  };
  if(!cartDetails?.length){
    return <Stack bg="gray.50" p="8" minH="lg">
      <Text textAlign="left" fontSize="2xl" fontWeight="bold">
        Your cart
      </Text>
      <EmptyPage titleText="No items in your cart" subTitleText="" buttonText="Search for a domain" buttonLink={"/"}/>
    </Stack> 
  }
  return (
    <>
      {transactionInfo && (
        <OpenPayment
          paymentMode={paymentMode}
          transactionInfo={transactionInfo}
          closePayment={closePaymentTransaction}
        />
      )}
      <PaymentInitiate
        openPayment={openPayment}
        closePayment={closePayment}
        setPaymentMode={setPaymentMode}
      />
      <Stack bg="gray.50" p="8" minH="lg" width="100%" margin="auto"  alignItems='center'>
      <Text  textAlign="left" fontSize="2xl" fontWeight="bold">
          Your cart
        </Text>
        <Stack width="95%" alignItems='center' margin="auto"  bg="white" direction={{base:"Column",md:"row"}} spacing="8">
          <Box flex="3">
            <Text p={4}  textAlign="left" fontSize="2xl" fontWeight="bold">
              Reserve Your Domain
            </Text>
          <CartItems
            data={cartDetails}
            handleRemoveFromCart={handleRemoveFromCart}
            handleMovetoWishlist={handleMovetoWishlist}
            attachOwner={onOwnerConnected}
          />
        </Box>

        <Box flex="2" my="8">
            <Checkout
              data={cartDetails}
              handleRemoveFromCart={handleRemoveFromCart}
              onCheckoutClick={onCheckoutClick}
              isLoggedIn={isLogged}
            />
        </Box>
        </Stack>

      </Stack>
    </>
  );
}
