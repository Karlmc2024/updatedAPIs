import React from 'react'

export default function SellDomain() {
  return (
    <div>
      Coming soon...
    </div>
  )
}
