import React from 'react'

export default function Transfer() {
  return (
    <div>
      Coming soon...
    </div>
  )
}
