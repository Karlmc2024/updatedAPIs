import {
  SimpleGrid,
} from '@chakra-ui/react';
import React from 'react';
import { useSelector } from 'react-redux';
import { useRequest } from 'redux-query-react';
import DomainCard from 'components/Domain/DomainCard'
import * as transactionQueryConfig from '../../query-configs/transaction';
import * as transactionSelectors from '../../selectors/transaction';

export default function DomainCards({ searchData, isLoading }) {

  const [queryStatePD, getPremiumDomain] = useRequest(
    transactionQueryConfig.getPremiumDomain(),
  );

  const premiumDomains = useSelector(transactionSelectors.premiumDomains);


  return (
    <>
      <SimpleGrid
        columns={{ base: 1, md: 1, lg: 1 }}
        paddingX="96"
        spacing="16"
        alignItems="center"
      ></SimpleGrid>
      <SimpleGrid
        columns={{ base: 1, md: 2, lg: 3 }}
        paddingX="32"
        spacing="16"
        alignItems="center"
      >
        {premiumDomains.map((website,key) => (
          <DomainCard {...website} key={key} isPremium/>
        ))}
      </SimpleGrid>
    </>
  );
}
