import React, { useState, useCallback } from 'react';
import { Stack, Text } from '@chakra-ui/react';

import DomainCards from './Domains';

export default function PremiumDomains() {
  return (
    <Stack paddingBottom="20">
      <Stack
        padding="28"
        bgGradient="linear(to-r, brand.500, rgba(152,108,244,1))"
      >
        {/*<Text*/}
        {/*  fontSize="5xl"*/}
        {/*  fontWeight="semibold"*/}
        {/*  color="white"*/}
        {/*  textTransform="uppercases"*/}
        {/*>*/}
        {/*  PREMIUM DOMAINS NFT SALE*/}
        {/*</Text>*/}
        <Text fontSize="xl" fontWeight="semibold" color="white">
          Rare & exclusive NexBloc domain name NFTs, available for the first
          time ever.
        </Text>
      </Stack>
      <DomainCards searchData={''} isLoading={false} />
    </Stack>
  );
}
