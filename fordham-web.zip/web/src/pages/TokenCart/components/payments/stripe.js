import React, { useState } from 'react';
import { Dialog, DialogTitle } from '@material-ui/core';
import { Input, Stack, Button, Text } from '@chakra-ui/react'
import {BsFillPatchCheckFill} from "react-icons/bs";
import {IoIosCloseCircle} from "react-icons/io"

import {   CardNumberElement,
  CardCvcElement,
  CardExpiryElement,
  Elements,
   } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import {  useStripe, useElements } from '@stripe/react-stripe-js';

import { STRIPE_PK } from '../../../../constants/keys';

import './stripe.css';

const ELEMENT_OPTIONS = {
  style: {
    base: {
      fontSize: '18px',
      color: '#424770',
      letterSpacing: '0.025em',
      '::placeholder': {
        color: '#aab7c4',
      },
    },
    invalid: {
      color: 'red',
    },
  },
}


export default function StripeComponent({ closePayment, transactionInfo,cancelPayment }) {
  const stripePromise = loadStripe(STRIPE_PK);
  return (
    <>
      <Dialog
        onClose={closePayment}
        open={transactionInfo ? true : false}
        disableBackdropClick
      >
        <DialogTitle>Pay with your Credit Card</DialogTitle>
        <div style={{ width: '500px', padding: '15px' }}>
          <Elements stripe={stripePromise}>
            <Stripe
              clientSecret={
                transactionInfo ? transactionInfo?.transactionInfo?.client_secret : ''
              }
              closePayment={closePayment}
              cancelPayment={cancelPayment}
            />
          </Elements>
        </div>
      </Dialog>
    </>
  );
}

function Stripe(props) {
  const [succeeded, setSucceeded] = useState(false);
  const [error, setError] = useState(null);
  const [processing, setProcessing] = useState('');
  const [disabled, setDisabled] = useState(true);
  const stripe = useStripe();
  const elements = useElements();
  const [postalCode, setPostalCode] = useState('')

  const handleChange = async event => {
    setDisabled(event.empty);
    setError(event.error ? event.error.message : '');
  };

  const handleSubmit = async ev => {
    ev.preventDefault();
    setProcessing(true);
    const payload = await stripe.confirmCardPayment(props.clientSecret, {
      payment_method: {
        card: elements.getElement(CardNumberElement),
        billing_details:{
          "address":{
            "postal_code":postalCode
          }
        }
      },
    });
    if (payload.error) {
      setError(`Payment failed ${payload.error.message}`);
      setProcessing(false);
      // dispatch(stripeStatus('failed'));
    } else {
      setError(null);
      setProcessing(false);
      setSucceeded(true);
      // dispatch(stripeStatus('success'));
    }
  };

  const handleCloseMe = () => {
    props.closePayment();
  };


  if(succeeded){
    return (
    <Stack align="center">
      <BsFillPatchCheckFill size="108" color="#4BB543"/>
      <Text>Payment is successful</Text>
      <Button onClick={handleCloseMe}>Close</Button>
    </Stack>

  )
    
  }

  if(error){
    return <Stack align="center">
    <IoIosCloseCircle size="108" color="red"/>
    <Text>Error has occurred</Text>
    <Text>{error}</Text>
    <Button onClick={handleCloseMe}>Close</Button>
  </Stack>
    
  }

  return (
    <form
      className="stripe"
      id="payment-form"
      onSubmit={handleSubmit}
      style={{ margin: 'auto' }}
    >
      <label htmlFor="cardNumber">Card Number</label>
      <CardNumberElement
          id="cardNumber"
          options={ELEMENT_OPTIONS}
      />
      <label htmlFor="expiry">Card Expiration</label>
      <CardExpiryElement
          id="expiry"
          options={ELEMENT_OPTIONS}
      />
      <label htmlFor="cvc">CVC</label>
      <CardCvcElement
          id="cvc"
          options={ELEMENT_OPTIONS}
      />
      <label htmlFor="postal">Postal Code</label>
      <Input
          mb="4"
          bg="white"
          padding="2"
          variant="unstyled"
          boxShadow="md"
          id="postal"
          placeholder="12345"
          value={postalCode}
          onChange={(event) => {
            setPostalCode(event.target.value)
          }}
      />
      <button
        className="stripe"
        disabled={processing || disabled || succeeded}
        id="submit"
      >
        <span id="button-text">
          {processing ? <div className="spinner" id="spinner"/> : 'Pay'}
        </span>
      </button>
      {/* Show any error that happens when processing the payment */}
      {error && (
        <div className="card-error" role="alert">
          {error}
        </div>
      )}
      {/* Show a success message upon completion */}
      <p className={!succeeded ? 'result-message' : 'result-message hidden'}>
        Please do not refresh while making transaction.{' '}
        <span style={{ cursor: 'pointer' }} onClick={props.cancelPayment}>
          Cancel
        </span>
      </p>
    </form>
  );
}
