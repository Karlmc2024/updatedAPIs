import React from 'react';

export default function CoinbaseComponent({ closePayment, transactionInfo }) {
  // window.location = transactionInfo.transactionInfo.hosted_url;
  let strWindowFeatures = "fullscreen=yes,location=no,height=720,width=1200,scrollbars=no,status=yes";
  window.coinbase_windows = window.open(transactionInfo.transactionInfo.hosted_url, "_blank", strWindowFeatures);
  return <div />;
}
