import { Heading, useColorModeValue } from '@chakra-ui/react';
import * as React from 'react';

const FooterHeading = (props) => (
  <Heading
    as="h4"
    color={useColorModeValue('brand.500', 'brand.400')}
    fontSize="sm"
    fontWeight="semibold"
    textTransform="uppercase"
    letterSpacing="wider"
    {...props}
  />
);

export default FooterHeading;
