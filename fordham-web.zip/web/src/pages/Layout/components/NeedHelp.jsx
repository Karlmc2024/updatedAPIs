import {
  Stack, Text, Button, SimpleGrid,
} from '@chakra-ui/react';
import React from 'react';

export default function NeedHelp() {
  return (
    <SimpleGrid columns={{ base: 1, lg: 2 }} minHeight="60">
      <Stack alignItems="center" justifyContent="center"  bg="white">
        <Text fontWeight="bold" fontSize="4xl">
          Need any help?
        </Text>
        <Text maxWidth="sm" color="gray.500">
            Decentralised naming for wallets websites, & more.
        </Text>
      </Stack>
      <Stack direction="row" justifyContent="center" alignItems="center">
         <Text> Email to : support@fordhem.edu</Text>
        {/*<Button variant="outline">*/}
        {/*  Live Chat*/}
        {/*</Button>*/}
      </Stack>
    </SimpleGrid>
  );
}
