import React from 'react';
import { Flex, Box } from '@chakra-ui/react';
import WishlistItems from './components/WishlistItems';
import { getWishlist, deleteFromWishlistMutation, moveToCartMutation } from 'pages/Wishlist/entities';
import { useSelector } from 'react-redux';
import {removeFromWishlist, moveToCartEntity} from './utils'
import { useMutation } from 'redux-query-react';

export default function Wishlist() {
  
  const wishlist = useSelector(getWishlist)
  const [,deleteFromWishlistApi] = useMutation(deleteFromWishlistMutation)
  const [,moveToCartApi] = useMutation(moveToCartMutation)
  const handleRemoveFromWishlist = (id)=>{
    removeFromWishlist(id,wishlist,deleteFromWishlistApi)
    }

  
    const handleMoveToCart = (id)=>{
      moveToCartEntity(id,wishlist,moveToCartApi)
      }
    
  return (
    <>
      <Flex bg="gray.50" p="8" minH="lg" >
        <Box width="full">
          <WishlistItems
            data={wishlist}
            handleRemoveFromWishlist={handleRemoveFromWishlist}
            handleMoveToCart={handleMoveToCart}
          />
        </Box>
      </Flex>
    </>
  );
}
