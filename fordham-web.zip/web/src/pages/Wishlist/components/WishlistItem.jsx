import { Stack, Text, IconButton, Image,Button } from '@chakra-ui/react';
import React from 'react';
import { AiOutlineDelete } from 'react-icons/ai';
import { FaGlobeAmericas } from 'react-icons/fa';
import { useSelector } from 'react-redux';
import { getCartDetails } from 'entities/cartEntity';

export default function WishlistItem({
  domainName,
  price,
  _id,
  handleRemoveFromWishlist,
  handleMoveToCart
}) {
  const cartData = useSelector(getCartDetails);
  const existsInCart = cartData?.some(item => item.domainName === domainName);
  return (
    <Stack
      alignItems={{base:"center",md:"flex-start"}}
      p="4"
      boxShadow="sm"
      borderRadius="lg"
      bg="white"
      justifyContent="space-between"
      spacing="4"
      direction="row"
    >
      <Stack
        direction={{base:"column",md:"row"}}
        alignItems={{base:"center",md:"flex-start"}}
        justifyContent="space-between"
        spacing="0"
        width="full"
      >
        <Stack direction="column">
          <Stack direction="row" alignItems="center" spacing="4">
            <FaGlobeAmericas/>
            <Text fontSize="3xl" fontWeight="semibold" color="brand.500">
              {domainName}
            </Text>
          </Stack>
        </Stack>
        <Stack direction={{base:"column",md:"row"}}>
          <Stack alignItems={{md:"flex-end"}}>
            <Text fontSize="3xl" fontWeight="semibold" color="brand.600">
              ${price}
            </Text>
            <Stack>
              <Text color="gray.600" maxW="xs" fontSize="xs" textAlign="right">
                 Move {domainName} domain to your  cart
              </Text>
              <Button onClick={()=>{handleMoveToCart(_id)}} disabled={existsInCart}>
               Move to Cart
              </Button>
            </Stack>
          </Stack>
          <IconButton
            p="0"
            icon={<AiOutlineDelete fontSize="20px" />}
            colorScheme="red"
            variant="ghost"
            onClick={() => {
              handleRemoveFromWishlist(_id);
            }}
          >
            Delete
          </IconButton>
        </Stack>
      </Stack>
    </Stack>
  );
}
