import { Stack, Text } from '@chakra-ui/react';
import React from 'react';
import WishlistItem from './WishlistItem';
import EmptyPage from 'components/common/EmptyPage';

export default function WishlistItems({
  data,
  handleRemoveFromWishlist,
  handleMoveToCart
}) {
  return (
    <Stack mr="8">
      <Text textAlign="left" fontSize="2xl" fontWeight="bold">
        Your wishlist
      </Text>
      {data.length === 0 ? <EmptyPage titleText="No items in your wishlist" subTitleText="" buttonText="Search for a domain" buttonLink={"/"}/>:""}
      <Stack>
        {data.map((website, i) => (
          <WishlistItem
            key={i}
            {...website}
            handleRemoveFromWishlist={handleRemoveFromWishlist}
            handleMoveToCart={handleMoveToCart}
          />
        ))}
      </Stack>
    </Stack>
  );
}
