import {addToWishlistEntity,updateWishlistEntity} from './entities';
import { getWishlistItems } from 'utils/Wishlist/wishlist';
import { addToCartEntity } from 'entities/cartEntity';
export const addToWishlist = (newDomain,addToWishlistApi)=>{
  const token = localStorage.getItem('token')
  if(token){
    addToWishlistApi(newDomain)
  }
  else{
    addToWishlistEntity(newDomain)
  }
}

export const removeFromWishlist = (id,wishlist,removeFromWishlistApi)=>{
  const token = localStorage.getItem('token')
  if(token){
    removeFromWishlistApi({id})
  }
  else{
    const updatedWishlistItems = wishlist.filter(item => item._id !== id);
    updateWishlistEntity(updatedWishlistItems);
  }
}

export const moveToCartEntity = (id,wishlist,moveToCartApi)=>{
  const token = localStorage.getItem('token')
  if(token){
    moveToCartApi({id})
  }
  else{
    const newCartItemIndex = wishlist.findIndex(item => item._id === id);
    const newCartItem = wishlist.splice(newCartItemIndex,1);
    if(newCartItem.length>0){
      addToCartEntity(newCartItem[0]);
    }
    
    updateWishlistEntity([...wishlist]);
  }
}

export const updateWishlist = (updateWishlistApi)=>{
  const token = localStorage.getItem('token')
  const wishlist = getWishlistItems();
  if(token&&wishlist?.length){
    updateWishlistApi(wishlist)
    localStorage.setItem('wishlist',[])
  }
  else{
    updateWishlistEntity(wishlist);
  }
}