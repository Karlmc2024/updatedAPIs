import React from 'react';
import { Stack, Text } from '@chakra-ui/react';
import { Th, Td, Tr, Table } from 'components/common/Table';

import { Link } from 'react-router-dom';

import { useSelector } from 'react-redux';
import { useRequest } from 'redux-query-react';

import * as transactionQueryConfig from '../../query-configs/transaction';
import * as transactionSelectors from '../../selectors/transaction';

import BackButton from 'components/common/BackButton';
import {getUserCreditHistory} from "../../query-configs/transaction";

export default function TransactionHistory() {

  const [queryStateGetUserCredits, getUserCredits] = useRequest(
    transactionQueryConfig.getUserCreditHistory(),
  );

  let myCreditsData = useSelector(transactionSelectors.getMyCredits);

  const transactionData =
    (myCreditsData && myCreditsData.transactionHistory) || [];

  React.useEffect(() => {
    getUserCredits();
  }, []);

  return (
    <>
      <Stack p="8" background="gray.50" minH="lg" overflowX="scroll">
        <BackButton path="/profile/view">Back</BackButton>
        <Text textAlign="left" fontSize="2xl" fontWeight="bold">
          Credits Transaction History
        </Text>
        <Table bg="white">
          <thead>
            <Tr>
              <Th>#</Th>
              <Th>Transaction Id</Th>
              {/*<Th>Status</Th>*/}
              <Th>Purchased Credits</Th>
              <Th>Allocated Tokens</Th>
               <Th>Purchased At</Th>
            </Tr>
          </thead>
          <tbody>
            {transactionData.length ? (
              transactionData
                .filter(data => data.status === 'paymentDone')
                .map((data,i) => {
                  const {
                    purchasedCredit,
                    allocatedTokens,
                    transactionId,
                    status,
                    createdAt,
                  } = data;
                  return (
                    <Tr key={transactionId}>
                      <Td>{i+1}</Td>
                      <Td>
                        {transactionId}
                      </Td>
                      {/*<Td>*/}
                      {/*  <Text textTransform={'capitalize'}>{status}</Text>*/}
                      {/*</Td>*/}
                      <Td>{purchasedCredit}</Td>
                      <Td>{allocatedTokens}</Td>
                       <Td>{new Date(createdAt).toLocaleDateString()}</Td>
                    </Tr>
                  );
                })
            ) : (
              <Tr>
                <Td colSpan="5">
                  <Text textAlign="center">No Credit Transactions found</Text>
                  <Text textAlign="center">
                    <Link textAlign="center" to={'/profile/view'}>
                      {' '}
                      Back to Account Page
                    </Link>
                  </Text>
                </Td>
              </Tr>
            )}
          </tbody>
        </Table>
      </Stack>
    </>
  );
}
