import React from 'react';
import {
  Button,
  useDisclosure,
  Stack,
  Text,
  SimpleGrid,
} from '@chakra-ui/react';
import BasicModal from 'components/common/Modal';
import * as transactionQueryConfig from '../../query-configs/transaction';
import * as transactionSelectors from '../../selectors/transaction';
import { useSelector } from 'react-redux';

import { useRequest } from 'redux-query-react';
import { useEffect } from 'react';
const BodyComponent = ({ orderId }) => {
  const [{ isPending, isFinished }, refresh] = useRequest(transactionQueryConfig.GetOrder(orderId));
  let orderData = useSelector(transactionSelectors.getOrder) || {};
  const { cart = {}, createdAt } = orderData;
  const { items = [], currency, totalCost, totalQty } = cart;

  useEffect(()=>{
    if(!isPending){
      refresh();
    }
  },[])

  const allDomainNames = items.map(item => item.domainName).join(', ');

  return (
    <Stack spacing="4">
      <Stack>
        <Text fontWeight="semibold" color="gray">Order id</Text>
        <Text fontSize="lg" fontWeight="semibold" color="brand.500">{orderId}</Text>
      </Stack>
      <Stack>
        <Text fontWeight="semibold" color="gray">Domains</Text>
        <Text fontSize="2xl" fontWeight="semibold" color="brand.500">{allDomainNames}</Text>
      </Stack>
      <SimpleGrid columns={2} spacing={10}>
        <Stack alignItems="center" boxShadow="lg" padding="4">
          <Text>Total price</Text>
          <Stack direction="row" align="center">
            <Text fontSize="7xl" fontWeight="semibold" color="brand.500">
              {totalCost}
            </Text>
            <Text fontSize="xl" fontWeight="semibold" color="brand.500">
              {currency}
            </Text>
          </Stack>
        </Stack>
        <Stack alignItems="center" boxShadow="lg" padding="4">
          <Text>Total quantity</Text>
          <Text fontSize="7xl" fontWeight="semibold" color="brand.500">
            {totalQty}
          </Text>
        </Stack>
      </SimpleGrid>
    </Stack>
  );
};

const FooterComponent = ({ onClose }) => (
  <>
    <Button onClick={onClose} mr={3}>
      Close
    </Button>
  </>
);

const OpenButton = ({ onOpen, orderId }) => (
  <Button onClick={onOpen} p="0" variant="ghost">
    {orderId}
  </Button>
);

export default function CreditOrderModal({ orderId }) {
  const { isOpen, onOpen, onClose } = useDisclosure();

  return (
    <>
      <BasicModal
        size="lg"
        BodyComponent={<BodyComponent orderId={orderId} />}
        header="Transaction details"
        FooterComponent={<FooterComponent onClose={onClose} />}
        isOpen={isOpen}
        onOpen={onOpen}
        onClose={onClose}
        OpenButton={<OpenButton onOpen={onOpen} orderId={orderId} />}
      />
    </>
  );
}
