import React, { useState } from 'react';
import { Stack, Text, Button } from '@chakra-ui/react';
import { Th, Td, Tr, Table } from 'components/common/Table';

import { Link } from 'react-router-dom';

import { useSelector } from 'react-redux';
import { useRequest } from 'redux-query-react';

import * as transactionQueryConfig from '../../query-configs/transaction';
import * as transactionSelectors from '../../selectors/transaction';

import BackButton from 'components/common/BackButton';
import CreditOrderModal from './CreditOrderDataModal';

export default function CreditUseTransactions() {

  const [queryStateGetUserCredits, getUserCredits] = useRequest(
    transactionQueryConfig.getUserCredits(),
  );
  let myCreditsData = useSelector(transactionSelectors.getMyCredits);

  const creditUsesHistory =
    (myCreditsData && myCreditsData.creditUsesHistory) || [];

  React.useEffect(() => {
    getUserCredits();
  }, []);

  return (
    <>
      <Stack p="8" background="gray.50" minH="lg" overflowX="scroll">
        <BackButton path="/profile/view">Back</BackButton>
        <Text textAlign="left" fontSize="2xl" fontWeight="bold">
          Credits Use History
        </Text>
        <Table bg="white">
          <thead>
            <Tr>
              <Th>Order Id</Th>
              <Th>Used Credits</Th>
              <Th>Initial Credit</Th>
              <Th>Remaining Credits</Th>
              {/* <Th>Created At</Th> */}
            </Tr>
          </thead>
          <tbody>
            {creditUsesHistory.length ? (
              creditUsesHistory.map(data => {
                const {
                  orderId,
                  usedCredit,
                  remainingCredit,
                  initialCredit,
                  createdAt,
                } = data;
                return (
                  <Tr key={orderId}>
                    <Td>
                      <CreditOrderModal orderId={orderId}/>
                    </Td>
                    <Td>{usedCredit}</Td>
                    <Td>{initialCredit}</Td>
                    <Td>{remainingCredit}</Td>
                    {/* <Td>{new Date(createdAt).toLocaleDateString()}</Td> */}
                  </Tr>
                );
              })
            ) : (
              <Tr>
                <Td colSpan="5">
                  <Text textAlign="center">No Credit Usage found</Text>
                  <Text textAlign="center">
                    <Link textAlign="center" to={'/profile/view'}>
                      {' '}
                      Back to Account Page
                    </Link>
                  </Text>
                </Td>
              </Tr>
            )}
          </tbody>
        </Table>
      </Stack>
    </>
  );
}
