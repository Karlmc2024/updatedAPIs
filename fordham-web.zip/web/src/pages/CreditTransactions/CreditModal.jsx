import React from 'react';
import {
  AlertDialog,
  AlertDialogBody,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogContent,
  AlertDialogOverlay,
  Button,
} from '@chakra-ui/react';

export default function CreditModal({
  onClose,
  children,
  isOpen,
  onDelete,
  modalHeading,
}) {
  return (
    <>
      {children}

      <AlertDialog isOpen={isOpen} onClose={onClose}>
        <AlertDialogOverlay>
          <AlertDialogContent>
            <AlertDialogHeader fontSize="lg" fontWeight="bold">
              {modalHeading}
            </AlertDialogHeader>

            <AlertDialogBody>Credit Data Body</AlertDialogBody>

            <AlertDialogFooter>
              <Button onClick={onClose} colorScheme="gray">
                Close
              </Button>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialogOverlay>
      </AlertDialog>
    </>
  );
}
