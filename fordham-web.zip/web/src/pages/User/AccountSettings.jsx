import React from 'react';
import { Stack, Heading } from '@chakra-ui/react';
import Notificaitons from './Notificaitons';

export default function AccountSettings({ updateUserApi, user }) {
  return (
    <Stack
      // width="xl"
      minH="sm"
      boxShadow="lg"
      p="8"
      bg="white"
      borderRadius="lg"
      spacing="6"
    >
      <Heading fontSize="xl">Account Settings</Heading>
      <Notificaitons updateUserApi={updateUserApi} user={user} />
    </Stack>
  );
}
