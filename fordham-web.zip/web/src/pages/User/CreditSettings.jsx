import React from 'react';
import {
  Stack,
  Heading,
  Stat,
  StatLabel,
  StatNumber,
  Text,
  Link,
} from '@chakra-ui/react';
import aveta from 'aveta';
import { useSelector } from 'react-redux';
import { useRequest } from 'redux-query-react';
import { Link as RouterLink } from 'react-router-dom';

import * as transactionQueryConfig from '../../query-configs/transaction';
import * as transactionSelectors from '../../selectors/transaction';

export default function CreditSettings({
  totalDomains,
  totalTransactionValue,
}) {
  const [queryStateGetUserCredits, getUserCredits] = useRequest(
    transactionQueryConfig.getUserCredits(),
  );
  let myCreditsData = useSelector(transactionSelectors.getMyCredits);
  const myCredits = (myCreditsData && myCreditsData.amount) || 0;
  const myToken = (myCreditsData && myCreditsData.nexbTokens) || 0;

  React.useEffect(() => {
    getUserCredits();
  }, []);

  return (
    <Stack
    >
      {/*<Heading fontSize="xl">Credit Info</Heading>*/}
      {/*<Stack>*/}
      {/*  <Stat textAlign="" boxShadow="sm">*/}
      {/*    <StatLabel>Available Credits</StatLabel>*/}
      {/*    <StatNumber fontSize="5xl">{myCredits ? aveta(myCredits, {*/}
      {/*      precision: 2,*/}
      {/*      lowercase: true,*/}
      {/*    }) : '0'}</StatNumber>*/}
      {/*  </Stat>*/}
      {/*</Stack>*/}
    </Stack>
  );
}
