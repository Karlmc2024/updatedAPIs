import React from 'react'
import { Stack, FormErrorMessage,FormControl,
  FormLabel,
  Input,
  Button, } from '@chakra-ui/react'
import { useForm } from "react-hook-form";
import { useHistory } from 'react-router-dom';
import { editProfileSchema } from './validation';
import { yupResolver } from '@hookform/resolvers/yup';
export default function ProfileEdit({firstName,lastName,phone, updateUserApi,isUpdating}) {

  const history = useHistory()
  

  const { register, handleSubmit, formState: { errors } } = useForm({
    defaultValues:{firstName,lastName,phone},
    resolver: yupResolver(editProfileSchema)
  });
  const onSubmit = data => updateUserApi(data);

  const handleCancel = ()=>{
    history.push('/profile/view')
  }

  return (
    <Stack minW={{base:"84",lg:"sm"}} alignItems="center" padding="8" spacing="8" as="form" onSubmit={handleSubmit(onSubmit)}>
        <Stack direction={{base:"column",lg:"row"}}>
        <FormControl id="firstname" isInvalid={errors.firstName}>
          <FormLabel>First name</FormLabel>
            <Input {...register("firstName")} />
            <FormErrorMessage>{errors?.firstName?.message}</FormErrorMessage>
        </FormControl>
        <FormControl id="lastname" isInvalid={errors.lastName}>
          <FormLabel>Last name</FormLabel>
            <Input {...register("lastName")} />
            <FormErrorMessage>{errors?.lastName?.message}</FormErrorMessage>
        </FormControl>
        </Stack>
        <Stack direction={{base:"column",lg:"row"}}>
        <FormControl id="website">
          <FormLabel>Website</FormLabel>
            <Input {...register("website")} />
        </FormControl>
        <FormControl id="phone" isInvalid={errors.phone}>
          <FormLabel>Phone</FormLabel>
            <Input {...register("phone")} />
            <FormErrorMessage>{errors?.phone?.message}</FormErrorMessage>
        </FormControl>
        </Stack>
        <Stack direction={{base:"column",lg:"row"}}>
          <Button colorScheme="red" onClick={handleCancel}>
            Cancel
          </Button>
          <Button type="submit" isLoading={isUpdating} loadingText="Saving...">
            Save
          </Button>
        </Stack>
      </Stack>
  )
}
