import React from 'react'
import { HStack,Stack, Text, Switch } from '@chakra-ui/react'

function NotificationSwitchElement({title,subTitle, isChecked, onChange,name}){
    return(
        <HStack justifyContent="space-between" alignItems="flex-start" borderBottom="1px solid" borderBottomColor="gray.200" pb="2"> 
            <Stack textAlign="left">
              <Text>
                {title}
              </Text>
              <Text color="gray" fontSize="sm">
                {subTitle}
              </Text>
            </Stack>
            <Switch isChecked={isChecked} onChange={()=>{onChange({[name]:!isChecked})}}/>
        </HStack>
    )
}

export default function Notificaitons({user, updateUserApi}) {
  const {newsLetterSubscribed, emailNotifications} = user || {}
  return <Stack> 
    <Stack textAlign="left">
    <Text fontSize="lg">
        Notifications
      </Text>
      <Text color="gray" fontSize="sm">
        Receive Fordham notifications via email.
      </Text>
    </Stack>
      <NotificationSwitchElement title="Email" subTitle="Receive email  regarding our next updates" isChecked={emailNotifications} name={"emailNotifications"} onChange={updateUserApi}/>
      <NotificationSwitchElement title="Subscribe" subTitle="Subscribe to our news letter" isChecked={newsLetterSubscribed} name={"newsLetterSubscribed"} onChange={updateUserApi}/>
    </Stack>
}
