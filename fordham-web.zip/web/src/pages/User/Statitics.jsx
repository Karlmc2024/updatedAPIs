import React from 'react';
import {
  Stack,
  Heading,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  StatArrow,
} from '@chakra-ui/react';

import { useSelector, useDispatch } from 'react-redux';
import { useRequest, useMutation } from 'redux-query-react';

import * as transactionQueryConfig from '../../query-configs/transaction';
import * as transactionSelectors from '../../selectors/transaction';

export default function Statitics({ totalDomains, totalTransactionValue }) {
  return (
    <Stack
      // width="l"
      boxShadow="lg"
      minH="sm"
      p="8"
      bg="white"
      borderRadius="lg"
      spacing="6"
    >
      <Heading fontSize="xl">Statistics</Heading>
      <Stack>
        <Stat boxShadow="sm">
          <StatLabel>Total Domains</StatLabel>
          <StatNumber fontSize="5xl">{totalDomains}</StatNumber>
          {/*<StatHelpText>*/}
          {/*  <StatArrow type='increase' />*/}
          {/*  High*/}
          {/*</StatHelpText>*/}
        </Stat>
        <Stat boxShadow="sm">
          <StatLabel>Total Transaction value</StatLabel>
          <StatNumber fontSize="5xl">{totalTransactionValue || '$0'}</StatNumber>
          {/*<StatHelpText>*/}
          {/*  <StatArrow type='increase' />*/}
          {/*  High*/}
          {/*</StatHelpText>*/}
        </Stat>
      </Stack>
    </Stack>
  );
}
