import React from 'react';
import {
  Stack,
  Badge,
  Heading,
  Text,
  Button,
  Box,
  HStack,
} from '@chakra-ui/react';
import { IoCalendar } from 'react-icons/io5';
import { format } from 'date-fns';
import { useRequest, useMutation } from 'redux-query-react';
import * as transactionQueryConfig from 'query-configs/transaction';
// import { useSelector } from 'react-redux';
// import * as transactionSelectors from 'selectors/transaction';
import { resendVerificationEmailMutation } from './userEntity';
import { Link } from "react-router-dom";
import {useHistory} from 'react-router-dom';

function ProfileViewLink({ icon, text }) {
  return (
    <HStack fontSize="md" color="brand.500" alignItems="flex-start" >
      {icon}
      <Text fontSize="sm">{text}</Text>
    </HStack>
  );
}

export default function ProfileView({
  firstName,
  lastName,
  phone,
  email,
  createdAt = new Date(),
  verified = false,
}) {
  var formattedCreatedAt = format(new Date(createdAt), 'dd MMM yyyy');
  useRequest(transactionQueryConfig.getMyDomains());
  const [{ isPending }, resendVerificationEmail] = useMutation(
    resendVerificationEmailMutation,
  );
  const history  = useHistory();
  // const myDomains = useSelector(transactionSelectors.getMyDomains);
  return (
    <div>
      <Heading fontWeight="semibold">
        {firstName} {lastName}
      </Heading>
      <Stack>
        <Stack>
          <Stack direction="row" align="center" justify="center">
            <Text color="gray.600">{email}</Text>
            {verified ? null : <Badge colorScheme="red">Not verified</Badge>}
          </Stack>
          {verified ? null : (
            <Box>
              <Button
                size="sm"
                onClick={resendVerificationEmail}
                isLoading={isPending}
                loadingText="Sending email..."
              >
                Resend verification email
              </Button>
            </Box>
          )}

          {/*<Box>*/}
          {/*    <Button*/}
          {/*      size="sm"*/}
          {/*      onClick={()=> history.push('/trademark-requests') }*/}
          {/*     >*/}
          {/*    Trademark requests*/}
          {/*    </Button>*/}
          {/*  </Box>*/}
        </Stack>
      </Stack>
      <Stack direction={{base:"column",lg:"row"}} width="full" justifyContent="space-between" align={{base:"center"}} mt="4">
        <ProfileViewLink
          text={`Joined: ${formattedCreatedAt}`}
          icon={<IoCalendar />}
        />
        <Button variant="link">
        <Link to="/change-password">
          <Text>
            Change password
          </Text>
        </Link>
      </Button>
      </Stack>
    </div>
  );
}
