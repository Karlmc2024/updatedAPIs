import React from 'react';
import { useRequest } from 'redux-query-react';
import { useSelector } from 'react-redux';
import {
  getUserRequest,
  getUser,
  getTotalTransactionValue,
} from './userEntity';
import { Stack, Button, Box, Avatar, HStack } from '@chakra-ui/react';
import ProfileView from './ProfileView';
import ProfileEdit from './ProfileEdit';
import { Switch, Route } from 'react-router-dom';
import { FiEdit2 } from 'react-icons/fi';
import { useHistory } from 'react-router-dom';
import {
  updateUserMutation,
  getTotalTransactionValueRequest,
} from './userEntity';
import { useMutation } from 'redux-query-react';
import AccountSettings from './AccountSettings';
import Statitics from './Statitics';
import CreditSettings from './CreditSettings';
import BackButton from 'components/common/BackButton';

export default function Profile() {
  const history = useHistory();

  const user = useSelector(getUser) || {};
  const { total: totalTransactionValue = 0 } =
    useSelector(getTotalTransactionValue) || {};
  useRequest(getUserRequest());
  useRequest(getTotalTransactionValueRequest());
  const { firstName, lastName, totalDomains } = user;

  const [{ isPending }, updateUserApi] = useMutation(updateUserMutation);

  const name = `${firstName} ${lastName}`;

  const handleEdit = () => {
    history.push('/profile/edit');
  };

  return (
    <Stack>
       <BackButton path="/">
        Back
      </BackButton>
      <Box
        height="48"
        bg="brand.500"
      ></Box>
      <Stack bg="gray.50" alignItems="center" padding="4" spacing="4">
        <Box
          minH="24"
          w={{base:"72",lg:"lg"}}
          alignItems="center"
          padding="4"
          spacing="4"
          mt="-12"
          bg="white"
          borderRadius="lg"
        >
          <Stack justifyContent="flex-end" width="full" textAlign="right">
            <Box>
              <Button
                colorScheme="gray"
                size="sm"
                rightIcon={<FiEdit2 />}
                onClick={handleEdit}
              >
                Edit
              </Button>
            </Box>
          </Stack>
          <Avatar name={name} size="2xl" mt={-36} border="6px solid white" />
          <Switch>
            <Route
              exact
              path="/profile/view"
              render={() => <ProfileView {...user} />}
            />
            <Route
              exact
              path="/profile/edit"
              render={() => (
                <ProfileEdit
                  {...user}
                  updateUserApi={updateUserApi}
                  isUpdating={isPending}
                />
              )}
            />
          </Switch>
        </Box>
        <Stack
          bg="gray.50"
          alignItems="center"
          padding="12"
          spacing="4"
          minH="lg"
        >
          <Stack direction={{"base":"column", lg:"row"}}>
            <Statitics
              totalDomains={totalDomains}
              totalTransactionValue={totalTransactionValue}
            />
            <AccountSettings updateUserApi={updateUserApi} user={user} />
          </Stack>
        </Stack>
      </Stack>
    </Stack>
  );
}
