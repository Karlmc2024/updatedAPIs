import React from 'react';
import { Button } from '@chakra-ui/react';
import app from '../../base';

export default function Dashboard() {
  return (
    <div>
      <Button onClick={() => app.auth().signOut()}>Logout</Button>
    </div>
  );
}
