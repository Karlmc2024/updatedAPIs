import * as yup from 'yup';


export const passwordValidation = yup.string()
.required('No password provided.') 
.min(8, 'Password is too short - should be 8 chars minimum.')
.matches(
  /(?=^.{8,64}$)(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&])(?!.*\s).*$/,
  "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and one special case Character"
)

export const loginSchema = yup.object().shape({
  email: yup.string().email().required(),
  password: yup.string().required(),
});

export const signUpSchema = yup.object().shape({
  lastName: yup.string().required(),
  firstName: yup.string().required(),
  email: yup.string().email().required(),
  password: passwordValidation,
});


export const forgotPasswordSchema = yup.object().shape({
  email: yup.string().email().required(),
});

export const resetPasswordSchema = yup.object().shape({
  newPassword:passwordValidation,
  confirmPassword: passwordValidation.oneOf([yup.ref('newPassword'), null], 'Passwords must match'),
});