import { Box, Button, SimpleGrid, VisuallyHidden } from '@chakra-ui/react';
import * as React from 'react';
import { FaTwitter, FaFacebook, FaGoogle } from 'react-icons/fa';
import { useMutation } from 'redux-query-react';

import DividerWithText from '../../components/common/DividerWithText';
import LoginForm from './LoginForm';
import AuthLayout from './AuthLayout';

import GoogleLogin from 'react-google-login';
// import FacebookLogin from 'react-facebook-login/dist/facebook-login-render-props';
// import GitHubLogin from 'react-github-login';
// import TwitterLogin from "react-twitter-login";

import { useQuery } from 'utils/Hooks/useQuery';

import * as socialQueryConfig from '../../query-configs/socialAuth';

const Login = ({ user, signInWithGoogle }) => {
  const query = useQuery();
  const redirect = query.redirect || '/';
  const [queryStateGoogle, googleLogin] = useMutation(data =>
    socialQueryConfig.googleLogin(data),
  );
  const [queryStateGithub, gitLogin] = useMutation(data =>
    socialQueryConfig.gitLogin(data),
  );
  const [queryStateFacebook, facebookLogin] = useMutation(data =>
    socialQueryConfig.facebookLogin(data),
  );

  React.useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      window.location.replace(redirect);
    }
  }, [queryStateGoogle.isPending]);

  const responseGoogle = response => {
    googleLogin(response);
  };

  const responseFacebook = response => {
    facebookLogin(response);
  };

  const onGitSuccess = response => {
    gitLogin(response);
  };

  const onGitfailed = response => {
  };

  const twitterAuthHandeler = (err, data) => {
  };

  return (
    <AuthLayout>
      <Box mb={40} px={{ base: '2', lg: '2' }}>
        <Box bg='white' border='0.5px  solid #900028' maxW="lg"  px={4} minW="sm" py={4} mx="auto">
          <LoginForm />
          <DividerWithText mt="6">
            {/*or continue with*/}
          </DividerWithText>
          <SimpleGrid mt="12" columns={1} spacing="3" color="brand.500">
            {/*<GoogleLogin*/}
            {/*  clientId={process.env.REACT_APP_GOOGLE_CLIENT_ID}*/}
            {/*  render={renderProps => (*/}
            {/*    <Button*/}
            {/*      color="currentColor"*/}
            {/*      variant="outline"*/}
            {/*      onClick={renderProps.onClick}*/}
            {/*      disabled={renderProps.disabled}*/}
            {/*    >*/}
            {/*      <VisuallyHidden>Login with Google</VisuallyHidden>*/}
            {/*      <FaGoogle />*/}
            {/*      <p style={{color:'black'}}> &nbsp; Login With Google</p>*/}
            {/*    </Button>*/}
            {/*  )}*/}
            {/*  onSuccess={responseGoogle}*/}
            {/*  onFailure={responseGoogle}*/}
            {/*  cookiePolicy={'single_host_origin'}*/}
            {/*/>*/}
          </SimpleGrid>
          {/* </Card> */}
        </Box>
      </Box>
    </AuthLayout>
  );
};
export default Login;
