import {
  Box,
  Button,
  SimpleGrid,
  VisuallyHidden,
  Flex,
} from '@chakra-ui/react';
import * as React from 'react';
import { FcGoogle } from 'react-icons/fc';
import {FaTwitter, FaFacebook, FaGoogle} from 'react-icons/fa';
import { useHistory } from 'react-router-dom';
import DividerWithText from '../../components/common/DividerWithText';
import AuthLayout from './AuthLayout';
import SignupForm from './SignupForm';
import AlertDialogExample from './SignupAlert';
import { useSelector } from 'react-redux';
import { useMutation } from 'redux-query-react';
import { getRegisterDetails } from 'entities/authEntity';

import GoogleLogin from 'react-google-login';

import * as socialQueryConfig from '../../query-configs/socialAuth';

const Signup = ({ user, signInWithGoogle }) => {
  const history = useHistory();
  const registeredMessage = useSelector(getRegisterDetails);
  React.useEffect(() => {
    if (user) {
      history.push('/dashboard');
    }
  }, [user]);

  const [queryStateGoogle, googleSignup] = useMutation(data =>
    socialQueryConfig.googleSignup(data),
  );


  const responseGoogle = response => {
    googleSignup(response);
  };


  return (
    <AuthLayout>
      <Box mb={20} px={{ base: '2', lg: '2' }}>
        <Box border='0.5px solid #900028' bg='white' maxW="lg"  px={8} minW="sm" py={4} mx="auto">
          <AlertDialogExample isOpen={registeredMessage} />
          <SignupForm />
          <DividerWithText mt="6">
            {/*or continue with{' '}*/}
          </DividerWithText>
          <SimpleGrid mt="12" px='8' columns={1} spacing="3" bg='white' color="brand.500">
          {/*  <GoogleLogin*/}
          {/*    clientId={process.env.REACT_APP_GOOGLE_CLIENT_ID}*/}
          {/*    render={renderProps => (*/}
          {/*      <Button*/}
          {/*        color="currentColor"*/}
          {/*        variant="outline"*/}
          {/*        onClick={renderProps.onClick}*/}
          {/*        disabled={renderProps.disabled}*/}
          {/*      >*/}
          {/*        <VisuallyHidden>Login with Google</VisuallyHidden>*/}
          {/*        <FaGoogle />*/}
          {/*        <p style={{color:'black'}}> &nbsp; Signup With Google</p>*/}
          {/*      </Button>*/}
          {/*    )}*/}
          {/*    onSuccess={responseGoogle}*/}
          {/*    onFailure={responseGoogle}*/}
          {/*    cookiePolicy={'single_host_origin'}*/}
          {/*  />*/}
          </SimpleGrid>
          {/* </Card> */}
        </Box>
      </Box>
    </AuthLayout>
  );
};
export default Signup;
