import {
  Box,
  Button,
  chakra,
  FormControl,
  FormLabel,
  Input,
  Stack,
  FormErrorMessage,
  useColorModeValue as mode,
  Text,
} from '@chakra-ui/react';
import * as React from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import PasswordField from 'components/common/PasswordField';
import { loginSchema } from './Validations';
import { useMutation } from 'redux-query-react'
import { makeLoginMutation } from 'entities/authEntity';
import { useHistory,Link } from 'react-router-dom';
import { useQuery } from 'utils/Hooks/useQuery';

const LoginForm = props => {
  const history = useHistory();
  const query  = useQuery()
  const redirect = query.redirect || '/'
  const [{ isPending },handleLogin] = useMutation(data =>
    makeLoginMutation(data),
  );

  React.useEffect(() => {
    const token = localStorage.getItem('token');
    if(token){
      window.location.replace(redirect);
    }
  },[isPending])

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({ resolver: yupResolver(loginSchema) });

  const onSubmit = async (data, event) => {
    event.preventDefault();
    try {
      handleLogin(data)
    } catch (error) {
      alert(error);
    }
  };
  return (
    <chakra.form onSubmit={handleSubmit(onSubmit)} {...props}>
      <Stack spacing="6" >
        <Stack textAlign="left" mb="2">
          <Text textAlign="center" fontSize="3xl">User Login</Text>
          <hr/>
        </Stack>
        {/*<Text>Login to access your NexBloc account</Text>*/}

        <FormControl id="email" isInvalid={errors.email}>
          <FormLabel color="brand.500">Email Address</FormLabel>
          <Input
            {...register('email')}
            type="email"
            autoComplete="email"
            placeholder="Email"
            size="sm"
            variant="flushed"
            p="2"
            borderColor="brand.500"
            focusBorderColor="brand.500"
          />
          <FormErrorMessage>{errors?.email?.message}</FormErrorMessage>
        </FormControl>
        <PasswordField
          {...register('password')}
          errors={errors}
          variant="flushed"
          placeholder="Password"
          size="sm"
          p="2"
          borderColor="brand.500"
          focusBorderColor="brand.500"
          showForgotPassword
        />
          <Button  type="submit" size="lg" fontSize="md">
            Sign in
          </Button>
        <Link
            style={{color:'black'}}
            to={'signup'}
        >
          New User ? Create Account
        </Link>
      </Stack>
    </chakra.form>
  );
};
export default LoginForm;
