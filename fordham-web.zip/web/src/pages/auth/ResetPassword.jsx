import {
  Box,
} from '@chakra-ui/react';
import * as React from 'react';
import ResetPasswordForm from './ResetPasswordForm'

import AuthLayout from './AuthLayout';

const ResetPassword = () => {

  return (
    <AuthLayout>
      <Box
        px={{ base: '4', lg: '8' }}
      >
        <Box maxW="md" mx="auto">
          <ResetPasswordForm />
        </Box>
      </Box>
    </AuthLayout>
  );
};
export default ResetPassword;
