import {
  Box,
  Stack
} from '@chakra-ui/react';
import * as React from 'react';
import ChangePasswordForm from './ChangePasswordForm';
import BackButton from '../../components/common/BackButton';

const ChangePassword = () => {

  return (
    <Stack>
      <BackButton path="/profile/view">Back</BackButton>

      <Stack
        minH="lg"
        bg="gray.50"
        alignItems="center"
        justifyContent="center"
      >

        <Box maxW="md" mx="auto">
          <ChangePasswordForm />
        </Box>
      </Stack>
    </Stack>

  );
};
export default ChangePassword;
