import {
  Stack, SimpleGrid, Image,
} from '@chakra-ui/react';
import React from 'react';

export default function AuthLayout({ children }) {
  return (
    <SimpleGrid bg='gray.50' columns={{ base: 1, lg: 2 }} minHeight="100vh" p="8" alignItems="center">
      <Stack alignItems="center" justifyContent="center" p="-4">
        <Image src={`${window.location.origin}/images/about1.png`} width="100%" height="100%"/>
      </Stack>
      <Stack alignItems="center" justifyContent="" width="full">
        {children}
      </Stack>
    </SimpleGrid>
  );
}
