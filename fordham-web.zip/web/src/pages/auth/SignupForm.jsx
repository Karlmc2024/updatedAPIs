import {
  Box,
  Button,
  chakra,
  FormControl,
  FormLabel,
  Input,
  Stack,
  FormErrorMessage,
  useColorModeValue as mode,
  Text,
} from '@chakra-ui/react';
import * as React from 'react';
import { Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import PasswordField from 'components/common/PasswordField';
import { signUpSchema } from './Validations';
import { useMutation } from 'redux-query-react';
import { makeSignupMutation } from 'entities/authEntity';
const SignupForm = props => {
  const [{ isPending }, handleSignUp] = useMutation(data =>
    makeSignupMutation(data),
  );

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({ resolver: yupResolver(signUpSchema) });
  const onSubmit = async data => {
    handleSignUp(data);
  };


  return (
    <chakra.form onSubmit={handleSubmit(onSubmit)} {...props}>
      <Stack bg='white'  spacing="6" width="full">
        <Stack textAlign="left">
          <Text fontSize="3xl">Create New Account</Text>
          <hr/>
          {/*<Text>Create New Account</Text>*/}
        </Stack>

        <Stack direction="row" spacing="8">
          <FormControl id="firstName" isInvalid={errors.firstName}>
            <FormLabel color="brand.500">First Name</FormLabel>
            <Input
              {...register('firstName')}
              type="name"
              autoComplete="firstName"
              // required
              size="sm"
              variant="flushed"
              p="4"
              borderColor="brand.500"
              focusBorderColor="brand.500"
            />
            <FormErrorMessage>{errors?.firstName?.message}</FormErrorMessage>
          </FormControl>

          <FormControl id="lastName" isInvalid={errors.lastName}>
            <FormLabel color="brand.500"> Last Name</FormLabel>
            <Input
              {...register('lastName')}
              type="name"
              autoComplete="lastName"
              // required
              size="sm"
              variant="flushed"
              p="4"
              borderColor="brand.500"
              focusBorderColor="brand.500"
            />
            <FormErrorMessage>{errors?.lastName?.message}</FormErrorMessage>
          </FormControl>
        </Stack>

        <FormControl id="email" isInvalid={errors.email}>
          <FormLabel color="brand.500">Email address</FormLabel>
          <Input
            {...register('email')}
            type="email"
            autoComplete="email"
            // required
            size="sm"
            variant="flushed"
            p="4"
            borderColor="brand.500"
            focusBorderColor="brand.500"
          />
          <FormErrorMessage>{errors?.email?.message}</FormErrorMessage>
        </FormControl>

        <PasswordField
          {...register('password')}
          errors={errors}
          variant="flushed"
          size="sm"
          p="4"
          borderColor="brand.500"
          focusBorderColor="brand.500"
        />
        {/*<Stack*/}
        {/*  direction="row"*/}
        {/*  alignItems="center"*/}
        {/*  justifyContent="space-between"*/}
        {/*  pt="4"*/}
        {/*  width="full"*/}
        {/*>*/}

          <Button
            type="submit"
            colorScheme="brand"
            size="md"
            fontSize="md"
            isLoading={isPending}
            loadingText="Creating account"
          >
            Create Account
          </Button>
          <Link
              style={{color:'black'}}
              to={'/login'}
          >
            Already have an account ? Login
          </Link>
        {/*</Stack>*/}
      </Stack>
    </chakra.form>
  );
};
export default SignupForm;
