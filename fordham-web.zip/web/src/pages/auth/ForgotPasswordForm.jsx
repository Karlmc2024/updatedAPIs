import {
  Button,
  chakra,
  FormControl,
  FormLabel,
  Input,
  Stack,
  FormErrorMessage,
  Text,
} from '@chakra-ui/react';
import * as React from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { forgotPasswordSchema } from './Validations';
import { useMutation } from 'redux-query-react'
import { makeForgotPasswordMutation } from 'entities/authEntity';

const ForgotPasswordForm = props => {
  const [{ isPending,isFinished,status },handleForgotPassword] = useMutation(data =>
    makeForgotPasswordMutation(data),
  );

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({ resolver: yupResolver(forgotPasswordSchema) });

  const onSubmit = async (data, event) => {
      event.preventDefault();
      handleForgotPassword(data)
  };
  if(isFinished&&status<400){
    return <Stack textAlign="left" mb="8">
    <Text fontSize="4xl">Forgot Password?</Text>
    <Text fontSize="sm" fontSize="lg">Please check your email for reset link.</Text>
  </Stack>
  }
  return (
    <chakra.form onSubmit={handleSubmit(onSubmit)} {...props}>
      <Stack spacing="6">
        <FormControl id="email" isInvalid={errors.email}>
        <Stack textAlign="left" mb="8">
          <Text fontSize="2xl">Forgot Password?</Text>
          <Text fontSize="sm">Enter the email address you used when you joined and we’ll send you reset your password link.</Text>
        </Stack>
          <FormLabel color="brand.500">Email Address</FormLabel>
          <Input
            {...register('email')}
            type="email"
            autoComplete="email"
            required
            size="lg"
            variant="flushed"
            p="4"
            borderColor="brand.500"
            focusBorderColor="brand.500"
          />
          <FormErrorMessage>{errors?.email?.message}</FormErrorMessage>
        </FormControl>
        
        <Stack
          direction="row"
          alignItems="center"
          justifyContent="space-between"
          pt="4"
        >
          <Button type="submit" colorScheme="brand" size="lg" fontSize="md">
            Send forgot password link
          </Button>
        </Stack>
      </Stack>
    </chakra.form>
  );
};
export default ForgotPasswordForm;
