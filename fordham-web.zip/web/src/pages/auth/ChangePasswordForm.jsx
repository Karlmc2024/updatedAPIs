import {
  Button,
  chakra,
  Stack,
  Text,
} from '@chakra-ui/react';
import * as React from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { resetPasswordSchema } from './Validations';
import { useMutation } from 'redux-query-react'
import { makeChangePasswordMutation } from 'entities/authEntity';
import PasswordField from 'components/common/PasswordField';
import {Link} from "react-router-dom";
import BackButton from 'components/common/BackButton';


const ChangePasswordForm = props => {
  const [{ isPending,isFinished,status },handleChangePassword] = useMutation(data =>
    makeChangePasswordMutation(data),
  );


  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({ resolver: yupResolver(resetPasswordSchema) });

  const onSubmit = async (data, event) => {
    event.preventDefault();
    handleChangePassword({password:data.newPassword})
  };

  if(isFinished&&status<400){
    return <Stack textAlign="left" mb="8">
    <Link to='/profile/view' fontSize="4xl">Back</Link>
    <Text fontSize="lg">Password has been changed successfully.</Text>
  </Stack>
  }

  return (
    <chakra.form onSubmit={handleSubmit(onSubmit)} {...props}>

      <Stack bg="white" p="10" spacing="6">

        <Stack textAlign="left" mb="8">
          <Text fontSize="2xl">Change Password</Text>
          <Text fontSize="sm">Enter the new password and confirm password</Text>
        </Stack>
        <PasswordField
          {...register('newPassword')}
          variant="flushed"
          size="lg"
          p="4"
          borderColor="brand.500"
          focusBorderColor="brand.500"
          label="New Password"
          errors={{password:errors.newPassword}}
        /> 
        <PasswordField
        {...register('confirmPassword')}
        errors={{password:errors.confirmPassword}}
        variant="flushed"
        size="lg"
        p="4"
        borderColor="brand.500"
        focusBorderColor="brand.500"
        label="Confirm Password"
      />
        {/*<Stack*/}
        {/*  direction="row"*/}
        {/*  alignItems="center"*/}
        {/*  justifyContent="space-between"*/}
        {/*  pt="4"*/}
        {/*>*/}
          <Button type="submit" colorScheme="brand" size="lg" fontSize="md">
            Change Password
          </Button>
        {/*</Stack>*/}
      </Stack>
    </chakra.form>
  );
};
export default ChangePasswordForm;
