import {
  Button,
  chakra,
  Stack,
  Text,
} from '@chakra-ui/react';
import * as React from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import { resetPasswordSchema } from './Validations';
import { useMutation } from 'redux-query-react'
import { makeResetPasswordMutation } from 'entities/authEntity';
import PasswordField from 'components/common/PasswordField';
import { useParams } from 'react-router-dom';

const ResetPasswordForm = props => {
  const [{ isPending,isFinished,status },handleResetPassword] = useMutation(data =>
    makeResetPasswordMutation(data),
  );

  const {userId,token} = useParams()

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({ resolver: yupResolver(resetPasswordSchema) });

  const onSubmit = async (data, event) => {
    event.preventDefault();
      handleResetPassword({userId,token,password:data.newPassword})
  };

  if(isFinished&&status<400){
    return <Stack textAlign="left" mb="8">
    <Text fontSize="4xl">Reset Password</Text>
    <Text fontSize="lg">Password has been changed successfully. <a href="/login">Login</a> into your account using new Password</Text>
  </Stack>
  }

  return (
    <chakra.form onSubmit={handleSubmit(onSubmit)} {...props}>
      <Stack spacing="6">
        
      <Stack textAlign="left" mb="8">
          <Text fontSize="2xl">Reset Password</Text>
          <Text fontSize="sm">Enter the new password and confirm password</Text>
        </Stack>
        <PasswordField
          {...register('newPassword')}
          variant="flushed"
          size="lg"
          p="4"
          borderColor="brand.500"
          focusBorderColor="brand.500"
          label="New Password"
          errors={{password:errors.newPassword}}
        /> 
        <PasswordField
        {...register('confirmPassword')}
        errors={{password:errors.confirmPassword}}
        variant="flushed"
        size="lg"
        p="4"
        borderColor="brand.500"
        focusBorderColor="brand.500"
        label="Confirm Password"
      />
        <Stack
          direction="row"
          alignItems="center"
          justifyContent="space-between"
          pt="4"
        >
          <Button type="submit" colorScheme="brand" size="lg" fontSize="md">
            Reset Password
          </Button>
        </Stack>
      </Stack>
    </chakra.form>
  );
};
export default ResetPasswordForm;
