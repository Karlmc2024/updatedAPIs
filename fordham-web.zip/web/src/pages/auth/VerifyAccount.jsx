import React from 'react'
import { Text , Stack} from '@chakra-ui/react'
import {useParams} from 'react-router-dom'
import { useRequest } from 'redux-query-react'
import {verifyEmailRequest, verifyEmailDetails} from 'entities/authEntity'
import AlertDialogExample from './SignupAlert'
import { useSelector } from 'react-redux'


export default function VerifyAccount() {
  const {userId,token} = useParams()
  const isVerifiedAccount =  useSelector(verifyEmailDetails)
  const [{isPending},status] = useRequest(verifyEmailRequest({userId,token}))
  return (
    <Stack align="center" justify="center" minH={"lg"}>
    <AlertDialogExample isOpen={isVerifiedAccount} message="Your account has been verified. You can log in now."/>
    <Text fontSize="3xl" fontWeight="bold">
      Verifying your email ...
    </Text>
    </Stack>
  )
}
