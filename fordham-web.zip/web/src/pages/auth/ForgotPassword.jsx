import {
  Box,
} from '@chakra-ui/react';
import * as React from 'react';
import ForgotPasswordForm from './ForgotPasswordForm'

import AuthLayout from './AuthLayout';

const ForgotPassword = () => {

  return (
    <AuthLayout>
      <Box
        px={{ base: '4', lg: '8' }}
      >
        <Box maxW="md" mx="auto">
          <ForgotPasswordForm />
        </Box>
      </Box>
    </AuthLayout>
  );
};
export default ForgotPassword;
