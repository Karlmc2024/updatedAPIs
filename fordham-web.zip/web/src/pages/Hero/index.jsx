import React, { useState, useEffect, useCallback } from 'react';
import debounce from 'lodash.debounce';
import Search from './Search';
import LearnMore from './LearnMore';
import DomainCards from './Domains';
import { useMutation } from 'redux-query-react';
import { useSelector } from 'react-redux';
import store from 'redux/reduxQueryStore';
import { updateEntities } from 'redux-query';
import { useLocalStorage } from '@mantine/hooks';

import { searchDomainMutation,getSerachDomain } from './entities';
import { Divider, Text} from "@chakra-ui/react";


export default function Home() {
  const [searchData, setsearchData] = useState('');
  const [TLD, setTLD] = useLocalStorage({ key: 'tld', defaultValue: '.fordham' });
  const [isLoading,setIsLoading] = useState(false);
  const [showSearchMessagePopup,setShowSearchMessagePopup] = useState(false);

  const searchedDomain = useSelector(getSerachDomain)||[];
  const [{isPending},searchDomain] = useMutation(searchDomainMutation)

  // useEffect(() => {
  //   if(searchData?.length>0){
  //     searchDomain(searchData+TLD);
  //   }
  // },[TLD])

  const  debouncedChangeHandler = useCallback(debounce((se, srTLD) => {
    setIsLoading(false);
    if(se.length > 0) {
      searchDomain(se+srTLD);
    } else {
      store.dispatch(
        updateEntities({
          searchDomain: prevValue => null,
        }),
      );
    }
  }, 500), []); 

    useEffect(() => {
      return () => {
        debouncedChangeHandler.cancel();
      }
    }, []);


  const handleDomainSerachInputChange = (e) => {
    const { value } = e.target;
    e.target.value = e.target.value.replace(/[^a-zA-Z0-9]/g, "").toLowerCase();
    setsearchData(value);
    const searchLength = value?.length
    setIsLoading(true);
    if(searchLength >= 3){
      debouncedChangeHandler(e.target.value, TLD);
    }
  };

  let searchedDomainVal = searchData.length>=3?searchedDomain:[];
  return (
    <>
        <Search
        searchData={searchData}
        onChange={handleDomainSerachInputChange}
        onTLDChange={(tldVal) => {
          setTLD(tldVal)
        }}
        showSearchMessagePopup={showSearchMessagePopup}
        TLD={TLD}
      />

      <DomainCards searchedDomain={searchedDomainVal} isLoading={(isPending||(isLoading))&&searchData.length>=3} TLD={TLD}/>

      <LearnMore />

      <Divider orientation="horizontal" />

    </>
  );
}
