import {
  Stack,
  Text,
  SimpleGrid,
  Skeleton,
  SkeletonCircle,
  Flex,
} from '@chakra-ui/react';
import React from 'react';
import { useSelector } from 'react-redux';
import { useRequest } from 'redux-query-react';
import DomainCard from 'components/Domain/DomainCard'

import * as transactionQueryConfig from '../../query-configs/transaction';
import * as transactionSelectors from '../../selectors/transaction';

export function Loadingdomain() {
  return (
    <Stack
      alignItems="center"
      py="16"
      boxShadow="lg"
      borderRadius="lg"
      bg="white"
      mb="4"
    >
      <Stack alignItems="center" spacing="4">
        <SkeletonCircle size="72px" />
        <Skeleton height="10" width="32" />
        <Skeleton height="6" width="32" />
        <Stack direction="row" alignItems="center" justifyContent="center">
          <Skeleton height="10" width="32" />
        </Stack>
      </Stack>
      <Stack direction="row">
        <Skeleton height="10" width="32" />
        <Skeleton height="10" width="32" />
      </Stack>
    </Stack>
  );
}

export default function DomainCards({ searchedDomain, isLoading, TLD }) {
  const tags = useSelector(state => state.entities.tlds);
  const [queryStatePD, getPremiumDomain] = useRequest(
    transactionQueryConfig.getPremiumDomain(),
  );

  const premiumDomains = useSelector(transactionSelectors.premiumDomains);
  const tldId = tags?.find(tld => tld.tldName === TLD)?._id;
  return (
    <>
      <Flex
        justifyContent="center"
        marginTop="-32"
        marginBottom="-8"
        padding="4"
      >
        {isLoading ? (
          <Loadingdomain />
        ) : (
          searchedDomain?.map(website => <DomainCard key={Math.random()} tldId={tldId} {...website}/>)
        )}
      </Flex>
      {/*<Text fontSize={{base:"3xl",md:"4xl"}} fontWeight="semibold" mb="8" color="white"> */}
      {/*  Premium Domains NFT Sale*/}
      {/*</Text>*/}
      <SimpleGrid
        columns={{ base: 1, md: 2, lg: 3 }}
        paddingX={{base:"4",md:"32"}}
        spacing="16"
        alignItems="center"
      >
        {premiumDomains.map((website,index) => (
          <DomainCard {...website} tldId={tldId} key={index} isPremium/>
        ))}
      </SimpleGrid>
    </>
  );
}
