export const searchDomainMutation = (data)=>{
  return {
    url:`/api/domains/search?domainName=${data}`,
    body:data,
    transform:(responseBody)=>{
      const {result} = responseBody || {};
      const {domainName} = result || {};
      return {searchDomain:domainName?[result]:[]};
    },
    update:{
      searchDomain:(oldValue,newValue)=>{
        return newValue;
      }
    }
  }
}

export const getSerachDomain = state => state.entities.searchDomain;