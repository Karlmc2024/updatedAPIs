import React from 'react';
import { Button, HStack, Tooltip,SimpleGrid, WrapItem } from '@chakra-ui/react';

const DomainTag = ({ tldName, active, onClick, TLD }) => {
  return (
    <Tooltip hasArrow label={active?tldName:"Coming soon..."}>
    <Button
      bg={ TLD === tldName ?  "white" : "brand.500"}
      color={ TLD !== tldName ? active ?  "white" : "gray.300" : "brand.500"}
      borderRadius="full"
      px="6"
      cursor={active?"pointer":"not-allowed"}
      onClick={() => {
        if(active){
          onClick(tldName)}
        }
      }
      _hover={{
      }}
      _active={{}}
    >
      {tldName}
    </Button>
    </Tooltip>
  );
};

export default function DomaingTags({ tags, onClick, TLD }) {
  return (
    <SimpleGrid columns={1} gap="2">
      {tags?.map(tag => (
        <DomainTag {...tag} key={Math.random()} onClick={onClick} TLD={TLD}/>
      ))}
      <br/>
    </SimpleGrid>
  );
}
