/* eslint-disable max-len */
import {
  SimpleGrid, Stack, Text, Image,
} from '@chakra-ui/react';
import React from 'react';

const MainHeading = ({ heading, description }) => (
  <Stack textAlign="center">
    <Text fontSize="3xl" fontWeight="semibold">
      {heading}
    </Text>
    <Text color="gray.700" paddingX={{ base: '0', md: '16' }}>
      {description}
    </Text>
  </Stack>
);

const Question = ({ heading, description }) => (
  <Stack textAlign="left" maxWidth="md" spacing="4" direction="row">
    <Image src={`${window.location.origin}/images/right-icon.png`} boxSize="36px" />
    <Stack>
      <Text fontSize="2xl" color="brand.500">
        {heading}
      </Text>
      <Text color="gray.700">
        {description}
      </Text>
    </Stack>
  </Stack>
);

const AllQuestions = ({ questions }) => (
  <SimpleGrid columns={{ base: 1, md: 3 }} spacing="10" paddingX={{ base: 0, lg: '20' }}>
    {questions?.map(({ heading, description }) => <Question key={heading} heading={heading} description={description} />)}
  </SimpleGrid>
);

export default function Features() {
  const mainHeading = {
    heading: 'Cloud Load Balancing',
    description: 'Deploy your service infrastructure on our fully redundant, high performance cloud platform and benefit from its high reliability, security and enterprise feature set.',
  };
  const questions = [
    {
      heading: 'Instant Activation',
      description: 'We operate one of the most advanced 100 Gbit networks in the world, complete with Anycast support and extensive DDoS protection.',
    },
    {
      heading: 'Fully Redundant',
      description: 'We operate one of the most advanced 100 Gbit networks in the world, complete with Anycast support and extensive DDoS protection.',
    },
    {
      heading: 'Powerful Automation',
      description: 'We operate one of the most advanced 100 Gbit networks in the world, complete with Anycast support and extensive DDoS protection.',
    },
    {
      heading: 'Powerful Automation',
      description: 'We operate one of the most advanced 100 Gbit networks in the world, complete with Anycast support and extensive DDoS protection.',
    },
    {
      heading: 'High Performance',
      description: 'We operate one of the most advanced 100 Gbit networks in the world, complete with Anycast support and extensive DDoS protection.',
    },
    {
      heading: 'Dedicated Support',
      description: 'We operate one of the most advanced 100 Gbit networks in the world, complete with Anycast support and extensive DDoS protection.',
    },
  ];
  return (
    <Stack spacing="16" padding="16">
      <MainHeading {...mainHeading} />
      <AllQuestions questions={questions} />
    </Stack>
  );
}
