import {
  Stack, Text, SimpleGrid, Box,
} from '@chakra-ui/react';
import React from 'react';
export const SupportCard = ({ children }) => (
  <Box bg="brand.800" minHeight="16" padding="8" borderRadius="md" color="white">
    {children}
  </Box>
);

export default function Support() {
  return (
    <SimpleGrid
      columns={{ base: 1, lg: 2 }}
      minHeight="60"
      bg="gray.100"
      backgroundImage={`${window.location.origin}/images/section_bg02.png`}
      py="48"
      backgroundSize="cover"
      backgroundRepeat="no-repeat"
    >
      <Stack alignItems="center" justifyContent="center" color="white">
        <Text fontWeight="bold" fontSize="4xl">

        </Text>
        <Text fontWeight="bold" fontSize="4xl">

        </Text>
        <Text maxWidth="sm">
         Building decentralized digital identities for the world
          Use NFT domains as your:
          <ul>
            <li>
              Universal username across apps and websites
            </li>
            <li>
              Website URL

            </li>
            <li>
              Payment address for wallets

            </li>
            <li>
              Secure Domain Storage
            </li>
          </ul>
        </Text>
      </Stack>
      <Stack direction="row" justifyContent="center" alignItems="center">

      </Stack>
    </SimpleGrid>
  );
}
