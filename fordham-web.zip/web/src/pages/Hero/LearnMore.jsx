import {
    Stack, Text, Button, SimpleGrid, Image, Box, useColorModeValue as mode, Divider
} from '@chakra-ui/react';
import React from 'react';
import { FcMoneyTransfer, FcMultipleDevices, FcPrivacy, FcGlobe } from 'react-icons/fc'

export const Feature = (props) => {
  const { title, children, icon } = props
  return (
    <Stack
      spacing={{
        base: '3',
        md: '6',
      }}
      direction={{
        base: 'column',
        md: 'row',
      }}
      alignItems="center"
    >
      <Box fontSize="6xl">{icon}</Box>
      <Stack spacing="1">
        <Text fontWeight="extrabold" fontSize="lg">
          {title}
        </Text>
        <Box color={mode('gray.600', 'gray.400')}>{children}</Box>
      </Stack>
    </Stack>
  )
}

const Features =  () => (
  <Box
    as="section"
    maxW="5xl"
    mx="auto"
    textAlign={{sm:"center",md:"left"}}
    px={{
      base: '0',
      md: '8',
    }}
  >
    <SimpleGrid
      columns={{
        base: 1,
      }}
      spacingX={{base:"2",md:"10"}}
      spacingY={{
        base: '8',
        md: '14',
      }}
    >
      <Feature title="Secure domain storage" icon={<FcPrivacy />}>
      We store all registered domains in so-called "cold" storage, outside the Internet and computers. The goal is to eliminate the risk of hacker attacks and the stealing of domains. Your domain is in safe hands.
      </Feature>

      <Feature title="Universal username across apps and websites" icon={<FcMultipleDevices />}>
        Human-meaningful .fordham domains.
      </Feature>
      <Feature title="Website URL" icon={<FcGlobe />}>
        Access websites using the top-level domain.
      </Feature>
      <Feature title="Payment address for wallets" icon={<FcMoneyTransfer />}>
      Securely record and transfer arbitrary names (keys).
Attach a value (data) to the names (up to 520 bytes).
      </Feature>
      
    </SimpleGrid>
  </Box>
)


export default function LearnMore() {
  return (
    <SimpleGrid columns={{ base: 1, lg: 2 }} minHeight="60" padding={{base:"4", md:"32"}}>

      <Image mt='50px' src={`${window.location.origin}/images/about1.png`} />
      <Stack alignItems="left" justifyContent="center">
        {/* <Text alignItems="left" fontWeight="bold" fontSize="2xl">
          Building decentralized digital identities for the world
        </Text>
        <Text fontWeight="bold" color="brand.500" fontSize="1xl">
          Use NFT domains as your:
        </Text> */}
        <br/>
        <br/>
        <Features/>
        </Stack>
    </SimpleGrid>
  );
}
