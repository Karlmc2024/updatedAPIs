import React from 'react';
import {
  Popover,
  PopoverTrigger,
  PopoverContent,
  PopoverHeader,
  PopoverBody,
  PopoverArrow,
  PopoverCloseButton,
} from "@chakra-ui/react"

export default function SearchMessagePopup({children,isOpen}) {
  return (
    <Popover
      isOpen={isOpen}
      placement="bottom"
      closeOnBlur={false}
    >
      <PopoverTrigger>
        {children}
      </PopoverTrigger>
      <PopoverContent  bg="white">
        <PopoverHeader pt={4} fontSize="sm" border="0">
          Domain length should be at least 2 characters
        </PopoverHeader>
        <PopoverArrow />
      </PopoverContent>
    </Popover>
  )
}