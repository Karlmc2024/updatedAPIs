import {
  Stack,
  Input,
  Text,
  InputGroup,
  InputLeftElement,
  InputRightElement,
  FormControl,
  Select,
  FormHelperText,
  Box,
  Heading, Button
} from '@chakra-ui/react';
import React from 'react';
import { FaSearch } from 'react-icons/fa';
import DomaingTags from './DomaingTags';
import { useSelector } from 'react-redux';
import { Link as RouterLink } from 'react-router-dom';


export default function Search({ searchData, onChange, onTLDChange, TLD, showSearchMessagePopup }) {

  const tags = useSelector(state => state.entities.tlds);
  const searchFormSubmit = event => {
    event.preventDefault();
  };

  return (
      <Stack
          alignItems="center"
          justifyContent="center"
          backgroundSize="cover"
          backgroundRepeat="no-repeat"
          minHeight="lg"
          backgroundImage={`${window.location.origin}/images/Background-NexBloc.jpeg`}
          padding="4"
      >
      {
        searchData ? <div></div>:<Stack style={{position:'absolute',top:20}} >
        {/*<Heading*/}
        {/*     fontSize={{base:"xl",md:"2xl"}}*/}
        {/*    fontWeight="extrabold"*/}
        {/*    color="white"*/}
        {/*>*/}
        {/*  Buy Credits - Get $NEXB Tokens*/}
        {/*</Heading>*/}

        {/*<Button*/}
        {/*    color="white"*/}
        {/*    as={RouterLink}*/}
        {/*    to='/token-payment'*/}
        {/*    background="#F48E00"*/}
        {/*    marginLeft="4"*/}
        {/*    _hover={{ color: 'white', background: '#F48E00' }}*/}
        {/*    _active={{ color: 'white', background: '#F48E00' }}*/}
        {/*>*/}
        {/*  Fund Now*/}
        {/*</Button>*/}
      </Stack>
      }
      
    <Stack
        justifyContent="center"
        alignItems="center"
      transition="all .2s linear"
      {...(searchData
        ? { minHeight: 'sm', pt: '4', justifyContent: 'flex-start' }
        : {})}
    >

      <Heading
        textTransform="uppercase"
        color="white"
        fontSize={{base:"2xl",md:"3xl"}} fontWeight="extrabold"
      >
        Blockchain-based domain names
      </Heading>
      <Text
        fontSize="1xl"
        fontWeight="extrabold"
        color="white"
      >
        Reserve Your Domain <DomaingTags tags={tags} onClick={onTLDChange} TLD={TLD}/>
      </Text>
      <FormControl id="search-domain">
        <InputGroup>
          <InputLeftElement pointerEvents="none" height="100%" width="16">
            <FaSearch color="gray.500" size="32px" />
          </InputLeftElement>
          <Input
            value={searchData.toLowerCase()}
            onChange={onChange}
            variant="filled"
            borderRadius="full"
            placeholder="Search for a Domain"
            minHeight="16"
            width={{ base: '100%', md: '2xl' }}
            background="white"
            boxShadow="xl"
            pr="16"
            pl="16"
            _hover={{ background: 'white' }}
            _focus={{ background: 'white' }}
          />
          <InputRightElement height="100%"  width="50" marginRight="10px">
            <Select
                style={{'textAlign':'end'}}
              value={TLD}
              variant="unstyled"
              placeholder=""
              onChange={e => {
                onTLDChange(e.target.value);
              }}
            >
              {
                tags?.map(({tldName, active}) => <option key={tldName} value={tldName} disabled={!active}>{tldName}</option>)
              }
              
            </Select>
          </InputRightElement>
        </InputGroup>
        {
          searchData.length>0 && searchData.length<3 ? <FormHelperText bg="whiteAlpha.500" color="brand.500" padding="2" br="lg">Please enter 3 or more letters to search a domain</FormHelperText> : ""
        }
        
        </FormControl>
    </Stack>
        </Stack>
  );
}
