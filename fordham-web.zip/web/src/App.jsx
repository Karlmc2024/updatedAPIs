import createRoutes from 'createRoutes';
import * as React from 'react';
import { BrowserRouter as Router, Switch } from 'react-router-dom';
import './App.css';
import withFirebaseAuth from 'react-with-firebase-auth';
import firebase from 'firebase/app';
import 'firebase/auth';
import FullPageLoader from 'components/common/FullPageLoader';
import { ChakraProvider } from '@chakra-ui/react';
import app from './base';
import Layout from './pages/Layout';
import theme from './theme';
import { updateCart } from 'components/Domain/cartUtils';
import { useMutation, useRequest } from 'redux-query-react';
import { updateCartMutation,getCartRequest } from 'entities/cartEntity';
import { getWishlistRequest, updateWishlistMutation } from 'pages/Wishlist/entities';
import { updateWishlist } from 'utils/Wishlist/wishlist';
import { AnimatedSwitch , spring} from 'react-router-transition';
import { getUserRequest } from 'pages/User/userEntity';
import { getTLD } from 'query-configs/transaction';
import ScrollToTop from  './scrollTop';

const firebaseAppAuth = app.auth();
const providers = {
  googleProvider: new firebase.auth.GoogleAuthProvider(),
};

function glide(val) {
  return spring(val, {
    stiffness: 174,
    damping: 19,
  });
}

function mapStyles(styles) {
  return {
    opacity: styles.opacity,
    transform: `translateX(${styles.offset}px)`,
  };
}

const pageTransitions = {
  atEnter: {
    offset: 200,
    opacity: 0.5,
  },
  atLeave: {
    offset: glide(-100),
    opacity: glide(0),
  },
  atActive: {
    offset: glide(0),
    opacity: glide(1),
  },
};

function App(props) {

  useRequest(getUserRequest())
  const [,updateCartApi] = useMutation(updateCartMutation);
  const [,updateWishlistApi] = useMutation(updateWishlistMutation);
  useRequest(getCartRequest)
  useRequest(getWishlistRequest())
  useRequest(getTLD())

  React.useEffect(() => {
    updateCart(updateCartApi);
    updateWishlist(updateWishlistApi)
  }, []);

  return (
    <div className="App wrapper">
      <ChakraProvider theme={theme}>
        <Router>
          <ScrollToTop />
          <Switch>
            <Layout>
              <React.Suspense fallback={<FullPageLoader />}>
              <AnimatedSwitch
                  {...pageTransitions}
                  mapStyles={mapStyles}
                  className="route-wrapper"
              >
                {createRoutes(props)}
                </AnimatedSwitch>
              </React.Suspense>
            </Layout>
          </Switch>
        </Router>
      </ChakraProvider>
    </div>
  );
}

export default withFirebaseAuth({
  providers,
  firebaseAppAuth
})(App);
