const { ethers } = require("hardhat");

const privateKey = '37cd6dbcb5668adf3b45cc7313562dd6606dc352ca59662f94b3a22832a9c926';
const signer = new ethers.Wallet(privateKey).connect(ethers.provider);

async function main(order) {

    const registry_ = await ethers.getContractFactory("RootRegistry");
    const registryInstance = new ethers.Contract('0xfaA63424573A85718c260C076Dc17B775eb0c9B5',registry_.interface, signer  );
    
    //const order = ['0xc205aDAE354dAE50664513344B05D342c4e87577', 'fordham', 'test1', 'fordham', Math.round(Math.random()*1000)];
    const sig = await getSignature(signer, ...order); 
    
    const tx = await registryInstance.mintDomain(order, sig);

    console.log(tx);

}



const toTypedOrder = (
    domain_owner, domain_parent, domain_label, domain_zone, domain_salt) => {


        const domain = {
             
            name: 'Fordham',
            version: '1',
            chainId: 51,
            verifyingContract: '0xfaA63424573A85718c260C076Dc17B775eb0c9B5'
        };

    
         const types = {
            
            Order: [
                { name: 'owner', type: 'address' },
                { name: 'parent', type: 'string' },
                { name: 'label', type: 'string' },
                { name: 'zone', type: 'string'},
                { name: 'salt', type: 'uint256'}                
            ]
        };
    
    
       
    
         const value = {
            owner: domain_owner,
            parent: domain_parent,
            label: domain_label,
            zone: domain_zone,
            salt: domain_salt,
            Message: 'Approve Fordham to mint domain to your wallet'
        }

        const message = {
            DomainLabel : domain_label,
            ParentDomain : domain_parent,
            Message: 'Approve NexBloc to mint domain to your wallet'
        }
    

    
        return  { domain, types, value} ;
    }
    
    
    
    const getSignature = async (signer,...args) => {
        //console.log(signer.address);
        const order = toTypedOrder(...args);
             // console.log(order.domain);

        const signedTypedHash =  await signer._signTypedData(
            order.domain,
            order.types,
            order.value,
            order.message
        );


        const sig = ethers.utils.splitSignature(signedTypedHash);

    
        return [sig.v, sig.r, sig.s];
    }

const to_address = '0xc205aDAE354dAE50664513344B05D342c4e87577';
const domain_parent = 'fordham'
const domain_label = 'test_domain'
const domain_zone = 'fordham'
const order = [to_address, domain_parent, domain_label, domain_zone, Math.round(Math.random()*1000)];

main(order).catch((error) => {
    console.error(error);
    process.exitCode = 1;
});