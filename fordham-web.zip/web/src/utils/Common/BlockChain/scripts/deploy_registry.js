const { ethers, upgrades } = require("hardhat");

//const privateKey = '';
//const signer = new ethers.Wallet(privateKey).connect(ethers.provider);
const { getImplementationAddress } = require('@openzeppelin/upgrades-core');


async function main() {

    /*const registry_ = await ethers.getContractFactory("RootRegistry");
    const registry = await upgrades.deployProxy(registry_ ,['0x531aCED0CAEcB53ea5D66a207807708CAE3E97e6', '0xc205aDAE354dAE50664513344B05D342c4e87577', 'Fordham', '1'],{kind: 'uups'});
    await registry.deployed();
    console.log(`registry proxy deployed at: ${registry.address}`); */

    const registryImplementationAddress = await getImplementationAddress(ethers.provider, '0xfaA63424573A85718c260C076Dc17B775eb0c9B5');//registry.address);
    console.log(`registry implementation deployed at: ${registryImplementationAddress}`);

}


main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});