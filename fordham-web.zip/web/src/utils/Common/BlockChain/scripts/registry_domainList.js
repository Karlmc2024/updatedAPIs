const { ethers } = require("hardhat");

const privateKey = '37cd6dbcb5668adf3b45cc7313562dd6606dc352ca59662f94b3a22832a9c926';
const signer = new ethers.Wallet(privateKey).connect(ethers.provider);

async function main() {

    const registry_ = await ethers.getContractFactory("RootRegistry");
    const registryInstance = new ethers.Contract('0xfaA63424573A85718c260C076Dc17B775eb0c9B5',registry_.interface, signer  );
    
    
    const [tx1,tx2] = await registryInstance.domainList();

    console.log(tx1);
    console.log(tx2);

}


main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});