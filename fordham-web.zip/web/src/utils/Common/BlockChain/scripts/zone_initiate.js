const { ethers } = require("hardhat");

const privateKey = '37cd6dbcb5668adf3b45cc7313562dd6606dc352ca59662f94b3a22832a9c926';
const signer = new ethers.Wallet(privateKey).connect(ethers.provider);

async function main() {

    
    const zone_ = await ethers.getContractFactory("Zone");
    const zoneInstance = new ethers.Contract('0x4E228A1Db6e5c01AFa53cC05fAD0c2aF1d3D97a9',zone_.interface, signer  );

    const tx = await zoneInstance.setRegistry('0xfaA63424573A85718c260C076Dc17B775eb0c9B5');

    console.log(tx);


}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});