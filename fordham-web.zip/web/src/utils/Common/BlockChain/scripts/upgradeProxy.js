const { ethers } = require("hardhat");

const privateKey = '37cd6dbcb5668adf3b45cc7313562dd6606dc352ca59662f94b3a22832a9c926';
const signer = new ethers.Wallet(privateKey).connect(ethers.provider);
//const stakeable_ = ethers.getContractFactory("Registry");

async function main() {

    
    const registryV3 = await ethers.getContractFactory("RegistryV3");
    await upgrades.upgradeProxy('0x5938B0c9a81b13A3F863817e53F844DB628Ff36d', registryV3);
    console.log("Registry upgraded successfully");



}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
