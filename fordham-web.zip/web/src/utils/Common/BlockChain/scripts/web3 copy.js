import  {ethers} from "ethers";
import Web3 from "xdc3"
//import registry from './artifacts/RootRegistry.json'
import registry from './artifacts/contracts/RootRegistry.sol/RootRegistry.json'
const HDWalletProvider = require("@truffle/hdwallet-provider");
const privateKey = '0x37cd6dbcb5668adf3b45cc7313562dd6606dc352ca59662f94b3a22832a9c926';



//import /*getBlockChainAddressStorage,*/ {mainnetXdc3/*, mainnetSenderAddress*/} from './xdc'

export const getWeb3 = () => {
  return new Web3(Web3.givenProvider || 'http://localhost:7545');
}

export const getWeb3Account = (web3) => {
  return web3.eth.getAccounts();
}

const provider_test = new HDWalletProvider(privateKey,"https://rpc.xinfin.network");
const xdc3 = new Web3(provider_test);
// fetch addres from metamask
// contract function from our wallet

//export const mintDomain = async ({web3, sender, domain = '', gas}) => {
 // const domainValues = domain.split('.');
 // const registrarInstanceAddress =await getBlockChainAddressStorage(domainValues[1]);
 // let registrarInstance =  new mainnetXdc3.eth.Contract(registrar.abi, '0xfaA63424573A85718c260C076Dc17B775eb0c9B5'); //registrarInstanceAddress);
 // return registrarInstance.methods.mintDomain(sender,domainValues[1],domainValues[0],domainValues[1]).send({gas : gas,from : sender/*mainnetSenderAddress*/});
//}

//let provider = new ethers.providers.JsonRpcProvider("https://rpc.apothem.network");
const ethereum = window.ethereum;
const provider = new ethers.providers.Web3Provider(ethereum)
const provider2 = new ethers.providers.JsonRpcProvider('https://rpc.xinfin.network');
const signer = provider.getSigner()
const signer2 = provider2.getSigner()
//const mainnetXdc3 = new ethers.Wallet(privateKey).connect(provider);
const account = xdc3.eth.accounts.privateKeyToAccount(privateKey);
xdc3.eth.accounts.wallet.add(account);
const sender2 = xdc3.eth.accounts.wallet[0].address;


export const mintDomain = async ({web3, sender, domain = '', gas}) => {
  //const registry_ = await ethers.getContractFactory("RootRegistry");
  const domainValues = domain.split('.');
  //const registrarInstanceAddress =await getBlockChainAddressStorage(domainValues[1]);
  let registrarInstance =  new xdc3.eth.Contract(registry.abi, '0x2c10058b52c630eb5affa2fe8c6224aa9e7d06f4'); //registrarInstanceAddress);
  
//const registryInstance = new ethers.Contract('0x2c10058b52c630eb5affa2fe8c6224aa9e7d06f4',registry.abi, signer  );

const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
const account = accounts[0];


const sig = await getSignature(signer, ...[account,'fordham','webtest1','fordham',Math.round(Math.random()*1000)]);

 return registrarInstance.methods.mintDomain([account,'fordham','test_domain2','fordham',Math.round(Math.random()*1000)], sig).send({gas : gas,from : sender2/*mainnetSenderAddress*/});
  
//return registryInstance.mintDomain([account,'fordham','test_domain2','fordham',Math.round(Math.random()*1000)], sig )
}


export const getDomainTokenId =  async ({  domain = '', gas}) => {
  const domainValues = domain.split('.');
  //const registrarInstanceAddress =await getBlockChainAddressStorage(domainValues[1]);
  //let registrarInstance =  new mainnetXdc3.eth.Contract(registry, '0xfaA63424573A85718c260C076Dc17B775eb0c9B5');//registrarInstanceAddress);
  
  return 1//registrarInstance.methods.domainTokenId(domain, 1).send({gas : gas,from : '0xc205aDAE354dAE50664513344B05D342c4e87577'/*mainnetSenderAddress*/});
}

//const provider = new ethers.providers.Web3Provider(window.ethereum, "any");
// Prompt user for account connections
//await provider.send("eth_requestAccounts", []);
//const signer = provider.getSigner();
//console.log("Account:", await signer.getAddress()); 

/*export const connectwalletHandler = () => {
  if (window.ethereum) {
      provider.send("eth_requestAccounts", []).then(async () => {
          await accountChangedHandler(provider.getSigner());
      })
  } else {
      setErrorMessage("Please Install MetaMask!!!");
  }
} */

const toTypedOrder = (
  domain_owner, domain_parent, domain_label, domain_zone, domain_salt) => {


      const domain = {
           
          name: 'Fordham',
          version: '1',
          chainId: 50,
          verifyingContract: '0x2c10058b52c630eb5affa2fe8c6224aa9e7d06f4'
      };

  
       const types = {
          
          Order: [
              { name: 'owner', type: 'address' },
              { name: 'parent', type: 'string' },
              { name: 'label', type: 'string' },
              { name: 'zone', type: 'string'},
              { name: 'salt', type: 'uint256'}             
          ]
      };
  
  
     
  
       const value = {
          owner: domain_owner,
          parent: domain_parent,
          label: domain_label,
          zone: domain_zone,
          salt: domain_salt,
          Message: 'Approve Fordham to mint domain to your wallet'
      }

      const message = {
          DomainLabel : domain_label,
          ParentDomain : domain_parent,
          Message: 'Approve Fordham to mint domain to your wallet'
      }
  

  
      return  { domain, types, value} ;
  }
  
  
  
  const getSignature = async (signer,...args) => {
      //console.log(signer.address);
      const order = toTypedOrder(...args);
           // console.log(order.domain);

      const signedTypedHash =  await signer._signTypedData(
          order.domain,
          order.types,
          order.value,
          order.message
      );


      const sig = ethers.utils.splitSignature(signedTypedHash);

  
      return [sig.v, sig.r, sig.s];
  }
