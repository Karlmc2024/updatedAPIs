import HDWalletProvider from "@truffle/hdwallet-provider";

import XDC3 from "xdc3"
//import storage from './build/contracts/Storage.json';

const privKey = '0x37cd6dbcb5668adf3b45cc7313562dd6606dc352ca59662f94b3a22832a9c926';
// change the provider to mainnet url
// setup network configuration
const mainnetProvider = new HDWalletProvider(privKey,"https://rpc.xinfin.network");
export const mainnetXdc3 = new XDC3(mainnetProvider);
const account = mainnetXdc3.eth.accounts.privateKeyToAccount(privKey);
mainnetXdc3.eth.accounts.wallet.add(account);
export const mainnetSenderAddress = mainnetXdc3.eth.accounts.wallet[0].address;

/*export  default async function getBlockChainAddressStorage (zone) {
        let storageInstance =  new mainnetXdc3.eth.Contract(storage.abi, process.env.REACT_APP_ADDRESSES_STORAGE_ADDRESS) ;
        return storageInstance.methods.resolveAddress("registry",'production' || 'production' ).call();
} */
