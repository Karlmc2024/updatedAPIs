import  {ethers} from "ethers";
import Web3 from "xdc3"
import registrar from './build/contracts/RootRegistry.json'
import {mainnetXdc3, mainnetSenderAddress} from './xdc'

const ethereum = window.ethereum;

export const getWeb3 = () => {
  //return new Web3(Web3.givenProvider);
  return new ethers.providers.Web3Provider(window.ethereum)
}

export const getWeb3Account = async (web3) => {
 // return web3.eth.requestAccounts();
 const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
 return accounts;
} 
// fetch addres from metamask
// contract function from our wallet

const provider = new ethers.providers.Web3Provider(ethereum)
const signer =  provider.getSigner()

export const mintDomain = async ({web3, sender, domain = '', gas}) => {
  const domainValues = domain.split('.');

  const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
  const account = accounts[0];
  
  const ChainId = '0x32'

  if(await ethereum.request({ method: 'eth_chainId' }) != ChainId){
    try {
      await ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: ChainId}],
      });
    } catch (switchError) {
       if (switchError.code === 4902) {
         console.log("This network is not available in your metamask.")
        }
       console.log("Failed to switch to the network")
} 
  }
  

  let salt = Math.round(Math.random()*1000000)
  let message = 'Approve Fordham to mint domain to your wallet'
  const Order = [account,domainValues[1],domainValues[0],domainValues[1], salt, message]
  
  const sig = await getSignature(signer, ...Order);

  let registrarInstance =  new mainnetXdc3.eth.Contract(registrar.abi, '0xfe48f76c20b22bda6c149e69ed36f518eafce5e4');
  
  return registrarInstance.methods.mintDomain(Order, sig).send({gas : gas,from : mainnetSenderAddress});
}

export const getDomainTokenId =  async ({  domain = '', gas}) => {
  const domainValues = domain.split('.');
  let registrarInstance =  new mainnetXdc3.eth.Contract(registrar.abi, '0xfe48f76c20b22bda6c149e69ed36f518eafce5e4');
  
  const tx = await registrarInstance.methods.domainInfo(domain).call()
  console.log(tx.tokenId);
  return tx.tokenId;
}


const toTypedOrder = (
  domain_owner, domain_parent, domain_label, domain_zone, domain_salt) => {


      const domain = {
           
          name: 'Fordham',
          version: '1',
          chainId: 50,
          verifyingContract: '0xfe48f76c20b22bda6c149e69ed36f518eafce5e4'
      };

  
       const types = {
          
          Order: [
              { name: 'owner', type: 'address' },
              { name: 'parent', type: 'string' },
              { name: 'label', type: 'string' },
              { name: 'zone', type: 'string'},
              { name: 'salt', type: 'uint256'},
              { name: 'message', type: 'string'}             
             
          ]
      };
  
  
     
  
       const value = {
          owner: domain_owner,
          parent: domain_parent,
          label: domain_label,
          zone: domain_zone,
          salt: domain_salt,
          message: 'Approve Fordham to mint domain to your wallet'
      }

      const message = {
          DomainLabel : domain_label,
          ParentDomain : domain_parent,
          Message: 'Approve Fordham to mint domain to your wallet'
      }
  

  
      return  { domain, types, value} ;
  }
  
  
  
  const getSignature = async (signer,...args) => {
      const order = toTypedOrder(...args);

      const signedTypedHash =  await signer._signTypedData(
          order.domain,
          order.types,
          order.value,
          order.message
      );


      const sig = ethers.utils.splitSignature(signedTypedHash);

  
      return [sig.v, sig.r, sig.s];
  }
