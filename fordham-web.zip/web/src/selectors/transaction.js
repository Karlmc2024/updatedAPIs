export const getTransactionInfo = state => {
  return state.entities.transactionInfo || null;
};
export const getTransactionMode = state =>
  state.entities.transactionMode || null;

export const getOrderId = state => state.entities.orderId || null;

export const getMyOrders = state => state.entities.myOrders || [];
export const getOrder = state => state.entities.order || null;

export const getOrderDomain = state => state.entities.domainsToConfigure;
export const getMyDomains = state => state.entities.myDomains || [];

export const transactionStatus = state => state.entities.txStatus || null;
export const premiumDomains = state => state.entities.premiumDomains || [];

export const availableCoupons = state => state.entities.availableCoupons || [];

export const creditsOptions = state => state.entities.creditsOptions || [];
export const influencerOptions = state =>
  state.entities.influencerOptions || [];
export const creditsNexbTokens = state => state.entities.creditsNexbTokens || 0;
export const getMyCredits = state => state.entities.myCredits || null;
export const creditsPaymentMode = state =>
  state.entities.creditsPaymentMode || null;
export const creditsTransactionInfo = state =>
  state.entities.creditsTransactionInfo || null;
