let initialState = {
  currentUser: null,
  cartDetails: [],
  transactionInfo: null,
  paymentMode: null,
  trademarkRequests
};

function userReducer(state = initialState, action) {
  switch (action.type) {
    case 'SET_CURRENT_USER':
      return { ...state, currentUser: action.data };
    case 'SET_CART':
      return { ...state, cartDetails: action.data };
    case 'ADD_TO_CART':
      return {
        ...state,
        cartDetails: [...state.cartDetails, ...[action.data]],
      };
    case 'INITIATE_PAYMENT':
      return {
        ...state,
        transactionInfo: action.data.transactionInfo,
        paymentMode: action.data.mode,
      };
    case 'CLOSE_PAYMENT':
      return {
        ...state,
        transactionInfo: null,
        paymentMode: null,
      };
    default:
      return state;
  }
}

export default userReducer;
