import {
  Stack,
  Text,
  Button} from '@chakra-ui/react';
import React from 'react';
import { useHistory } from 'react-router-dom';
import { AiOutlineShoppingCart, AiOutlineHeart} from 'react-icons/ai';

import { addToCartMutation,getCartDetails } from 'entities/cartEntity';
import { useMutation } from 'redux-query-react';
import { useSelector } from 'react-redux';
import { addToCart } from './cartUtils';
import { getWishlist,addToWishlistMutation } from 'pages/Wishlist/entities';
import {customToast} from 'components/common/Toast'
import {addToWishlist} from 'pages/Wishlist/utils'
const style = { color: "red" }

export default function DomainCard({ domainName, price,tldId, id, available, isPremium,isDomainTradeMarked }) {
  const [{isPending:isAddToCartPending}, addToCartApi] = useMutation(addToCartMutation);
  const [{isPending:isAddToWishlistPending}, addToWishlistApi] = useMutation(addToWishlistMutation);
  const cartData = useSelector(getCartDetails);
  const wishlist = useSelector(getWishlist)
  const existsInCart = cartData?.some(item => item.domainName === domainName);
  const existsInWishlist = wishlist?.some(item => item.domainName === domainName);
  const history = useHistory();
  const handleAddCartItem = item => {
    if (!existsInCart) {
      // if(cartData.length >= 2){
      //   customToast({status:"warning",title:"Warning",description:"You cannot buy more than two domain for now!"})
      //   return;
      // }
      addToCart(item, addToCartApi);
    } else {
      history.push('/cart');
    }
  };

  const handleAddToWishlist = item => {
    if(!existsInWishlist){
      addToWishlist(item,addToWishlistApi);
    }
    else{
      history.push('/wishlist');
    }
  }
  if((available === false)){
    return (
      <Stack
      alignItems="center"
      py="16"
      px="16"
      maxW='420px'
      boxShadow="lg"
      borderRadius="lg"
      bg="white"
      mb="4"
      color="black"
      >
         <Text fontSize="2xl" fontWeight="semibold" color="brand.500">
           {domainName}
         </Text>
        <Text size="md">
        Oops <b style={{color:'red'}}>{domainName}</b> is Not Available
        </Text>
      </Stack>
    );
  }

  if(isDomainTradeMarked === true){
    return (
        <Stack
            alignItems="center"
            py="16"
            px="16"
            maxW='420px'
            boxShadow="lg"
            borderRadius="lg"
            bg="white"
            mb="4"
            color="black"
        >
          <Stack justify="flex-end" direction="row" width="full" mt="-8" mr="-8">
            <Text
                bgGradient="linear(to-r, green.400, green.600)"
                fontSize="sm"
                px="2"
                py="1"
                fontWeight="semibold"
                borderRadius="sm"
                color="white"
            >
              Trademark
            </Text>
          </Stack>

            <Text fontSize="2xl" fontWeight="semibold" color="brand.500">
              {domainName}
            </Text>
            <Text textAlign='left'>
              This domain may be trademarked. If you are the owner and would like to Reserve it,
              Please contact <b style={{color:'red'}}>support@fordham.edu </b> for guidelines.
            </Text>
        <Stack>
        <Button
        onClick={()=> history.push({
          pathname :"/request-trademark",
          domainName :domainName
        })}
        >
        Request Purchase
        </Button>
        
        </Stack>
        </Stack>
    );
  }

  return (
    <Stack
      alignItems="center"
      p="12"
      boxShadow="md"
      borderRadius="lg"
      bg="white"
      mb="4"
    >
      <Stack alignItems="center" spacing="4">
        {
          isPremium ? <Stack justify="flex-end" direction="row" width="full" mt="-8" mr="-8"> 
          <Text
            bgGradient="linear(to-r, green.400, green.600)"
            fontSize="sm"
            px="2"
            py="1"
            fontWeight="semibold"
            borderRadius="sm"
            color="white"
          >
            Premium
          </Text>
      </Stack> : null
        }
        <Text fontSize="2xl" fontWeight="semibold" color="brand.500">
          {domainName}
        </Text>
        <Text>Reserve your domain starting at</Text>
        <Stack direction="row" alignItems="center" justifyContent="center">
          <Text fontSize="2xl" fontWeight="normal" color="brand.600">
              <small style={{ color: 'red' }}>${price}</small>{' '}
          </Text>
        </Stack>
      </Stack>
      <Stack>
        <Button
          leftIcon={<AiOutlineShoppingCart />}
          onClick={() => handleAddCartItem({ domainName,tld:tldId , price, _id: id })}
          isLoading={isAddToCartPending}
          loadingText="Adding to cart..."
        >
          {existsInCart ? 'Checkout' : 'Add to Cart'}
        </Button>
        <Button
          leftIcon={
            <AiOutlineHeart
              style={existsInWishlist ? style : ''}
              fontSize="20px"
            />
          }
          onClick={() => handleAddToWishlist({ domainName, tld:tldId, price, _id: id })}
          variant="outline"
        >
          {existsInWishlist ? 'Go to Wishlist' : 'Add to Wishlist'}
        </Button>
      </Stack>
    </Stack>
  );
}
