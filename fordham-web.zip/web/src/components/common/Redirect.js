import React, { Component } from "react";

export class Redirect extends Component {
    constructor( props ){
        super(props);
        this.state = { ...props };
    }
    componentWillMount(){
        window.open(this.state.href,"_blank");
    }
    render(){
        return (<section>Redirecting...</section>);
    }
}

export default Redirect;