import React from 'react'
import  { IoMdArrowRoundBack } from "react-icons/io";
import { Button, HStack } from '@chakra-ui/react';
import { Link } from 'react-router-dom';

export default function BackButton({children, path}) {

  return (
    <HStack py="2" pl="4">
        <Button type="link" aria-label='Close' variant="ghost" leftIcon={<IoMdArrowRoundBack size="24px"/>}>
          <Link to={path}>
            {children}
          </Link>
        </Button>
    </HStack>
  )
}
