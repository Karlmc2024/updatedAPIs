import React from 'react'
import { HStack, Stack, Circle, Divider, Text } from '@chakra-ui/react'
import { MdDone } from 'react-icons/md'

const StepperContent = ({ isActive, heading, footer, description, checked , index, headingDirection="column", contentWidth }) => {
  const color = isActive || checked ? 'white' : 'brand.500'
  const bg = isActive || checked ? 'brand.500' : '#fff'
  return <Stack justify="flex-start" align="center">
    <Stack direction={headingDirection} alignItems="center"
      {...contentWidth && { width: contentWidth }}
    >
      <Circle color={color} size="40px" bg={bg}>
        {checked?<MdDone/>:index}
      </Circle>
      <Text>
        {heading}
      </Text>
    </Stack>
    <Text fontSize="xs">
      {description}
    </Text>
    <Text fontSize="xs" fontWeight="semibold">
      {footer}
    </Text>

  </Stack>
}

const StepperDividerLine = ({ isActive }) => {
  return <Divider style={{ marginTop: "20px" }} orientation="horizontal" borderBottomWidth="2px" borderBottomColor={isActive ? "brand.500" : "gray.400"} />
}

export default function HorizantalStepper({ stepperData, activeIndex, headingDirection, showChecked, contentWidth }) {

  return (
    <HStack
             align="flex-start"
    >
      {
        stepperData.map(({ heading, footer, description }, index) => {
          return <React.Fragment key={index}>
            <StepperContent
              heading={heading}
              footer={footer}
              description={description}
              isActive={activeIndex === index}
              index={index + 1}
              headingDirection={headingDirection}
              checked={showChecked && index<activeIndex}
              contentWidth={contentWidth}
              />
            {index + 1 !== stepperData.length && <StepperDividerLine />}

          </React.Fragment>

        })
      }
    </HStack>
  )
}
