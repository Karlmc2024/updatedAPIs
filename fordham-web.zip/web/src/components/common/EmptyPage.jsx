import { Box, Heading, Text, Button } from '@chakra-ui/react';
import { Link } from 'react-router-dom';

export default function EmptyPage({headingText, titleText, subTitleText , buttonText, buttonLink}) {
  return (
    <Box textAlign="center" py={10} px={6}>
      <Heading
        display="inline-block"
        as="h2"
        size="2xl"
        bg='brand.500'
        backgroundClip="text">
        {headingText}
      </Heading>
      <Text fontSize="18px" mt={3} mb={2}>
        {titleText}
      </Text>
      <Text color={'gray.500'} mb={6}>
        {subTitleText}
      </Text>

      <Button
        colorScheme="brand"
        bg='brand.500'
        color="white"
        variant="solid">
          <Link style={{color:'#fff'}} to={buttonLink}>
              {buttonText}
          </Link>
      </Button>
    </Box>
  );
}
