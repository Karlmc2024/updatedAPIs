import React from 'react'
import {
  AlertDialog,
  AlertDialogBody,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogContent,
  AlertDialogOverlay,
  Button
} from "@chakra-ui/react"

export default function Alert({isOpen, header ,message="Your account has been created. You can log in now.", onOk, okText= "Okay"}) {

  const handleOnOk = () => {
    if(onOk && typeof onOk === 'function'){
      onOk()
    }
  }


  return (
    <>
      <AlertDialog
        isOpen={isOpen}
      >
        <AlertDialogOverlay>
          <AlertDialogContent>
            <AlertDialogHeader fontSize="lg" fontWeight="bold">
              {header}
            </AlertDialogHeader>

            <AlertDialogBody>
              {message}
            </AlertDialogBody>

            <AlertDialogFooter>
              <Button onClick={handleOnOk}>
                {okText}
              </Button>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialogOverlay>
      </AlertDialog>
    </>
  )
}