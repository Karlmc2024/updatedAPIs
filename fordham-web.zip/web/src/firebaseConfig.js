// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: 'AIzaSyCyA2GwR0itGhoC6s4ENowNlAZJZTw1ENA',
  authDomain: 'nexweb-566fd.firebaseapp.com',
  projectId: 'nexweb-566fd',
  storageBucket: 'nexweb-566fd.appspot.com',
  messagingSenderId: '6937766054',
  appId: '1:6937766054:web:37c9958551844e66af2c67',
  measurementId: 'G-YR3BEESZ5B',
};

export default firebaseConfig;
