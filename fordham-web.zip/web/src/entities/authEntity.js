export const makeLoginMutation = ({ email, password }) => ({
  url: `/api/login`,
  body: {
    email,
    password,
  },
  transform: (responseBody) => {
    const {data,result } = responseBody || {};
    const res = data || result;
    if (res?.token) {
      let { token, user, refreshToken } = res || {};
      localStorage.setItem("token", token);
      localStorage.setItem("user", JSON.stringify(user));
      localStorage.setItem("refreshToken", JSON.stringify(refreshToken));
    }
    return res;
  },
  update: {
    authData: (oldValue, newValue) => newValue,
  },
});

export const makeSignupMutation = (data) => ({
  url: `/api/signup`,
  body: data,
  transform: (responseBody) => {
    const {data,result } = responseBody || {};
    const res = data || result;
    return {registerData: res};
  },
  update: {
    registerData: (oldValue, newValue) => newValue,
  },
});


export const makeForgotPasswordMutation = (data) => ({
  url: `/api/forgot-password`,
  body: data,
  transform: (responseBody) => {
    const {data,result } = responseBody || {};
    return {
      forgotPassword: data || result,
    };
  },
  update: {
    forgotPassword: (oldValue, newValue) => newValue,
  },
});


export const makeResetPasswordMutation = ({userId,token,password}) => ({
  url: `/api/reset-password/${userId}/${token}`,
  body: {password},
  options:{
    method:"PUT"
  },
  transform: (responseBody) => {
    const {data,result } = responseBody || {};
    return {
      resetPassword: data || result,
    };
  },
  update: {
    resetPassword: (oldValue, newValue) => newValue,
  },
});

export const makeChangePasswordMutation = ({password}) => ({
  url: `/api/change-password`,
  body: {password},
  options:{
    method:"PUT"
  },
  transform: (responseBody) => {
    const {data,result } = responseBody || {};
    return {
      changePassword: data || result,
    };
  },
  update: {
    changePassword: (oldValue, newValue) => newValue,
  },
});


export const verifyEmailRequest = ({userId,token}) => ({
  url: `/api/verify-account/${userId}/${token}`,
  transform: (responseBody) => {
    const {data,result } = responseBody || {};
    return {
      verifyEmail: data || result,
    }
  },
  update:{
    verifyEmail: (oldValue, newValue) => newValue,
  }
})

export const getRegisterDetails = state => state.entities.registerData
export const verifyEmailDetails = state => state.entities.verifyEmail