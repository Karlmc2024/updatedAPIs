import "@testing-library/cypress/add-commands";
import "@synthetixio/synpress/support";
