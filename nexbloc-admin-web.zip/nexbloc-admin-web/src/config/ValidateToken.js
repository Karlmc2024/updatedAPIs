import {getToken , getUser} from '../../config/index';


let initState = {
    user : null,
    token :null
}


const verifytoken = (token) => {
    try {
        const decodedToken = jwt_decode(token);
        const ExpireIn = new Date(decodedToken.exp * 1000);
        if (new Date() > ExpireIn) {
            localStorage.removeItem('user');
            return null;
        } else {
            return decodedToken;
        }
    } catch (error) {
        return null;
    }
};

let  token  = getToken();
let user  = getUser();
const setToken = (token, user)=>{
    console.warn("the set token called")
    if (token && user) {
        const decodetoken = verifytoken(token);
        if (decodetoken) {
            initState.token  = token;
            initState.user = user;
            return;
        }
    }
    return;    
}

setToken(token, user);
