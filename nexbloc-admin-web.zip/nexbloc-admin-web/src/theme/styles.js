import { mode } from "@chakra-ui/theme-tools";

export const globalStyles = {
  colors: {
    gray: {
      700: "#1f2733",
    },
    blue: {
      100 : "#5b35f9",
      200 :"#5b35f9",
      300: "#0000FF"
    }
  },
  styles: {
    global: (props) => ({
      body: {
        bg: mode("blue.50", "gray.800")(props),
        fontFamily: 'Helvetica, sans-serif'
      },
      html: {
        fontFamily: 'Helvetica, sans-serif'
      }
    }),
  },
};
