export const formatCurruntMonthly =(data)=>{
    
}