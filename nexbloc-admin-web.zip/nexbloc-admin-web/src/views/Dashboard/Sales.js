import {
    Box,
    Flex,
    Grid,
    Text,
    FormControl,
    Input,
    Select,
    Avatar,
    Wrap,
    WrapItem,
    useDisclosure,
    Spacer,
    Button,
    ModalContent,
    ModalCloseButton,
    Center,
    Stat,
    StatNumber,
    StatLabel,
    ModalBody,
    InputGroup,
    InputLeftElement,
    ModalHeader,
    ModalOverlay,
    ModalFooter,
    FormLabel,
    Tooltip,
    useColorModeValue,
    SimpleGrid
} from "@chakra-ui/react";
import React, { useState, useEffect } from 'react';
import Card from "components/Card/Card.js";
import BarChart from 'components/Charts/BarChart';
import PieChart from 'components/Charts/PieChart';
import LineChart from 'components/Charts/LineChart';
import { useSelector } from 'react-redux';
import moment from 'moment';
import {useDispatch} from 'react-redux';
import CardBody from "components/Card/CardBody.js";
import {useToast} from '@chakra-ui/toast';
import {gettotalSale, getCurruntMonthSaleReports, getMonthWiseReport , getYearlySaleReport, downloadSale} from '../../store/actions/sale-report';
import DownloadButton from "views/Common/DownloadButton";

export default function sales(props) {
    const  now = new Date();
    const textColor = useColorModeValue("black", "white");
    const today = moment().format("YYYY-MM-DD");
    const start  = moment().subtract(1, "month").format("YYYY-MM-DD");
    const dispatch  = useDispatch();
    const toast  = useToast();
    const [graphdata, setgraphdata] = useState({ start:start , end:today , filetype: "xls", ischanged: false });
    const loader = useSelector(state => state.loaderReducer.loader);
    const fileloader = useSelector(state => state.fileloaderReducer.loader);
    const salesreport  = useSelector(state => state.salereportReducer);
    function changegraphdata(e){
        setgraphdata({...graphdata , [e.target.name] : e.target.value});
    }
    
    const handeldownload = () => {
    dispatch(downloadSale({filetype :  graphdata.filetype , startdate :  graphdata.start , enddate : graphdata.end}, toast));  

    }
    useEffect(()=>{
        dispatch(getCurruntMonthSaleReports( { startdate : 1  ,  enddate :now.getDate()},toast ));
        dispatch( getMonthWiseReport({startmonth : 1 , endmonth : now.getMonth() }, toast));
        dispatch(getYearlySaleReport({startyear : 2012 , endyear:  now.getFullYear()}, toast));
        dispatch(gettotalSale(toast));
    }, [])

    return (
        <Flex color={textColor} flexDirection="column" pt={{ base: "120px", md: "75px" }}>
            <Grid templateColumns={{ sm: "1fr", lg: "1fr" }}
                templateRows={{ sm: "repeat(2, 1fr)", lg: "1fr" }}
                gap="24px"
                mb={{ lg: "26px" }}
                mt={{ lg: "26px", base: "20px" }}>
                <Card>
                    <Text
                        fontSize="3xl"
                        color={textColor}
                        fontWeight="bold"
                    >
                        Sale Reports
                    </Text>
                    <SimpleGrid columns={{ sm: 1, md: 2, xl: 4 }}>
                        <Card minH="83px">
                            <FormControl >
                                        <FormLabel htmlFor='start'>From <span>(MM/DD/YYYY)</span></FormLabel>
                                        <Input type="date" name="start" onChange={changegraphdata} value={graphdata.start} w={"80%"} />
                                    </FormControl>
                            
                        </Card>
                        <Card minH="83px">
                            <CardBody>
                            <FormControl>
                                        <FormLabel htmlFor='end'>To <span>(MM/DD/YYYY)</span></FormLabel>
                                        <Input type="date" name="end" onChange={changegraphdata} value={graphdata.end} w="80%" />
                                    </FormControl>
                            </CardBody>
                        </Card>
                        <Card minH="83px">
                            <CardBody>
                            <FormControl>
                                        <FormLabel htmlFor='email'>Select file type</FormLabel>
                                        <Select placeholder='Select file type' name="filetype" onChange={changegraphdata} w={"80%"}>
                                            <option  value="xls" selected={true}>.xls</option>
                                            <option  value="csv">.csv</option>
                                        </Select>
                                    </FormControl>
                            </CardBody>
                        </Card>
                        <Card>
                            <CardBody>
                            <DownloadButton fileloader={fileloader} handeldownload={handeldownload}/>

                            </CardBody>
                        </Card>
                    </SimpleGrid>
                    
                </Card>
                <Card>
                    <Text fontWeight={"bold"}> Current Month Sale ({new Date().toLocaleString('default', { month: 'long' })}) </Text>
                    <SimpleGrid columns={{ sm: 1, md: 2, xl: 4 }} spacing="24px">
                        <Card minH="83px">
                            <CardBody>
                                <Flex flexDirection="row" align="center" justify="center" w="100%">
                                    <Stat me="auto">
                                        <StatLabel
                                            fontSize="sm"
                                            color={textColor}
                                            fontWeight="bold"
                                            pb=".1rem"
                                        >
                                            Domain Sale
                                        </StatLabel>
                                        <Flex>
                                            <StatNumber fontSize="lg" color={textColor}>
                                            ${salesreport.daytodaySale.domain}
                                            </StatNumber>

                                        </Flex>
                                    </Stat>

                                </Flex>
                            </CardBody>
                        </Card>
                        <Card minH="83px">
                            <CardBody>
                                <Flex flexDirection="row" align="center" justify="center" w="100%">
                                    <Stat>
                                        <StatLabel
                                            fontSize="sm"
                                            color={textColor}
                                            fontWeight="bold"
                                            pb=".1rem"
                                        >
                                            Premium Domain Sale
                                        </StatLabel>
                                        <Flex>
                                            <StatNumber fontSize="lg" color={textColor}>
                                                ${salesreport.daytodaySale.premiumdomain}
                                            </StatNumber>
                                        </Flex>
                                    </Stat>

                                </Flex>
                            </CardBody>
                        </Card>
                        <Card minH="83px">
                            <CardBody>
                                <Flex flexDirection="row" align="center" justify="center" w="150%">
                                    <Stat me="auto">
                                        <StatLabel
                                            fontSize="sm"
                                            color={textColor}
                                            fontWeight="bold"
                                            pb=".1rem"
                                        >
                                            Total Current month Sale
                                        </StatLabel>
                                        <Flex>
                                            <StatNumber fontSize="lg" color={textColor} fontWeight="bold">
                                                $ {salesreport.daytodaySale.total}
                                            </StatNumber>

                                        </Flex>
                                    </Stat>

                                </Flex>
                            </CardBody>
                        </Card>
                    </SimpleGrid>
                    <SimpleGrid columns={{ sm: 1, md: 2, xl: 2 }} spacing="24px">
                    
                        <Card>
                            <CardBody>
                              <LineChart xaxies = {salesreport.daytodaySale.xaxies } yaxies  ={salesreport.daytodaySale.yaxies} title ={"Current Month Report"} width="450" ></LineChart>
                            </CardBody>
                        </Card>
                        <Card>
                            <CardBody>
                                <PieChart labels  = {[ "Domain", "Premium Domain"]} series ={[Math.abs((salesreport.daytodaySale.domain/salesreport.daytodaySale.total)*100), Math.abs((salesreport.daytodaySale.premiumdomain/salesreport.daytodaySale.total)*100)]} title ={"Domain and Premium Domain Sale Ratio"}></PieChart>
                            </CardBody>
                        </Card>
                    </SimpleGrid>
                </Card>
                <Card>
                    <Text fontWeight={"bold"}> Current Year Sale ({new Date().getFullYear()})</Text>
                    <SimpleGrid columns={{ sm: 1, md: 2, xl: 4 }} spacing="24px">
                        <Card minH="83px">
                            <CardBody>
                                <Flex flexDirection="row" align="center" justify="center" w="100%">
                                    <Stat me="auto">
                                        <StatLabel
                                            fontSize="sm"
                                            color={textColor}
                                            fontWeight="bold"
                                            pb=".1rem"
                                        >
                                            Domain Sale
                                        </StatLabel>
                                        <Flex>
                                            <StatNumber fontSize="lg" color={textColor}>
                                                ${salesreport.monthlySale.domain}
                                            </StatNumber>

                                        </Flex>
                                    </Stat>

                                </Flex>
                            </CardBody>
                        </Card>
                        <Card minH="83px">
                            <CardBody>
                                <Flex flexDirection="row" align="center" justify="center" w="100%">
                                    <Stat>
                                        <StatLabel
                                            fontSize="sm"
                                            color={textColor}
                                            fontWeight="bold"
                                            pb=".1rem"
                                        >
                                            Premium Domain Sale
                                        </StatLabel>
                                        <Flex>
                                            <StatNumber fontSize="lg" color={textColor}>
                                                ${salesreport.monthlySale.premiumdomain}
                                            </StatNumber>

                                        </Flex>
                                    </Stat>

                                </Flex>
                            </CardBody>
                        </Card>
                        <Card minH="83px">
                            <CardBody>
                                <Flex flexDirection="row" align="center" justify="center" w="150%">
                                    <Stat me="auto">
                                        <StatLabel
                                            fontSize="sm"
                                            color={textColor}
                                            fontWeight="bold"
                                            pb=".1rem"
                                        >
                                            Total Current Year Sale
                                        </StatLabel>
                                        <Flex>
                                            <StatNumber fontSize="lg" color={textColor} fontWeight="bold">
                                                ${salesreport.monthlySale.total}
                                            </StatNumber>

                                        </Flex>
                                    </Stat>

                                </Flex>
                            </CardBody>
                        </Card>
                    </SimpleGrid>
                    <SimpleGrid columns={{ sm: 1, md: 2, xl: 2 }} spacing="24px">
                    
                        <Card>
                            <CardBody>
                              <LineChart xaxies={salesreport.monthlySale.xaxies} yaxies={salesreport.monthlySale.yaxies} title={"Current Year Monthly Sale"} width="450"></LineChart>
                            </CardBody>
                        </Card>
                        <Card>
                            <CardBody>
                                <PieChart labels  = {[ "Domain", "Premium Domain"]} title={"Domain and Premium Domain Sale Ratio"} series ={[Math.abs((salesreport.monthlySale.domain/salesreport.monthlySale.total)*100), Math.abs((salesreport.monthlySale.premiumdomain/salesreport.monthlySale.total)*100)]}></PieChart>
                            </CardBody>
                        </Card>
                    </SimpleGrid>
                </Card>
                <Card>
                    <Text fontWeight={"bold"}> Yearly Sale report</Text>
                    <SimpleGrid columns={{ sm: 1, md: 2, xl: 4 }} spacing="24px">
                        <Card minH="83px">
                            <CardBody>
                                <Flex flexDirection="row" align="center" justify="center" w="100%">
                                    <Stat me="auto">
                                        <StatLabel
                                            fontSize="sm"
                                            color={textColor}
                                            fontWeight="bold"
                                            pb=".1rem"
                                        >
                                            Domain Sale
                                        </StatLabel>
                                        <Flex>
                                            <StatNumber fontSize="lg" color={textColor}>
                                                ${salesreport.yearlySale.domain}
                                            </StatNumber>

                                        </Flex>
                                    </Stat>

                                </Flex>
                            </CardBody>
                        </Card>
                        <Card minH="83px">
                            <CardBody>
                                <Flex flexDirection="row" align="center" justify="center" w="100%">
                                    <Stat>
                                        <StatLabel
                                            fontSize="sm"
                                            color={textColor}
                                            fontWeight="bold"
                                            pb=".1rem"
                                        >
                                            Premium Domain Sale
                                        </StatLabel>
                                        <Flex>
                                            <StatNumber fontSize="lg" color={textColor}>
                                                ${salesreport.yearlySale.premiumdomain}
                                            </StatNumber>

                                        </Flex>
                                    </Stat>

                                </Flex>
                            </CardBody>
                        </Card>
                        <Card minH="83px">
                            <CardBody>
                                <Flex flexDirection="row" align="center" justify="center" w="150%">
                                    <Stat me="auto">
                                        <StatLabel
                                            fontSize="sm"
                                            color={textColor}
                                            fontWeight="bold"
                                            pb=".1rem"
                                        >
                                            Total  Sale
                                        </StatLabel>
                                        <Flex>
                                            <StatNumber fontSize="lg" color={textColor} fontWeight="bold">
                                                ${salesreport.yearlySale.total}
                                            </StatNumber>

                                        </Flex>
                                    </Stat>

                                </Flex>
                            </CardBody>
                        </Card>
                    </SimpleGrid>
                    <SimpleGrid columns={{ sm: 1, md: 2, xl: 2 }} spacing="24px">
                    
                        <Card>
                            <CardBody>
                            <LineChart xaxies = {salesreport.yearlySale.xaxies } yaxies  ={salesreport.yearlySale.yaxies} width="450" title={"Yealy Sale Report"} ></LineChart>

                            </CardBody>
                        </Card>
                        <Card>
                            <CardBody>
                                <PieChart title= {"Domain and Premium Domain Sale ratio"} labels  = {[ "Domain", "Premium Domain"]} series ={[Math.abs((salesreport.yearlySale.domain/salesreport.yearlySale.total)*100), Math.abs((salesreport.yearlySale.premiumdomain/salesreport.yearlySale.total)*100)]}></PieChart>
                            </CardBody>
                        </Card>
                    </SimpleGrid>
                </Card>
            </Grid>
        </Flex>
    )
}