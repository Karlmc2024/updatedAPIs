// Chakra imports
import {
  Box,
  Flex,
  Grid,
  Icon,
  Progress,
  SimpleGrid,
  Stat,
  StatHelpText,
  StatLabel,
  StatNumber,
  Table,
  Tbody,
  Text,
  Th,
  Thead,
  Tr,
  useDisclosure,
  useColorMode,
  useColorModeValue,
} from "@chakra-ui/react";
// Custom components
import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js";
import CardHeader from "components/Card/CardHeader.js";
import BarChart from "components/Charts/BarChart";
import LineChart from "components/Charts/LineChart";
import IconBox from "components/Icons/IconBox";

// Custom icons
import {
  CartIcon,
  DocumentIcon,
  GlobeIcon,
  RocketIcon,
  StatsIcon,
  PersonIcon,
  WalletIcon,
} from "../../components/Icons/Icons";
import DashboardTableRow from "components/Tables/DashboardTableRow";
import TimelineRow from "components/Tables/TimelineRow";
import React, { useState, useEffect } from "react";
// react icons
import { AttachMoney } from '@material-ui/icons';
import { useSelector, useDispatch } from 'react-redux';
import { BsArrowRight } from "react-icons/bs";
import { IoCheckmarkDoneCircleSharp } from "react-icons/io5";
import { dashboardTableData, timelineData } from "variables/general";
import { getTodayusercount } from '../../store/actions/user';
import { getTodaydomaincount, getTotalBookDomainCount } from '../../store/actions/domain';
import { getTodaypremiumdomaincount } from '../../store/actions/premium-domain';
import { useToast } from '@chakra-ui/toast';
import { gettotalSale, getCurruntMonthSaleReports, getYearlySaleReport  } from '../../store/actions/sale-report';
import { getCurruntMonthUserReports , getYearlyUserReport} from '../../store/actions/user-report';
export default function Dashboard() {
  const toast = useToast();
  // Chakra Color Mode
  const { isOpen, onOpen, onClose } = useDisclosure();

  const dispatch = useDispatch();
  const { colorMode, toggleColorMode } = useColorMode();
  const iconTeal = useColorModeValue("blue.200", "blue.200");
  const iconBoxInside = useColorModeValue("white", "white");
  const textColor = useColorModeValue("black", "white");
  const countdata = useSelector(state => state.countReducer);
  const now = new Date();
  const loader = useSelector(state => state.loaderReducer.loader);
  const salereports = useSelector(state => state.salereportReducer);
  const userreports = useSelector(state => state.userreportReducer);


  const overlayRef = React.useRef();

  useEffect(() => {
    dispatch(gettotalSale(toast));
    dispatch(getTodayusercount(toast));
    dispatch(getTodaydomaincount(toast));
    dispatch(getCurruntMonthSaleReports({ startdate: 1, enddate: now.getDate() }, toast));
    dispatch(getCurruntMonthUserReports({ startdate: 1, enddate: now.getDate() }, toast))
    dispatch(getTotalBookDomainCount(toast));
    // to calculate percentage of extra users are join  in currunt year 
    dispatch(getYearlyUserReport({ startyear: 2021, endyear: now.getFullYear() }, toast));
    // percentage of extra sale in gain in currunt year 
    dispatch(getYearlySaleReport({ startyear: 2012, endyear: now.getFullYear() }, toast));
  }, [])
  
  return (
    <Flex flexDirection="column" pt={{ base: "120px", md: "75px" }}>
      <SimpleGrid columns={{ sm: 1, md: 2, xl: 4 }} spacing="24px">
        <Card minH="83px">
          <CardBody>
            <Flex flexDirection="row" align="center" justify="center" w="100%">
              <Stat me="auto">
                <StatLabel
                  fontSize="sm"
                  color={textColor}
                  fontWeight="bold"
                  pb=".1rem"
                >
                  Today's Users
                </StatLabel>
                <Flex>
                  <StatNumber fontSize="lg" color={textColor}>

                    + {loader ? " Loding..." : countdata.today_users}
                  </StatNumber>

                </Flex>
              </Stat>
              <IconBox as="box" h={"45px"} w={"45px"} bg="blue.200">
                <PersonIcon h={"24px"} w={"24px"} color={iconBoxInside} />
              </IconBox>
            </Flex>
          </CardBody>
        </Card>
        <Card minH="83px">
          <CardBody>
            <Flex flexDirection="row" align="center" justify="center" w="100%">
              <Stat me="auto">
                <StatLabel
                  fontSize="sm"
                  color={textColor}
                  fontWeight="bold"
                  pb=".1rem"
                >
                  Today's Domains
                </StatLabel>
                <Flex>
                  <StatNumber fontSize="lg" color={textColor}>
                    + {loader ? "Loading..." : countdata.today_domains}
                  </StatNumber>

                </Flex>
              </Stat>
              <IconBox as="box" h={"45px"} w={"45px"} bg="blue.200">
                <GlobeIcon h={"24px"} w={"24px"} color={iconBoxInside} />
              </IconBox>
            </Flex>
          </CardBody>
        </Card>
        <Card minH="83px">
          <CardBody>
            <Flex flexDirection="row" align="center" justify="center" w="100%">
              <Stat>
                <StatLabel
                  fontSize="sm"
                  color={textColor}
                  fontWeight="bold"
                  pb=".1rem"
                >
                  Total Booked Domains
                </StatLabel>
                <Flex>
                  <StatNumber fontSize="lg" color={textColor}>
                    {loader ? "Loading..." : countdata.total_book_domains}
                  </StatNumber>

                </Flex>
              </Stat>
              <IconBox as="box" h={"45px"} w={"45px"} bg={"blue.200"}>
                <DocumentIcon h={"24px"} w={"24px"} color={iconBoxInside} />
              </IconBox>
            </Flex>
          </CardBody>
        </Card>
        <Card minH="83px">
          <CardBody>
            <Flex flexDirection="row" align="center" justify="center" w="100%">
              <Stat me="auto">
                <StatLabel
                  fontSize="sm"
                  color={textColor}
                  fontWeight="bold"
                  pb=".1rem"
                >
                  Total Sales
                </StatLabel>
                <Flex>
                  <StatNumber fontSize="lg" color={textColor} fontWeight="bold">
                    ${loader ? " Loding..." : salereports.totalSale}

                  </StatNumber>

                </Flex>
              </Stat>
              <IconBox as="box" h={"45px"} w={"45px"} bg="blue.200">
                <AttachMoney h={"24px"} w={"24px"} color={iconBoxInside} style={{ color: "white" }} />
              </IconBox>
            </Flex>
          </CardBody>
        </Card>
      </SimpleGrid>
      <Grid
        templateColumns={{ sm: "1fr", lg: "1.5fr 1.5fr" }}
        templateRows={{ sm: "repeat(2, 1fr)", lg: "1fr" }}
        gap="24px"
        mb={{ lg: "26px" }}
        mt={{ lg: "26px", base: "20px" }}
      >
        <Card p="16px">
          <CardHeader mb="20px" pl="22px">
            <Flex direction="column" alignSelf="flex-start">
              <Text fontSize="lg" color={textColor} fontWeight="bold" mb="6px">
                User Report
              </Text>
              <Text fontSize="md" fontWeight="medium" color={textColor}>
                <Text as="span" color="green" fontWeight="bold">
                  (+ { Math.ceil( Math.abs(userreports.yearlyUser.uptolastyearusercount /  userreports.yearlyUser.count)*100)}%) more
                </Text>{" "}
                in {now.getFullYear()}
              </Text>
            </Flex>
          </CardHeader>
          <CardBody>
            <Flex direction="column" w="100%">
              <LineChart xaxies={userreports.daytodayUser.xaxies} yaxies={userreports.daytodayUser.yaxies} title={`Current Month User Report (${new Date().toLocaleDateString('default',{month: 'long'})})`} width="440" />
            </Flex>
          </CardBody>
        </Card>
        <Card p="28px 10px 16px 0px" mb={{ sm: "26px", lg: "0px" }}>
          <CardHeader mb="20px" pl="22px">
            <Flex direction="column" alignSelf="flex-start">
              <Text fontSize="lg" color={textColor} fontWeight="bold" mb="6px">
                Sales Overview
              </Text>
              <Text fontSize="md" fontWeight="medium" color={textColor}>
                <Text as="span" color="green" fontWeight="bold">
                  (+ { Math.ceil(Math.abs(salereports.yearlySale.uptolastyearssale /  salereports.yearlySale.total)*100)}%) more
                </Text>{" "}
                in {now.getFullYear()}
              </Text>
            </Flex>
          </CardHeader>
          <Box w="100%" h={{ sm: "300px" }} ps="8px">
            <LineChart xaxies={salereports.daytodaySale.xaxies} yaxies={salereports.daytodaySale.yaxies} title={`Sale Report (${new Date().toLocaleDateString('default',{month: 'long'})})`} height={"300"} width="400" />
          </Box>
        </Card>
      </Grid>

    </Flex>
  );
}
