import React, { useState } from 'react';
import {
    Flex,
    Grid,


}
    from '@chakra-ui/react';
const TodayDomains = (prop) => {
    return (
        <Flex flexDirection="column" pt={{ base: "120px", md: "75px" }}>
            <Grid
                templateColumns={{ sm: "1fr", lg: "1fr" }}
                templateRows={{ sm: "repeat(2, 1fr)", lg: "1fr" }}
                gap="24px"
                mb={{ lg: "26px" }}
                mt={{ lg: "26px", base: "20px" }}
            >
                Today Domains
            </Grid>
        </Flex>
    )
}

export default TodayDomains;