import {
    Box,
    Flex,
    Grid,
    Text,
    FormControl,
    Input,
    Modal,
    Select,
    Avatar,
    Wrap,
    WrapItem,
    useDisclosure,
    Spacer,
    Button,
    ModalContent,
    ModalCloseButton,
    ModalBody,
    InputGroup,
    InputLeftElement,
    ModalHeader,
    ModalOverlay,
    ModalFooter,
    FormLabel,
    Tooltip,
    Center,
    useColorModeValue,
} from "@chakra-ui/react";
import moment from 'moment';

import { useSelector } from "react-redux";
import {getuserDomainPagination} from '../../store/actions/user';
import { Table, Thead, Tbody, Tr, Th, Td, chakra } from '@chakra-ui/react'
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import React ,{useState, useEffect} from 'react';
import Card from "components/Card/Card.js";
import {useToast} from '@chakra-ui/toast';
import {useDispatch} from 'react-redux';
const UserDomains = (props) => {
    const loader = useSelector(state => state.loaderReducer.loader);
    const dispatch = useDispatch();
    const toast  = useToast();
    const textColor = useColorModeValue("black", "white");
    const userdomains = useSelector(state => state.userdomainReducer);
    
    const [page, setpage] = useState(1);
    const _id  = props.match.params.id;
        
    function getpreviouspage(){
        dispatch( getuserDomainPagination({page : page+1, limit: 10,_id : _id}, toast));
        setpage(page+1);
    }
    
    function getnextpage(){
        dispatch( getuserDomainPagination({page : page-1, limit: 10,_id : _id}, toast));
        setpage(page-1);
    }
    useEffect(()=>{
        dispatch( getuserDomainPagination({page : page, limit: 10,_id : _id}, toast));

    }, [])

    return (
        <Flex direction="column" pt={{ base: "120px", md: "75px" }}>
            <Card overflowX={{ sm: "scroll", xl: "hidden" }}>
                    <Text fontSize="xl" color={textColor} fontWeight="bold">
                        User Domains
                    </Text>
                <Flex mt="20px" mb="20px">
                        <Table variant='simple' mt={"1"} >
                            <Thead>
                                <Tr style={{ textTransform: "none" }}>
                                

                                    <Th>DOMAIN NAME</Th> 
                                    <Th> DNS</Th>    
                                    <Th> Type  </Th> 
                                    <Th> DEPLOYED ON CHAIN</Th>
                                    <Th> PURCHASE DATE</Th>
                                                           
                                </Tr>
                            </Thead>
                            <Tbody>
                                {(loader == false &&  (userdomains && (userdomains.domains.length || userdomains.domains.length === 0))) ?
                                    userdomains.domains.map((row, index) => (
                                        <>
                                            <Tr key={index}>
                                             <Td>{row.domainName}</Td>
                                             <Td> {row.dns}</Td>
                                             <Td>{row.type}</Td>
                                             <Td>{row.deployedOnChain? "YES": "NO" }</Td>
                                             <Td> {moment(row.purchaseDate).format("YYYY-MM-DD")}</Td>
                                            </Tr>

                                        </>


                                    )) : <Flex >
                                        <Center>
                                            Loading.....
                                        </Center>
                                    </Flex>}

                            </Tbody>

                        </Table>

                    </Flex>

                    <Flex>
                        <Spacer></Spacer>
                        <Flex>
                            <Box rounded="md">
                                <Button
                                    fontSize="15px"
                                    bg="blue.200"
                                    w="100%"
                                    h="45"
                                    mb="20px"
                                    color="white"
                                    mt="20px"
                                    isDisabled={userdomains.isfirstpage}
                                    onClick={getpreviouspage}
                                    _hover={{
                                        bg: "blue",
                                    }}
                                    _active={{
                                        bg: "#5b35f9",
                                    }}
                                    colorScheme='blue' mr={3} >
                                    <ChevronLeftIcon style={{ color: "white" }}></ChevronLeftIcon>

                                </Button>


                            </Box>
                            <Box rounded="md">
                                <Button
                                    isDisabled={userdomains.islastpage}
                                    fontSize="15px"
                                    bg="blue.200"
                                    w="100%"
                                    h="45"
                                    mb="20px"
                                    color="white"
                                    mt="20px"
                                    onClick={getnextpage}
                                    _hover={{
                                        bg: "blue",
                                    }}
                                    _active={{
                                        bg: "#5b35f9",
                                    }}
                                    colorScheme='blue' mr={3} >
                                    <ChevronRightIcon style={{ color: "white" }}  ></ChevronRightIcon>
                                </Button>
                            </Box>
                        </Flex>

                    </Flex>
                
            </Card>
        </Flex>

    )
}


export default UserDomains;
