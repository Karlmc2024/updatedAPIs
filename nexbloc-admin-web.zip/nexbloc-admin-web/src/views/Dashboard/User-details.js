
import {
    Box,
    Flex,
    Grid,
    Text,
    FormControl,
    Input,
    Modal,
    Select,
    Avatar,
    Wrap,
    WrapItem,
    useDisclosure,
    Spacer,
    Button,
    ModalContent,
    ModalCloseButton,
    ModalBody,
    InputGroup,
    InputLeftElement,
    ModalHeader,
    ModalOverlay,
    ModalFooter,
    FormLabel,
    Tooltip,
    Center,
    useColorModeValue,
} from "@chakra-ui/react";
import moment from 'moment';

import { useSelector } from "react-redux";
import { getuserDomainPagination } from '../../store/actions/user';
import { Table, Thead, Tbody, Tr, Th, Td, chakra } from '@chakra-ui/react'
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import React, { useState, useEffect } from 'react';
import Card from "components/Card/Card.js";
import { useToast } from '@chakra-ui/toast';
import { useDispatch } from 'react-redux';
const UserDomains = (props) => {
    const loader = useSelector(state => state.loaderReducer.loader);
    const dispatch = useDispatch();
    const toast = useToast();
    const textColor = useColorModeValue("black", "white");
    const userdomains = useSelector(state => state.userdomainReducer);
    
    const [page, setpage] = useState(1);
    const _id = props.match.params.id;

    function getpreviouspage() {
        dispatch(getuserDomainPagination({ page: page + 1, limit: 10, _id: _id }, toast));
        setpage(page + 1);
    }

    function getnextpage() {
        dispatch(getuserDomainPagination({ page: page - 1, limit: 10, _id: _id }, toast));
        setpage(page - 1);
    }
    useEffect(() => {
        dispatch(getuserDomainPagination({ page: page, limit: 10, _id: _id }, toast));

    }, [])

    return (
        <Flex direction="column" pt={{ base: "120px", md: "75px" }}>
            <Card overflowX={{ sm: "scroll", xl: "hidden" }}>
                <Text fontSize="xl" color={textColor} fontWeight="bold">
                    User Detail
                </Text>
                <Flex justify="center" align="center">
                    <Wrap>
                        <WrapItem>
                            <Avatar size='2xl' cursor={"pointer"} name='my avatar' src={avatar} />
                        </WrapItem>
                    </Wrap>

                </Flex>

            </Card>
        </Flex>

    )
}


export default UserDomains;
