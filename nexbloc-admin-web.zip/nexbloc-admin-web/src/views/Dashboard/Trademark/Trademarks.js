import {
    Flex,
    Grid,
    Text,
    FormControl,
    Input,
    Select,
    Avatar,
    Wrap,
    WrapItem,
    useDisclosure,
    Spacer,
    Button,
    ModalContent,
    ModalCloseButton,
    Center,
    ModalBody,
    InputGroup,
    InputLeftElement,
    ModalHeader,
    ModalOverlay,
    ModalFooter,
    FormLabel,
    Tooltip,
    Box,
    useColorModeValue,
} from "@chakra-ui/react";
import Card from "components/Card/Card";
import { Table, Thead, Tbody, Tr, Th, Td, chakra } from '@chakra-ui/react'
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import { Search } from "@material-ui/icons";
import { ExternalLinkIcon } from '@chakra-ui/icons';
import { Link } from 'react-router-dom';
import { useToast } from '@chakra-ui/toast';

import React, { useCallback, useState, useEffect } from 'react';
import { useSelector, useDispatch } from "react-redux";
import { getTrademark, downloadTrademark, searchTrademark } from '../../../store/actions/trademark';
import DownloadButton from "views/Common/DownloadButton";
import moment from 'moment'
const Trademarks = () => {
    const textColor = useColorModeValue("black", "white");

    const toast = useToast();

    const dispatch = useDispatch();
    const [page, setpage] = useState(1);
    const today = moment().format("YYYY-MM-DD");
    const loader = useSelector(state => state.loaderReducer.loader);
    
    const start = moment().subtract(1, "month").format("YYYY-MM-DD");
    const [pagedata, setpagedata] = useState({ start: start, end: today, filetype: "xls", ischanged: false })
    const fileloader = useSelector(state => state.fileloaderReducer.loader);
    const data = useSelector(state => state.trademarkReducer);
    console.log("trademark data ", data);
    function handeldownload() {
     
        dispatch(downloadTrademark({ ...pagedata }, toast));   
    }
    function changepagedata(e) {
        const name = e.target.name;
        setpagedata({ ...pagedata, [e.target.name]: e.target.value, ischanged: true });
        if (name == "start" || name == "end") {
            dispatch(getTrademark({ page: page, limit: 10, start: pagedata.start, end: pagedata.end }, toast));
        }
    }

    useEffect(() => {
        dispatch(getTrademark({ page: page, limit: 10, start: pagedata.start, end: pagedata.end }, toast));
    }, [])

    return (
        <React.Fragment>
            <Text
                fontSize="3xl"
                color={textColor}
                fontWeight="bold"
            >
                Trademarks
            </Text>
            <Flex>
                <Box mt="20px" mb="20px">
                    <Flex>
                        <Box>
                            <FormControl >
                                <FormLabel htmlFor='start'>From <span>(MM/DD/YYYY)</span></FormLabel>
                                <Input type="date" name="start" onChange={changepagedata} value={pagedata.start} w={"90%"} />
                            </FormControl>
                        </Box>
                        <Box>
                            <FormControl>
                                <FormLabel htmlFor='end'>To <span>(MM/DD/YYYY)</span></FormLabel>
                                <Input type="date" name="end" onChange={changepagedata} value={pagedata.end} w="90%" />
                            </FormControl>
                        </Box>
                    </Flex>

                </Box>
                <Box mt="20px" mb="20px">
                    <Flex>
                        <Box>
                            <FormControl>
                                <FormLabel htmlFor='email'>Select file type</FormLabel>
                                <Select placeholder='Select file type' name="filetype" onChange={changepagedata} w={"80%"}>
                                    <option value="xls" selected={true}>.xls</option>
                                    <option value="csv">.csv</option>
                                </Select>
                            </FormControl>
                        </Box>
                        <Box>
                            <DownloadButton fileloader={fileloader} handeldownload={handeldownload}/>

                        </Box>
                    </Flex>
                </Box>
            </Flex>
            <Flex mt="20px" mb="20px" width={"850px"} >
                <Table variant='simple' mt={"1"} overflow="scroll" scrollBehavior={"scroll"} whiteSpace="unset" >
                    <Thead>
                        <Tr style={{ textTransform: "none" }}>
                            <Th>Trademark Name</Th>
                            <Th>SerchCount</Th>
                        </Tr>
                       </Thead>
                       <Tbody>
                        {(  data && (data.rows && (data.rows.length || data.rows.length === 0))) ?
                            data.rows.map((row, index) => (
                                <>

                                    <Tr key={index}>
                                        <Td> {row.tradeMarkName}</Td>
                                        <Td> {row.searchCount}</Td>
                            
                                    </Tr>
                                </>
                            )) : <Flex >
                                <Center>
                                    Loading.....
                                </Center>
                            </Flex>}
                    </Tbody>
                
                </Table>
                    
            </Flex>

        </React.Fragment>

    )
}

export default Trademarks;
