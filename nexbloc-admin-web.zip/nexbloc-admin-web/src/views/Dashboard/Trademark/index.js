import React from 'react';
import { Tabs, TabList, TabPanels, Tab, TabPanel, Flex, Grid } from '@chakra-ui/react'
import Card from '../../../components/Card/Card';
import Trademarks from './Trademarks';
import TrademarkRequests from './TrademarkRequests';

const TrademarkIndex = (props) => {
    return (
        <Flex flexDirection="column" pt={{ base: "120px", md: "75px" }}>
            <Grid
                templateColumns={{ sm: "1fr", lg: "1fr" }}
                templateRows={{ sm: "repeat(2, 1fr)", lg: "1fr" }}
                gap="24px"
                mb={{ lg: "26px" }}
                mt={{ lg: "26px", base: "20px" }}
            >
                <Card>

                    <Tabs>
                        <TabList>
                            <Tab w={"50%"} color={"brand"}>Trademarks</Tab>
                            <Tab w={"50%"}>Trademark Requests</Tab>
                        </TabList>
                        <TabPanels>
                            <TabPanel>
                                <Trademarks />
                            </TabPanel>
                            <TabPanel>
                                <TrademarkRequests />
                            </TabPanel>
                        </TabPanels>
                    </Tabs>
                </Card>
            </Grid>
        </Flex>
    )
}
export default TrademarkIndex;
