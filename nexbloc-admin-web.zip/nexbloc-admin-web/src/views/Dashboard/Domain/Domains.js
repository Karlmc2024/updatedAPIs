import {
    Box,
    Flex,
    Grid,
    Text,
    FormControl,
    Input,
    Modal,
    Select,
    Avatar,
    Wrap,
    WrapItem,
    useDisclosure,
    Spacer,
    Button,
    ModalContent,
    ModalCloseButton,
    Center,
    ModalBody,
    InputGroup,
    InputLeftElement,
    ModalHeader,
    ModalOverlay,
    ModalFooter,
    FormLabel,
    Tooltip,
    useColorModeValue,
} from "@chakra-ui/react";
import { Table, Thead, Tbody, Tr, Th, Td, chakra } from '@chakra-ui/react'
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import { Search } from "@material-ui/icons";
import { ExternalLinkIcon } from '@chakra-ui/icons';
import { Link } from 'react-router-dom';
import Card from "components/Card/Card.js";
import { useToast } from '@chakra-ui/toast';
import React, { useCallback, useState, useEffect } from 'react';
import { useSelector, useDispatch } from "react-redux";
import { getAllDomainPagination, searchDomain, downloadDomains } from '../../../store/actions/domain';
import moment from 'moment';
import DownloadButton  from 'views/Common/DownloadButton';

export default function Domains(props) {

    const toast = useToast();
    const loader = useSelector(state => state.loaderReducer.loader);
    const dispatch = useDispatch();
    const today = moment().format("YYYY-MM-DD");
    const start = moment().subtract(1, "month").format("YYYY-MM-DD");
    const [pagedata, setpagedata] = useState({ start: start, end: today, filetype: "xls", ischanged: false })
    const textColor = useColorModeValue("black", "white");
    const domaindata = useSelector(state => state.domainReducer);

    const [page, setpage] = useState(1);
    const fileloader = useSelector(state => state.fileloaderReducer.loader);
    // change page data 

    function changepagedata(e) {
        const name = e.target.name;
        setpagedata({ ...pagedata, [e.target.name]: e.target.value, ischanged: true });
        if (name == "start" || name == "end") {
            dispatch(getAllDomainPagination({ page: page, limit: 10, start: pagedata.start, end: pagedata.end }, toast));
        }


    }
    function handeldownload(e) {
        dispatch(downloadDomains({ ...pagedata }, toast));
    }

    // get next page
    function getnextpage() {
        dispatch(getAllDomainPagination({ page: page + 1, limit: 10, start: pagedata.start, end: pagedata.end }, toast));
        setpage(page + 1);
    }

    // get previous page
    function getpreviouspage() {
        dispatch(getAllDomainPagination({ page: page - 1, limit: 10, start: pagedata.start, end: pagedata.end }, toast));
        setpage(page - 1);
    }
    // change handler 
    async function changeHandler(e) {
        const domainName = e.target.value;
        if (domainName == "") {
            // get first page domain
            dispatch(getAllDomainPagination({ page: page, limit: 10, start: pagedata.start, end: pagedata.end }, toast));
        }
        else {
            // search domain
            dispatch(searchDomain({ domainName }, toast));

        }
    }

    function debounce(fn, d) {
        let timer;
        return function (...args) {
            const context = this;
            if (timer) clearTimeout(timer);
            timer = setTimeout(() => {
                fn.apply(context, args)
            }, d)
        }
    }
    const searchmyDomain = useCallback(debounce(changeHandler, 500), []);
    useEffect(() => {
        dispatch(getAllDomainPagination({ page: page, limit: 10, start: pagedata.start, end: pagedata.end }, toast));
    }, [])
    const done = () => {

    }
    const columns = [
            {
              Header: "Domain Name",
              accessor: "domainName"
            },
            {
              Header: "DNS",
              accessor: "dns"
            }
       ,
            {
              Header: "Type",
              accessor: "type"
            },
            {
              Header: "dns",
              accessor: "visits"
            },
            {
              Header: "Actions",
              accessor: "_id",
              Cell: props =>{
                  return (
                    <Link to={`/admin/domain-detail/${props.value}`}>
                    View details <ExternalLinkIcon mx='2px' />
                </Link>
                  )
              }
            }
      ]

    return (
        <React.Fragment>
            <Flex>
                <Box mt="20px" mb="20px">
                    <Flex>
                        <Box>
                            <FormControl >
                                <FormLabel htmlFor='start'>From <span>(MM/DD/YYYY)</span></FormLabel>
                                <Input type="date" name="start" onChange={changepagedata} value={pagedata.start} w={"90%"} />
                            </FormControl>
                        </Box>
                        <Box>
                            <FormControl>
                                <FormLabel htmlFor='end'>To <span>(MM/DD/YYYY)</span></FormLabel>
                                <Input type="date" name="end" onChange={changepagedata} value={pagedata.end} w="90%" />
                            </FormControl>
                        </Box>
                    </Flex>

                </Box>
                <Box mt="20px" mb="20px">
                    <Flex>
                        <Box>
                            <FormControl>
                                <FormLabel htmlFor='email'>Select file type</FormLabel>
                                <Select placeholder='Select file type' name="filetype" onChange={changepagedata} w={"80%"}>
                                    <option value="xls" selected={true}>.xls</option>
                                    <option value="csv">.csv</option>
                                </Select>
                            </FormControl>
                        </Box>
                        <Box>
                        <DownloadButton fileloader={fileloader } handeldownload={handeldownload}/>

                        </Box>
                    </Flex>
                </Box>
            </Flex>
            <Flex>
                <FormControl w={"80%"} >
                    <FormLabel>Search domain</FormLabel>
                    <InputGroup>
                        <InputLeftElement
                            pointerEvents='none'
                            mb={"60px"}

                            children={<Search color='gray.300' />}
                        />
                        <Input type='text' borderRadius="15px"
                            bg="white"
                            name="text"
                            onChange={searchmyDomain}
                            focusBorderColor='blue.100' placeholder='Enter domain name'
                        />
                    </InputGroup>
                </FormControl>
            </Flex>

            <Flex mt="20px" mb="20px">
                <Table variant='simple' mt={"1"} >
                    <Thead>

                        <Tr style={{ textTransform: "none" }}>
                            <Th>DOMAIN NAME</Th>

                            <Th>DNS</Th>
                            <Th>DOMAIN TYPE</Th>
                            <Th>Actions</Th>
                        </Tr>
                    </Thead>
                    <Tbody>
                        {(loader == false && domaindata && (domaindata.domains && (domaindata.domains.length || domaindata.domains.length === 0))) ?
                            domaindata.domains.map((row, index) => (
                                <>

                                    <Tr key={index}>

                                        <Td> {row.domainName}</Td>

                                        <Td> {row.dns}</Td>
                                        <Td>{row.type}</Td>

                                        <Td><Link to={`/admin/domain-detail/${row._id}`}>
                                            View details <ExternalLinkIcon mx='2px' />
                                        </Link></Td>
                                    </Tr>

                                </>


                            )) : <Flex >
                                <Center>
                                    Loading.....
                                </Center>
                            </Flex>}

                    </Tbody>

                </Table>

            </Flex>

            <Flex>
                <Spacer></Spacer>
                <Flex>
                    <Box m ={"20px"} rounded="md">
                        <Button
                            fontSize="15px"
                            bg="blue.200"
                            w="100%"
                            h="45"
                            borderRadius={"5px"}
                            mb="20px"
                            color="white"
                            mt="20px"
                            isDisabled={domaindata.isfirstpage}
                            onClick={getpreviouspage}
                            _hover={{
                                bg: "blue",
                            }}
                            _active={{
                                bg: "#5b35f9",
                            }}
                            colorScheme='blue' mr={3} >
                            <ChevronLeftIcon style={{ color: "white" }}></ChevronLeftIcon>

                        </Button>


                    </Box>
                    <Box m={"20px"} rounded="md">
                        <Button
                            isDisabled={domaindata.islastpage}
                            fontSize="15px"
                            bg="blue.200"
                            w="100%"
                            borderRadius={"5px"}
                            h="45"
                            mb="20px"
                            color="white"
                            mt="20px"
                            onClick={getnextpage}
                            _hover={{
                                bg: "blue",
                            }}
                            _active={{
                                bg: "#5b35f9",
                            }}
                            colorScheme='blue' mr={3} >
                            <ChevronRightIcon style={{ color: "white" }} ></ChevronRightIcon>
                        </Button>
                    </Box>
                </Flex>

            </Flex>
        </React.Fragment>
    )
}


