import {
    Box,
    Flex,
    Grid,
    Text,
    FormControl,
    Input,
    Modal,
    Select,
    Avatar,
    Wrap,
    WrapItem,
    useDisclosure,
    Spacer,
    Button,
    ModalContent,
    ModalCloseButton,
    ModalBody,
    InputGroup,
    InputLeftElement,
    ModalHeader,
    ModalOverlay,
    ModalFooter,
    FormLabel,
    Tooltip,
    Center,
    useColorModeValue,
} from "@chakra-ui/react";
import moment from 'moment';
import { Table, Thead, Tbody, Tr, Th, Td, chakra } from '@chakra-ui/react'

import { useSelector } from "react-redux";
import React, { useState, useEffect } from 'react';
import Card from "components/Card/Card.js";
import { useToast } from '@chakra-ui/toast';
import { useDispatch } from 'react-redux';
import { getDomainDetail } from '../../store/actions/domain';
const DomainDetails = (props) => {
    const loader = useSelector(state => state.loaderReducer.loader);
    const domain = useSelector(state => state.domainReducer.curdomain);
    
    const dispatch = useDispatch();
    const toast = useToast();
    const textColor = useColorModeValue("black", "white");



    useEffect(() => {
        const _id = props.match.params._id;
        dispatch(getDomainDetail(_id, toast));

    }, [])

    return (
        <Flex direction="column" pt={{ base: "120px", md: "75px" }}>
            <Card overflowX={{ sm: "scroll", xl: "hidden" }}>
                <Text fontSize="xl" color={textColor} fontWeight="bold">
                    Domain Details
                </Text>
                <Flex mt="20px" mb="20px">
                    {
                        loader ? "Loading...." : (
                            <Box>
                                <Text fontWeight={"bold"} mt={"50px"}>
                                    Domain Detail
                                </Text>
                                <Table variant='simple' mt={"1"} >
                                    {loader == false ?

                                        <Tbody>
                                            <Tr>
                                                <Td>Domain Name  </Td>
                                                <Td>{domain.domainName} </Td>
                                            </Tr>
                                            <Tr>
                                                <Td>Type </Td>
                                                <Td> {domain.type}</Td>
                                            </Tr>

                                            <Tr>
                                                <Td> DNS </Td>
                                                <Td>{domain.dns}</Td>

                                            </Tr>
                                            <Tr>
                                                <Td> Deployed on chain  </Td>
                                                <Td>{domain.deployedOnChain ? "Yes" : "No"} </Td>

                                            </Tr>

                                            <Tr>
                                                <Td>Purchase Date (YYYY-MM-DD)</Td>
                                                <Td> {moment(domain.purchaseDate).format("YYYY-MM-DD")}</Td>
                                            </Tr>


                                        </Tbody>
                                        :
                                        <Flex >
                                            <Center>
                                                Loading.....
                                            </Center>
                                        </Flex>}


                                </Table>




                                <Text fontWeight={ "bold"} mt={"40px"}>
                                    User Detail
                                </Text>
                                <Table variant='simple' mt={"1"} >
                                    {loader == false   && domain.user && domain.user.length !=0 ?

                                        <Tbody>
                                            <Tr>
                                                <Td>First Name   </Td>
                                                <Td>{domain.user[0].firstName} </Td>
                                            </Tr>
                                            <Tr>
                                                <Td>Last Name </Td>
                                                <Td> {domain.user[0].lastName}</Td>
                                            </Tr>

                                            <Tr>
                                                <Td> Email </Td>
                                                <Td>{domain.user[0].email}</Td>

                                            </Tr>
                                            <Tr>
                                                <Td> Phone no  </Td>
                                                <Td>{domain.user[0].phone} </Td>

                                            </Tr>



                                        </Tbody>
                                        :
                                        <Flex >
                                            <Center>
                                                Loading.....
                                            </Center>
                                        </Flex>}


                                </Table>


                            </Box>

                        )
                    }

                </Flex>

            </Card>
        </Flex>

    )
}


export default DomainDetails;
