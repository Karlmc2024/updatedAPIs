// Chakra imports
import {
    Box,
    Flex,
    Grid,
    Text,
    FormControl,
    Input,
    Modal,
    Avatar,
    Wrap,
    WrapItem,
    useDisclosure,
    Spacer,
    Button,
    ModalContent,
    ModalCloseButton,
    ModalBody,
    InputGroup,
    InputLeftElement,
    ModalHeader,
    ModalOverlay,
    ModalFooter,
    FormLabel,
    Tooltip,
    useColorModeValue,
} from "@chakra-ui/react";
// Custom components
import { Table, Thead, Tbody, Tr, Th, Td, chakra } from '@chakra-ui/react'
import Card from "components/Card/Card.js";
import { Search, Block } from "@material-ui/icons";
import ChevronLeftIcon from '@material-ui/icons/ChevronLeft';
import ChevronRightIcon from '@material-ui/icons/ChevronRight';
import { useToast } from '@chakra-ui/toast';
import React, { useState, useEffect, useCallback } from "react";
// react icons
import { useDispatch, useSelector } from 'react-redux';
import BlockIcon from '@material-ui/icons/Block';
import CheckCircleOutlineIcon from '@material-ui/icons/Restore';
import { getAdmins, BlockAdmin, unBlockAdmin, addAdmin, searchAdmin } from '../../store/actions/admin';
import avatar from '../../assets/img/avatars/avatar.jpg'
export default function Admins() {
    const { isOpen, onOpen, onClose } = useDisclosure();
    const { isOpen: isblockmodel, onOpen: openblockmodel, onClose: closeblockmodel } = useDisclosure();
    const { isOpen: isunblockmodel, onOpen: opneunblockmodel, onClose: closeunblockmodel } = useDisclosure();
    const admins = useSelector(state => state.adminReducer);
    const [email, setemail] = useState("");
    const [page, setpage] = useState(1);
    const toast = useToast();
    const textColor = useColorModeValue("black", "white");
    const dispatch = useDispatch();
    const loader = useSelector(state => state.loaderReducer.loader);
    const [toggleblock, settoggleblock] = useState(false);
    const [curid, setcurid] = useState(null);
    useEffect(() => {
        dispatch(getAdmins(1, 10, toast));
    }, [])
    // pagination  to get next page
    function getnextpage() {
        dispatch(getAdmins(page + 1, 10, toast));
        setpage(page + 1);
    }
    // pagination to get previous page
    function getprevouspage() {
        dispatch(getAdmins(page - 1, 10, toast));
        setpage(page - 1);
    }

    function changeemail(e) {
        setemail(e.target.value);
    }

    function handelopenBlockModel(id) {
        openblockmodel();
        setcurid(id);
    }
    function handelCloseBlockModel() {
        closeblockmodel();
        setcurid(null);
    }
    function handelCloseUnBlockModel() {
        closeunblockmodel();
        setcurid(null);

    }
    function handelOpenUnBlockModel(id) {
        if (id != null) {
            opneunblockmodel();
            setcurid(id);
        }

    }


    async function changeHandler(e) {
        const first_name = e.target.value;
        if (first_name == "") {
            // get first page admins 
            dispatch(getAdmins(1, 10, toast));
        }
        else {
            // search donor 
            dispatch(searchAdmin(first_name, toast));
        }
    }
    // if the text difference between two clicks are more than  500 then it will execute
    function debounce(fn, d) {
        let timer;
        return function (...args) {
            const context = this;
            if (timer) clearTimeout(timer);
            timer = setTimeout(() => {
                fn.apply(context, args)
            }, d)
        }
    }
    const searchAdmins = useCallback(debounce(changeHandler, 500), []);

    // Add admin sumbit handler 
    const onSubmit = async (e) => {
        e.preventDefault();
        const done = dispatch(addAdmin({ email }, toast));
        if (done) {
            onClose();
        }
    }

    // block secondary admin
    const blockAdmin = async () => {
        const id = curid;
        const done = dispatch(BlockAdmin(id, toast));
        if (done) {
            closeblockmodel();
        }
    }


    // unblock secondary admin
    const unblockAdmin = async () => {
        const id = curid;
        const done = dispatch(unBlockAdmin(id, toast));
        if (done) {
            closeunblockmodel();
        }
    }

    return (
        <Flex flexDirection="column" pt={{ base: "120px", md: "75px" }}>


            <Grid
                templateColumns={{ sm: "1fr", lg: "1fr" }}
                templateRows={{ sm: "repeat(2, 1fr)", lg: "1fr" }}
                gap="24px"
                mb={{ lg: "26px" }}
                mt={{ lg: "26px", base: "20px" }}
            >
                <Card>
                    <Flex>
                        <Box p='4'>

                            <Modal isOpen={isunblockmodel} color={textColor} onClose={closeunblockmodel}>
                                <ModalOverlay />
                                <ModalContent>
                                    <ModalHeader>Unblock Admin</ModalHeader>
                                    <ModalCloseButton />
                                    <ModalBody>
                                        <Text>Are you sure Unblok admin</Text>
                                    </ModalBody>

                                    <ModalFooter>
                                        <Button
                                            fontSize="15px"
                                            bg="blue.200"
                                            w="100%"
                                            h="45"
                                            mt="20px"
                                            mb="20px"
                                             border={"1px solid blue"}
                                              mr={3} onClick={handelCloseUnBlockModel}>
                                            Close
                                        </Button>
                                        <Button
                                            isLoading={loader}
                                            loadingText='Unblocking...'
                                            fontSize="15px"
                                            onClick={() => unblockAdmin(curid)}
                                            bg="blue.200"
                                            w="100%"
                                            h="45"
                                            mb="20px"
                                            color="white"

                                            mt="20px"
                                            _hover={{
                                                bg: "blue",
                                            }}
                                            _active={{
                                                bg: "#5b35f9",
                                            }}
                                        >
                                            Unblock
                                        </Button>

                                    </ModalFooter>
                                </ModalContent>
                            </Modal>
                            <Modal isOpen={isblockmodel} color={textColor} onClose={handelCloseBlockModel}>
                                <ModalOverlay />
                                <ModalContent>
                                    <ModalHeader>Block Admin</ModalHeader>
                                    <ModalCloseButton />
                                    <ModalBody>
                                        <Text>please sure want to Block admin</Text>
                                    </ModalBody>

                                    <ModalFooter>
                                        <Button
                                            fontSize="15px"
                                            w="100%"
                                            h="45"
                                            mt={"20px"}
                                            mb="20px"
                                           varient="outline"
                                           border={"1px solid blue"}
                                            onClick={handelCloseBlockModel}>
                                            Close
                                        </Button>
                                        <Button
                                            isLoading={loader}
                                            loadingText='Bloking...'
                                            type="submit"
                                            fontSize="15px"
                                            bg="blue.200"
                                            w="100%"
                                            h="45"
                                            mb="20px"
                                            color="white"
                                            onClick={() => blockAdmin(curid)}
                                            mt="20px"
                                            _hover={{
                                                bg: "blue",
                                            }}
                                            _active={{
                                                bg: "#5b35f9",
                                            }}
                                        >
                                            Block
                                        </Button>

                                    </ModalFooter>
                                </ModalContent>
                            </Modal>
                            <Text
                                fontSize="3xl"
                                color={textColor}
                                fontWeight="bold"

                            >
                                All Admins
                            </Text>

                        </Box>
                        <Spacer />



                        <Box p='4' bg='white'>
                            <Button onClick={onOpen} fontSize="15px"
                                bg="blue.200"
                                w="100%"
                                h="45"
                                mb="10px"
                                color="white"
                                _hover={{
                                    bg: "blue",
                                }}
                                _active={{
                                    bg: "#5b35f9",
                                }}>Add Admin</Button>

                            <Modal isOpen={isOpen} color={textColor} onClose={onClose}>
                                <ModalOverlay />
                                <ModalContent>
                                    <ModalHeader>Add Admin</ModalHeader>
                                    <ModalCloseButton />
                                    <ModalBody>
                                        <FormControl>
                                            <FormLabel ms="4px" fontSize="sm" fontWeight="normal" color={"black"}>
                                                Email <span style={{ color: "red" }}>*</span>
                                            </FormLabel>
                                            <Input
                                                isRequired
                                                borderRadius="15px"
                                                mb="24px"
                                                name="email"
                                                value={email}
                                                fontSize="sm"
                                                type="email"
                                                onChange={changeemail}
                                                placeholder="test@gmail.com"
                                                size="lg"
                                                bg="white"
                                                focusBorderColor='blue.100'

                                            />

                                        </FormControl>
                                    </ModalBody>

                                    <ModalFooter>
                                        <Button
                                            fontSize="15px"
                                            mt="20px"
                                            bg={"transparent"}
                                            w="100%"
                                            h="45"
                                            mb="20px"
                                            border={"1px solid blue"}
                                             mr={3} onClick={onClose}>
                                            Close
                                        </Button>
                                        <Button
                                            isLoading={loader}
                                            loadingText='adding...'
                                            type="submit"
                                            fontSize="15px"
                                            bg="blue.200"
                                            w="100%"
                                            h="45"
                                            mb="20px"
                                            color="white"
                                            onClick={onSubmit}
                                            mt="20px"
                                            _hover={{
                                                bg: "blue",
                                            }}
                                            _active={{
                                                bg: "#5b35f9",
                                            }}
                                        >
                                            Add Admin
                                        </Button>

                                    </ModalFooter>
                                </ModalContent>
                            </Modal>
                        </Box>
                    </Flex>
                    <Card w="80%">
                        <Text
                            color={textColor}
                        >
                            Search admin
                        </Text>
                        <InputGroup>
                            <InputLeftElement
                                pointerEvents='none'
                                mb={"60px"}
                                children={<Search color='gray.300' />}
                            />


                            <Input type='text' borderRadius="15px"
                                bg="white"
                                name="text"
                                onChange={searchAdmins}
                                focusBorderColor='blue.100' placeholder='Enter first name '
                            />
                        </InputGroup>
                    </Card>
                    <Card w="100%">

                        <Table variant='simple' mt={"1"} >
                            <Thead>
                                <Tr style={{ textTransform: "none" }}>
                                    <Th>Profile </Th>
                                    <Th>Email</Th>
                                    <Th>First Name </Th>
                                    <Th>Last Name</Th>
                                    <Th>Actions</Th>
                                </Tr>
                            </Thead>
                            <Tbody >
                                {(admins && (admins.rows && (admins.rows.length || admins.rows.length === 0))) ?
                                    admins.rows.map((row, index) => (

                                        <Tr key={row._id}>

                                            <Td>{row.image == null ? <Wrap>

                                                <WrapItem>
                                                    <Avatar name='Dan Abrahmov' src={avatar} />
                                                </WrapItem></Wrap> : null}</Td>
                                            <Td> {row.email}</Td>
                                            <Td> {row.first_name}</Td>
                                            <Td>{row.last_name}</Td>
                                            <Td>{row.isactive == false ?
                                                (<Box bg='white'>
                                                    <Tooltip label='Unblock admin' bg='black' style={{ color: "white" }}>
                                                        <CheckCircleOutlineIcon onClick={() => handelOpenUnBlockModel(row._id)} fontSize="15px"
                                                            style={{ color: "green" }} />
                                                    </Tooltip>

                                                </Box>) :
                                                (<Box bg='white'>
                                                    <Tooltip label='Block Admin' bg='black' style={{ color: "white" }}>
                                                        <BlockIcon onClick={()=>  handelopenBlockModel(row._id)} fontSize="15px"
                                                            style={{ color: "red", cursor: "pointer" }}
                                                        />
                                                    </Tooltip>


                                                </Box>)}</Td>

                                        </Tr>



                                    )) : <div style={{ padding: '80px' }}>
                                        <div style={{ textAlign: 'center' }}>
                                            Loading...
                                        </div>
                                    </div>}

                            </Tbody>

                        </Table>


                    </Card>
                    <Card>
                        <Flex>
                            <Spacer></Spacer>
                            <Flex>
                                <Box m={"20px"} rounded="md">
                                    <Button
                                        fontSize="15px"
                                        bg="blue.200"
                                        w="100%"
                                        h="45"
                                       borderRadius={"5px"}
                                        color="white"
                                        isDisabled={admins.isfirstpage}
                                        onClick={getprevouspage}
                                        _hover={{
                                            bg: "blue",
                                        }}
                                        _active={{
                                            bg: "#5b35f9",
                                        }}
                                        colorScheme='blue' mr={3} >
                                        <ChevronLeftIcon style={{ color: "white" }}></ChevronLeftIcon>

                                    </Button>


                                </Box>
                                <Box rounded="md" m={"20px"}>
                                    <Button
                                        isDisabled={admins.islastpage}
                                        fontSize="15px"
                                        bg="blue.200"
                                        w="100%"
                                        h="45"
                                        color="white"
                                       borderRadius={"5px"}
                                        onClick={getnextpage}
                                        _hover={{
                                            bg: "blue",
                                        }}
                                        _active={{
                                            bg: "#5b35f9",
                                        }}
                                        colorScheme='blue' mr={3} >
                                        <ChevronRightIcon style={{ color: "white" }} ></ChevronRightIcon>
                                    </Button>
                                </Box>
                            </Flex>

                        </Flex>
                    </Card>



                </Card>

            </Grid>

        </Flex>
    );
}
