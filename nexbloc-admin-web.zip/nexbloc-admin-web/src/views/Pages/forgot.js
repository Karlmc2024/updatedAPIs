import React, {useState} from "react";
import {useSelector, useDispatch} from 'react-redux';
import {Link} from 'react-router-dom';
// Chakra imports
import {
  Flex,
  Button,
  FormControl,
  FormLabel,
  Heading,
  Input,
  Text,
  useColorModeValue,
} from "@chakra-ui/react";
// Assets
import {useToast} from '@chakra-ui/toast';
import {  forgot_password  } from '../../store/actions/auth';
import { toastError, toastsuccess } from '../../handler/index';

function Forgot() {
  // Chakra color mode
  const titleColor = useColorModeValue("black", "teal.200");
  const textColor = useColorModeValue("black", "white");
  const loader  = useSelector(state=> state.loaderReducer.loader);
  const dispatch  = useDispatch();
  const [data , setData]  = useState({email :""});
  const toast  = useToast();
  const handelchange = (event) => {
    const { name, value } = event.target;

    setData((preVal) => {
        return {
            ...preVal,
            [name]: value,
        };
    });
};

const onSubmit = async (event) => {
    event.preventDefault();
  
    if (data.email== "" ) {
    toastError("Email  must be provided");
  } else {
     const done  = await dispatch(forgot_password(data, toast));
    if(done){
      setData({...data ,email :""})
    }
  }
}
  return (
    <Flex position="relative" mb="40px">
      <Flex
        h={{ sm: "initial", md: "75vh", lg: "85vh" }}
        w="100%"
        maxW="1044px"
        mx="auto"
        justifyContent="space-between"
        mb="30px"
        mt="30px"
        pt={{ sm: "100px", md: "0px" }}
      >
        <Flex
          alignItems="center"
          justifyContent="start"
          style={{ userSelect: "none" }}
          mx="auto"
          mt={{ md: "150px", lg: "60px" }}
          w={{ base: "90%", md: "50%", lg: "42%" }}
        >
          <Flex
            direction="column"
            w="100%"
            background="white"
            p="48px"
            marginTop={"100px"}
            mt={{ md: "150px", lg: "70px" }}
          >
            <Heading color={titleColor} textAlign="center" fontSize="32px" mb="20px">
               Forgot Password
            </Heading>
            <FormControl onSubmit={onSubmit}>
              <FormLabel ms="4px" fontSize="sm" fontWeight="normal" color={"black"}>
                Email <span style={{color:"red"}}>*</span>
              </FormLabel>
              <Input
                isRequired
                borderRadius="15px"
                mb="24px"
                name="email"
                value={data.email}
                fontSize="sm"
                type="email"
                onChange={handelchange}
                placeholder="Your email address"
                size="lg"
                bg="white"
               focusBorderColor='blue.100'
                
              />
              
                <Button
                 isLoading={loader}
                 loadingText='Submitting'
                fontSize="15px"
                type="submit"
                bg="blue.200"
                w="100%"
                h="45"
                mb="20px"
                color="white"
              onClick={onSubmit}
                mt="20px"
                _hover={{
                  bg: "blue",
                }}
                _active={{
                  bg: "#5b35f9",
                }}
              >
            Forgot Password
              </Button>

              
            </FormControl>
            <Flex
              flexDirection="column"
              justifyContent="flex-end"
              alignItems="flex-end"
              maxW="100%"
              mt="0px"
            >
              <Text color={textColor} >
                <Link to="/auth/signin" color={"#5b35f9"} textTransform="none" textUnderlineOffset={true}  as="span" ms="5px" >
                  sign in
                </Link>
              </Text>
            </Flex>
          </Flex>
        </Flex>

      </Flex>
    </Flex>
  );
}

export default Forgot;
