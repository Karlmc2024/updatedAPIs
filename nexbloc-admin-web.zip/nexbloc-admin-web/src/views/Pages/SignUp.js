import React, { useState } from "react";
import { useSelector, useDispatch } from 'react-redux';
import { Link, useHistory } from 'react-router-dom';
import {signUpAdmin} from '../../store/actions/admin';
import {Checkbox} from '@chakra-ui/react';
// Chakra imports
import {
  Flex,
  Button,
  FormControl,
  FormLabel,
  Heading,
  Input,
  Text,
  useColorModeValue,
} from "@chakra-ui/react";
// Assets
import { signin } from '../../store/actions/auth';
import { toastError, toastsuccess } from '../../handler/index';
import { useToast } from '@chakra-ui/toast';
function SignUp(props) {
  // Chakra color mode
  const titleColor = useColorModeValue("black", "teal.200");
  const textColor = useColorModeValue("black", "white");
  const loader = useSelector(state => state.loaderReducer.loader);
  const dispatch = useDispatch();
  const [data, setData] = useState({ email: "", password: "", first_name :"", last_name : "" ,  repeat_password:"", terms: false})
  const toast = useToast();
  const history = useHistory();
  const handelchange = (event) => {
    const { name, value } = event.target;
    setData((preVal) => {
      return {
        ...preVal,
        [name]: value,
      };
    });
  };

  const onSubmit = async (event) => {
    event.preventDefault();
    
    if (data.email=="" ) {
      toastError("Email and password must be provided", toast);
    }
    else if (data.password  != data.repeat_password ){
      toastError("Password and Confirm password should be same", toast);
    } 
    else {
      const token  = props.match.params.token;

     const done = await  dispatch(signUpAdmin(data,token, toast));
     setData({ email: "", password: "", first_name :"", last_name : "" ,  repeat_password:""});

    }
  }
  return (
    <Flex position="relative" mb="40px">
      <Flex
        h={{ sm: "initial", md: "75vh", lg: "85vh" }}
        w="100%"
        maxW="1044px"
        mx="auto"
        justifyContent="space-between"
        mb="30px"
        mt="30px"
        pt={{ sm: "100px", md: "0px" }}
      >
        <Flex
          alignItems="center"
          justifyContent="start"
          style={{ userSelect: "none" }}
          mx="auto"
          mt={{ md: "150px", lg: "390px" }}
          w={{ base: "90%", md: "50%", lg: "42%" }}
        >
          <Flex
            direction="column"
            w="100%"
            background="white"
            p="48px"
            marginTop={"100px"}
            mt={{ md: "150px", lg: "70px" }}
          >
            <Heading color={titleColor} textAlign="center" fontSize="32px" mb="20px">
              Sign Up
            </Heading>
            <FormControl onSubmit={onSubmit}>
            <FormLabel ms="4px" fontSize="sm" fontWeight="normal" color={"black"}>
                First Name <span style={{color:"red"}}>*</span>
              </FormLabel>
              <Input
                isRequired
                borderRadius="15px"
                mb="24px"
                name="first_name"
                value={data.first_name}
                fontSize="sm"
                type="text"
                onChange={handelchange}
                placeholder="Your first name"
                size="lg"
                bg="white"
                focusBorderColor='blue.100'

              />

<FormLabel ms="4px" fontSize="sm" fontWeight="normal" color={"black"}>
                Last Name <span style={{color:"red"}}>*</span>
              </FormLabel>
              <Input
                isRequired
                borderRadius="15px"
                mb="24px"
                name="last_name"
                value={data.last_name}
                fontSize="sm"
                type="text"
                onChange={handelchange}
                placeholder="Your last name"
                size="lg"
                bg="white"
                focusBorderColor='blue.100'

              />

              <FormLabel ms="4px" fontSize="sm" fontWeight="normal" color={"black"}>
                Email <span style={{color:"red"}}>*</span>
              </FormLabel>
              <Input
                isRequired
                borderRadius="15px"
                mb="24px"
                name="email"
                value={data.email}
                fontSize="sm"
                type="email"
                onChange={handelchange}
                placeholder="Your email address"
                size="lg"
                bg="white"
                focusBorderColor='blue.100'

              />
              <FormLabel ms="4px" fontSize="sm" fontWeight="normal">
                Password  <span style={{color:"red"}}>*</span>
              </FormLabel>
              <Input
                borderRadius="15px"
                mb="36px"
                bg="white"

                onChange={handelchange}
                name="password"
                isRequired
                value={data.password}
                fontSize="sm"
                type="password"
                placeholder="Your password"
                size="lg"
                focusBorderColor='blue.100'
              />

<FormLabel ms="4px" fontSize="sm" fontWeight="normal">
                Repeat Password  <span style={{color:"red"}}>*</span>
              </FormLabel>
              <Input
                borderRadius="15px"
                mb="36px"
                bg="white"
                onChange={handelchange}
                name="repeat_password"
                isRequired
                value={data.repeat_password}
                fontSize="sm"
                type="password"
                placeholder="abcd@1234"
                size="lg"
                focusBorderColor='blue.100'
              />
              <Checkbox name="terms" isChecked={data.terms} onChange={()=> setData({...data , terms :!data.terms  })} >Terms </Checkbox>
              <Button
                isLoading={loader}
                loadingText='Submitting'
                type="submit"
                fontSize="15px"
                bg="blue.200"
                w="100%"
                h="45"
                mb="20px"
                color="white"
                onClick={onSubmit}
                mt="20px"
                _hover={{
                  bg: "blue",
                }}
                _active={{
                  bg: "#5b35f9",
                }}
              >
                Sign up
              </Button>


            </FormControl>
            <Flex
              flexDirection="column"
              justifyContent="flex-end"
              alignItems="flex-end"
              maxW="100%"
              mt="0px"
            >
              <Text color={textColor} >
                <Link to="/auth/signin" color={"#5b35f9"} textTransform="none" as="span" ms="5px" >
                  Sign in
                </Link>
              </Text>
            </Flex>
          </Flex>
        </Flex>

      </Flex>
    </Flex>
  );
}

export default SignUp;
