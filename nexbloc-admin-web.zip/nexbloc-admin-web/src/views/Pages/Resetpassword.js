import React, {useState} from "react";
import {useSelector, useDispatch} from 'react-redux';
import {Link} from 'react-router-dom';
// Chakra imports
import {
  Box,
  Flex,
  Button,
  FormControl,
  FormLabel,
  Heading,
  Input,

  Text,
  Image,
  useColorModeValue,
} from "@chakra-ui/react";
// Assets
import loadingimg from '../../assets/img/loader.svg';
import {  reset_password  } from '../../store/actions/auth';
import { toastError, toastsuccess } from '../../handler/index';
import {useToast} from '@chakra-ui/toast';
import PasswordInput from '../../components/Password';

function Reset(props) {
  // Chakra color mode
  const titleColor = useColorModeValue("black", "teal.200");
  const textColor = useColorModeValue("black", "white");
  const loader  = useSelector(state=> state.loaderReducer.loader);
  const dispatch  = useDispatch();
  const [data , setData]  = useState({password:"", repeat_password: ""});
  const toast  = useToast();
  const handelchange = (event) => {
    const { name, value } = event.target;

    setData((preVal) => {
        return {
            ...preVal,
            [name]: value,
        };
    });
};

const onSubmit = async (event) => {
    event.preventDefault();
  const token  = props.match.params.id;  
  if (data.password  == ""   || data.repeat_password  =="") {
    toastError("Password and Repeat password required", toast);
  } else if(token == ""){
      toastError("Invalide link", toast);
  }
  else if(data.password  !== data.repeat_password){
    toastError("Password and Repeat Password should be same ", toast);
  }
  else{
    const  done  = await dispatch(reset_password(token , data, toast));
    if(done){
      setData({...data,  password :"", repeat_password: ""});
    }
  }
}
  return (
    <Flex position="relative" mb="40px">
      <Flex
        h={{ sm: "initial", md: "75vh", lg: "85vh" }}
        w="100%"
        maxW="1044px"
        mx="auto"
        justifyContent="space-between"
        mb="30px"
        mt="30px"
        pt={{ sm: "100px", md: "0px" }}
      >
        <Flex
          alignItems="center"
          justifyContent="start"
          style={{ userSelect: "none" }}
          mx="auto"
          mt={{ md: "150px", lg: "60px" }}
          w={{ base: "90%", md: "50%", lg: "42%" }}
        >
          <Flex
            direction="column"
            w="100%"
            background="white"
            p="48px"
            marginTop={"100px"}
            mt={{ md: "150px", lg: "80px" }}
          >
            <Heading color={titleColor} textAlign="center" fontSize="32px" mb="10px">
               Reset Password
            </Heading>
            <FormControl onSubmit={onSubmit}>
               <FormLabel ms="4px" fontSize="sm" fontWeight="normal">
                Password <span style={{color:"red"}}>*</span>
              </FormLabel>
             <PasswordInput isRequired={true}
                borderRadius="15px"
                mb="36px"
                required
                bg="white"
                onChange={handelchange}
                name="password"
                value={data.password}
                fontSize="sm"
                type="password"
                placeholder="Your password"
                size="lg"
                focusBorderColor='blue.100'  />
              
              <FormLabel ms="4px" fontSize="sm" fontWeight="normal">
                Enter repeat password <span style={{color:"red"}}>*</span>
              </FormLabel>
              <PasswordInput
            isRequired={true}
                borderRadius="15px"
                mb="36px"
                bg="white"
                onChange={handelchange}
                name="repeat_password"
                value={data.repeat_password}
                fontSize="sm"
                type="password"
                placeholder="Your repeat password"
                size="lg"
                focusBorderColor='blue.100'
              />
              
             
              
                <Button
                 isLoading={loader}
                 loadingText='Submitting'
                type="submit"
                fontSize="15px"
                bg="blue.200"
                w="100%"
                h="45"
                mb="20px"
                color="white"
              onClick={onSubmit}
                mt="20px"
                _hover={{
                  bg: "blue",
                }}
                _active={{
                  bg: "#5b35f9",
                }}
              >
            Reset Password
              </Button>

              
            </FormControl>
            <Flex
              flexDirection="column"
              justifyContent="flex-end"
              alignItems="flex-end"
              maxW="100%"
              mt="0px"
            >
              <Text color={textColor} textDecorationLine="underline" >
                <Link to="/auth/signin" color={"#5b35f9"} textTransform="none" textUnderlineOffset={true}  as="span" ms="5px" >
                  sign in
                </Link>
              </Text>
            </Flex>
          </Flex>
        </Flex>

      </Flex>
    </Flex>
  );
}

export default Reset;
