import React from 'react';
import { Button} from '@chakra-ui/react';
import {DownloadIcon} from '@chakra-ui/icons';

const DownloadButton = ({handeldownload, fileloader })=>{
    return (
        <React.Fragment>
            
            <Button
                                        isLoading={fileloader}
                                        loadingText='downloading...'
                                        type="submit"
                                        leftIcon={<DownloadIcon color={"white"} />}
                                        fontSize="15px"
                                        bg="blue.200"
                                        w="100%"
                                        borderRadius={"5px"}
                                        onClick={handeldownload}
                                        h="45"
                                        mb="20px"
                                        color="white"
                                        mt="30px"
                                        _hover={{
                                            bg: "blue",
                                        }}
                                        _active={{
                                            bg: "#5b35f9",
                                        }}
                                    >
                                        Download
                                    </Button>
        </React.Fragment>
        
    )
}

export default DownloadButton;
