
const init_state = {
rows :[],
    isfirstpage : false,
    islastpage : false ,
    count : 0
}
export const  trademarkRequestReducer  = (state=  init_state , action )=>{
    const { type , payload} =  action;
    switch(type){
        case "SET_TRADEMARK_REQUESTS": 
            return  {...state , rows : payload.rows , isfirstpage : payload.isfirstpage , islastpage :  payload.islastpage};
        default :
            return state;
    }
}