let  initialstate = {
    rows: [],
    page: 1,
    count: 0,
    islastpage: true,
    isfirstpage: true
}


function getafterBlockrows(rows, id) {
   
    const newrows = rows.map(row => {
        if (row._id == id) {
            return {...row, isactive : false};
        }
        return row;
    })
    return newrows;


}

function getafterunBlockrows(rows, id) {
    const newrows = rows.map(row => {
        if (row._id == id) {
            
            return {...row  , isactive : true};
        }
        return row;
    })
    return newrows;

}

export const adminReducer = (state = initialstate, action) => {
    const { type, payload } = action;
    switch (type) {
        case "SET_ADMINS":
            return { ...state, rows: payload.rows, count: payload.count, page: payload.page, islastpage: payload.islastpage, isfirstpage: payload.isfirstpage };
        case "ADD_ADMIN":
            return { ...state, rows: [...state.rows, payload] };
        case "DISABLE_PAGE_BTN":
            return {...state , isfirstpage: true , islastpage : true};
        case "BLOCK_ADMIN":
            return { ...state, rows: getafterBlockrows(state.rows, payload.id) };
        case "UNBLOCK_ADMIN":
            return { ...state, rows: getafterunBlockrows(state.rows, payload.id) };
        default:
            return state;
    }
}
