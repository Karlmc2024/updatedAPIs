
const init_state = {
    rows :[],
    isfirstpage : false,
    islastpage : false ,
    count : 0
}
export const  trademarkReducer  = (state=  init_state , action )=>{
    const { type , payload} =  action;
    switch(type){
        case "SET_TRADEMARKS": 
            return  {...state , rows : payload.rows, isfirstpage : payload.isfirstpage , islastpage :  payload.islastpage};
        default :
            return state;
    }
}