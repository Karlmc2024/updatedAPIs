
const init_state = {
    domains :[],
    isfirstpage : false,
    islastpage : false ,
    curdomain : {},
    count : 0
}
export const  domainReducer  = (state=  init_state , action )=>{
    const { type , payload} =  action;
    switch(type){
        case "SET_DOMAINS": 
            return  {...state , domains: payload.domains , isfirstpage : payload.isfirstpage , islastpage :  payload.islastpage};
        case "SET_CURRUNT_DOMAIN": 
        return {...state , curdomain : payload};
        default :
            return state;
    }
}