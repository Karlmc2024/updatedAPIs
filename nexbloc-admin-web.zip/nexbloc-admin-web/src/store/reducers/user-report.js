const initialstate = {
    totalUser :0,
    monthlyUser : {xaxies:[] , yaxies: [], count : 0},
    yearlyUser: {xaxies:[] , yaxies: [], count : 0, uptolastyearusercount: 0 },
    daytodayUser :{xaxies:[] , yaxies: [], count : 0} 
}

export const userreportReducer = (state = initialstate , action)=>{
    const { type , payload}  = action;
    switch(type){
        case "SET_TOTAL_USER": 
            return { ...state , totalUser :  payload};
        case "SET_MONTHLY_USER_REPORT" :
            return { ...state ,monthlyUser : payload }
        case "SET_YEARLY_USER_REPORT":
             return  { ...state , yearlyUser: payload};
        case "SET_DAY_TO_DAY_USER_REPORT": 
            return {...state , daytodayUser : payload};
        default :
            return state
    }
}
