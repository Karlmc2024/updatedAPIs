import { combineReducers } from 'redux';
import authReducer from './auth';
import loaderReducer  from './loader';
import {imageloaderReducer} from './imageloader';
import {adminReducer} from './admin';
import {userReducer} from './user';
import {domainReducer} from './domain';
import {premiumdomainReducer} from './premium-domain';
import {fileloaderReducer} from './file-loader';
import {countReducer} from  './count';
import {userdomainReducer} from './user-domain';
import {salereportReducer} from './sale-report';
import {userreportReducer} from  './user-report';
import {trademarkRequestReducer} from './Trademark-request';
import {trademarkReducer} from './trademark';

const rootReducer = combineReducers({
    authReducer ,
    loaderReducer,
   adminReducer,
   imageloaderReducer ,
   userReducer,
   domainReducer,
   premiumdomainReducer ,
   fileloaderReducer,
   countReducer ,
   userdomainReducer,
   userreportReducer ,
   salereportReducer,
   trademarkReducer ,
   trademarkRequestReducer
})

export default rootReducer;