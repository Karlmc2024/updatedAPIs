let initstate  = {
    today_users: 0,
    today_domains: 0,
    total_book_domains: 0,
    today_premium_domains : 0 
}

export const countReducer  = (state = initstate , action)=>{
    const {type , payload} = action;
    switch(type){
        case "SET_USER_COUNT":
            return {...state , today_users : payload};
        case "SET_DOMAIN_COUNT":
            return {...state , today_domains : payload};
        case "SET_BOOK_DOMAIN_COUNT":
            return {...state , total_book_domains : payload};
        case "SET_PREMIUM_DOMAINS":
            return {...state , today_premium_domains : payload};
        default: 
            return state;
    }
}