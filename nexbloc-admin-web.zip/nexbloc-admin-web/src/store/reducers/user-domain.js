
const init_state = {
    domains :[],
    isfirstpage : false,
    islastpage : false ,
    count : 0
}
export const  userdomainReducer  = (state=  init_state , action )=>{
    const { type , payload} =  action;
    switch(type){
        case "SET_USER_DOMAINS": 
        
            return  {...state , domains: payload.domains , isfirstpage : payload.isfirstpage , islastpage :  payload.islastpage};
        default :
            return state;
    }
}