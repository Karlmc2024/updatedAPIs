const init_state ={
    premiumdomains :[],
    isfirstpage : false ,
    islastpage : false ,
    count :0
}
export const  premiumdomainReducer  =  (state = init_state ,action )=>{
    const { type ,payload }  = action;
    switch(type){
        case "SET_PREMIUM_DOMAINS":
            return  {...state , premiumdomains : payload.premiumdomains , isfirstpage : payload.isfirstpage , islastpage : payload.islastpage};
        case "ADD_PREMIUM_DOMAIN":
            return {  ...state,  premiumdomains: [  payload.domain,...state.premiumdomains ]};
        default : 
            return state;
    }
}

