import axiosinstance from '../../config/axios';
import { toastError, toastsuccess } from '../../handler/index';
import exportfromjson from 'export-from-json';

export const getTrademarkRequests  =  (formdata, toast)=> async (dispatch)=>{
    try {
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/trademark/request/?start=${formdata.start}&end=${formdata.end}`);
        // dispatch({ type :"SET_TRADEMARK_REQUEST",  payload :{ rows }})       
        dispatch({type :"SET_TRADEMARK_REQUESTS", payload: {rows : data.data.result   , isfirstpage: true , islastpage: true   }});

        dispatch({ type: "SET_LOADER", payload: false });   
        return true;

    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}

export const searchTrademarkRequest = (formdata, toast)=> async (dispatch)=>{
    try {
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/trademark/request/search?domainName=${formdata.domainName}`);
        dispatch({ type: "SET_LOADER", payload: false });
        dispatch({type :"SET_TRADEMARK_REQUESTS", payload: {rows : data.data.result   , isfirstpage: true , islastpage: true   }});
 
        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}

export const downloadTrademarkRequests  = (formdata, toast)=> async (dispatch)=>{
    try {
      
        dispatch({ type: "SET_FILE_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/trademark/request/?start=${formdata.start}&end=${formdata.end}`);
        exportfromjson({ data: data.data.result, fileName: `nexbloc-file-${formdata.start}-${formdata.end}`, exportType: formdata.filetype})
        dispatch({ type: "SET_FILE_LOADER", payload: false });
        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}


export const changeRequestStatus  =(formdata, toast) => async (dispatch)=>{
    try {
        const { data } = await axiosinstance.put(`/trademark/request/${formdata.id }`,  {
        status : formdata.status 
        });
      toastsuccess("Trademark  request status changed successfully", toast);
        return true;

    }
    catch(error){
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}