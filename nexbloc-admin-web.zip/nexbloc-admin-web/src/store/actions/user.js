import axiosinstance from '../../config/axios';
import { toastError, toastsuccess } from '../../handler/index';
import exportfromjson from 'export-from-json';

export const getUsers = (formdata, toast) => async (dispatch) => {
    try {
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/users/?start=${formdata.start}&end=${formdata.end}`);
        dispatch({ type: "SET_USERS", payload: { users: data.data.result, isfirstpage: data.data.isfirstpage, islastpage: data.data.islastpage } });
        dispatch({ type: "SET_LOADER", payload: false });
        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}


export const getUserPagination = (formdata, toast) => async (dispatch) => {
    try {
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/users/?start=${formdata.start}&end=${formdata.end}&page=${formdata.page}&limit=${formdata.limit}`);
        dispatch({ type: "SET_USERS", payload: { users: data.data.result, isfirstpage: data.data.isfirstpage, islastpage: data.data.islastpage } });
        dispatch({ type: "SET_LOADER", payload: false });
        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}

export const getUserDetail = (formdata, toast) => async (dispatch) => {
    try {
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.get("", formdata);
        dispatch({ type: "SET_LOADER", payload: false });
        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}

export const searchUser = (formdata, toast) => async (dispatch) => {
    try {
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/users/search?firstName=${formdata.firstName}`);
        dispatch({ type: "SET_USERS", payload: { users: data.data.result, isfirstpage: true, islastpage: true } });
        dispatch({ type: "SET_LOADER", payload: false });
        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}


export const downloadUsers = (formdata, toast) => async (dispatch) => {
    try {
        dispatch({ type: "SET_FILE_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/users/?start=${formdata.start}&end=${formdata.end}`);
        exportfromjson({ data: data.data.result, fileName: `nexbloc-file-${formdata.start}-${formdata.end}`, exportType: formdata.filetype })
        dispatch({ type: "SET_FILE_LOADER", payload: false });
        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_FILE_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}


export const getTodayusercount = (toast) => async (dispatch) => {
    try {
        //  get the count 
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/users/today-count`);
        dispatch({ type: "SET_USER_COUNT", payload: data.data.result });
        dispatch({ type: "SET_LOADER", payload: false });
        return true;

    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }

}

export const getuserDomainPagination = (formdata, toast) => async (dispatch) => {
    try {
        //  get the count 
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/users/domains/${formdata._id}?page=${formdata.page}&limit=${formdata.limit}`);
        dispatch({ type: "SET_USER_DOMAINS", payload: { domains: data.data.result, isfirstpage : data.data.isfirstpage , islastpage : data.data.islastpage } });
        dispatch({ type: "SET_LOADER", payload: false });
        return true;

    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}