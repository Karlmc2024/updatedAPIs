import axiosinstance from '../../config/axios';
import { toastError, toastsuccess } from '../../handler/index';
export const addAdmin = (formdata, toast) => async (dispatch) => {
    try {
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.post("/admin/add-admin", formdata);
        dispatch({ type: "SET_LOADER", payload: false });
        toastsuccess("Invitation Sended successfully", toast);
        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);

            return false;

        }
    }
}


export const getAdmins = (page, limit, toast) => async (dispatch) => {
    try {
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/admin/?page=${page}&limit=${limit}`);
        dispatch({type :"SET_ADMINS", payload :{...data.data}})       
        dispatch({ type: "SET_LOADER", payload: false });
        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });

            toastError(error.response.data.message, toast);
            return false;

        }
    }
}

export const BlockAdmin = (id, toast) => async (dispatch) => {
    try {
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.post(`/admin/block/${id}`);
        dispatch({ type: "BLOCK_ADMIN", payload: { id } });
        dispatch({ type: "SET_LOADER", payload: false });

        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });

            toastError(error.response.data.message, toast);
            return false;

        }
    }
}

export const unBlockAdmin = (id, toast) => async (dispatch) => {
    try {
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.post(`/admin/unblock/${id}`);
        dispatch({ type: "UNBLOCK_ADMIN", payload: { id } });
        dispatch({ type: "SET_LOADER", payload: false });

        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;

        }
    }
}

export const searchAdmin  = (first_name, toast)=> async (dispatch)=>{
    try{
        dispatch({type :"DISABLE_PAGE_BTN", payload :  {}})
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/admin/search/?first_name=${first_name}`);
        dispatch({type :"SET_ADMINS", payload :{rows : data.data.rows , count : data.data.count , isfirstpage : false , islastpage: false}});
        dispatch({ type: "SET_LOADER", payload: false });
        return true;

    }
    catch(error){
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
    }
}

export const signUpAdmin  = (formdata,token, toast)=> async (dispatch)=>{
    try{
        dispatch({type :"SET_LOADER", payload : true });
        const {data} = await axiosinstance.post(`/admin/setup-account/${token}`,formdata);
        dispatch({ type : "SET_LOADER", payload : false});
        toastsuccess("Sign up Successfully", toast);
        return true;
    }
    catch(error){
        dispatch({ type: "SET_LOADER", payload: false });
        toastError(error.response.data.message, toast);
        return false;
    }
}