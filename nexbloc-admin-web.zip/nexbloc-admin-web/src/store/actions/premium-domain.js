import axiosinstance from '../../config/axios';
import { toastError, toastsuccess } from '../../handler/index';
import exportfromjson from 'export-from-json';

export const getPremiumDomain  = (formdata, toast)=> async (dispatch)=>{
    try {
        dispatch({ type: "SET_LOADER", payload: true });
      
        const { data } = await axiosinstance.get(`/premium-domains/?start=${formdata.start}&end=${formdata.end}`);
        dispatch({type :"SET_PREMIUM_DOMAINS" , payload :{premiumdomains : data.data.result , isfirstpage : data.data.isfirstpage, islastpage: data.data.islastpage }});
       
        dispatch({ type: "SET_LOADER", payload: false });
        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}


export const getPremiumDomainPagination = (formdata, toast)=> async (dispatch)=>{
    try {
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/premium-domains/?start=${formdata.start}&end=${formdata.end}&page=${formdata.page}&limit=${formdata.limit}`);
       
        dispatch({type :"SET_PREMIUM_DOMAINS" , payload :{premiumdomains : data.data.result , isfirstpage : data.data.isfirstpage, islastpage: data.data.islastpage }});
        dispatch({ type: "SET_LOADER", payload: false });
        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}


export const getPremiumDomainDetail  = (formdata, toast)=> async (dispatch)=>{
    try {
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/premium-domains/?start=${formdata.start}&end=${formdata.end}&page=${formdata.page}&limit=${formdata.limit}`);
        dispatch({type :"SET_PREMIUM_DOMAINS" , payload :{users : data.data.result , isfirstpage : data.data.isfirstpage, islastpage: data.data.islastpage }});
        dispatch({ type: "SET_LOADER", payload: false });
        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}

export  const searchPremiumDomain  = (formdata, toast)=> async (dispatch)=>{
    try {
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/premium-domains/search?domainName=${formdata.domainName}`);
        dispatch({type :"SET_PREMIUM_DOMAINS" , payload :{premiumdomains : data.data.result , isfirstpage : true, islastpage: true }});
        dispatch({ type: "SET_LOADER", payload: false });
        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}

export const getTodaypremiumdomaincount =(toast)=>async (dispatch)=>{
    try{
        dispatch({type:"SET_LOADER" ,payload: true});
        const { data} = await axiosinstance.get('/premium-domain/today-count');
        dispatch({type :"SET_PREMIUM_DOMAIN_COUNT", payload:  data.data.result});
        dispatch({type:"SET_LOADER", payload : false});
    }
    catch(error){
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}

export const downloadpremiumDomains  = (formdata, toast)=> async (dispatch)=>{
    try{
        dispatch({ type: "SET_FILE_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/premium-domains/?start=${formdata.start}&end=${formdata.end}`);
        exportfromjson({ data: data.data.result, fileName: `nexbloc-file-${formdata.start}-${formdata.end}`, exportType: formdata.filetype})
        dispatch({ type: "SET_FILE_LOADER", payload: false });
        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_FILE_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}
export const addPremiumdomain  = (formdata, toast)=> async  (dispatch)=>{
    try{
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.post(`/premium-domains/`, formdata);
        dispatch({type :"ADD_PREMIUM_DOMAIN" , payload :{domain : data.result  }});
        toastsuccess("Premium domain added successfully", toast);
        dispatch({ type: "SET_LOADER", payload: false });
        return true;   
    }
    catch(error){
        if (error.response && error.response.data) {
            dispatch({ type: "SET_FILE_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}