import axiosinstance from '../../config/axios';
import { toastError, toastsuccess } from '../../handler/index';
import exportfromjson from 'export-from-json';


export const getDomains  = (formdata, toast)=> async (dispatch)=>{
    try {
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/domains/?start=${formdata.start}&end=${formdata.end}`);
        dispatch({type :"SET_DOMAINS" , payload :{domains : data.data.result , isfirstpage : data.data.firstpage, islastpage: data.data.islastpage }});        
        dispatch({ type: "SET_LOADER", payload: false });
        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}

export const getAllDomainPagination  = (formdata, toast)=> async (dispatch)=>{
    try {
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/domains/?start=${formdata.start}&end=${formdata.end}&page=${formdata.page}&limit=${formdata.limit}`);
        dispatch({type :"SET_DOMAINS" , payload :{domains : data.data.result , isfirstpage : data.data.isfirstpage, islastpage: data.data.islastpage }});   
        dispatch({ type: "SET_LOADER", payload: false });
        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}


export const searchDomain  = (formdata, toast)=> async (dispatch)=>{
    try {
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/domains/search?domainName=${formdata.domainName}`);
        dispatch({type :"SET_DOMAINS" , payload :{domains : data.data.result , isfirstpage :true, islastpage: true }});
        dispatch({ type: "SET_LOADER", payload: false });
        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}
export const downloadDomains  = (formdata, toast)=> async (dispatch)=>{
    try {
        dispatch({ type: "SET_FILE_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/domains/?start=${formdata.start}&end=${formdata.end}`);
        exportfromjson({ data: data.data.result, fileName: `nexbloc-file-${formdata.start}-${formdata.end}`, exportType: formdata.filetype})
        dispatch({ type: "SET_FILE_LOADER", payload: false });
        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}

export const getTodaydomaincount  = (toast)=> async (dispatch)=>{
    try{
        dispatch({ type :"SET_LOADER", payload: true});
        const { data}  = await axiosinstance.get('/domains/today-count');
        dispatch({ type :"SET_DOMAIN_COUNT", payload : data.data.result});
        dispatch({ type :"SET_LOADER", payload : false});
    }
    catch(error){
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}

export const  getTotalBookDomainCount  = (toast)=> async (dispatch)=>{
    try{
        dispatch({ type :"SET_LOADER", payload: true});
        const { data}  = await axiosinstance.get('/domains/total-book-domain');
        dispatch({ type :"SET_BOOK_DOMAIN_COUNT", payload : data.data.result});
        dispatch({ type :"SET_LOADER", payload : false});

    }
    catch(error){
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}

export const getDomainDetail  =(_id,toast)=> async (dispatch)=>{
    try{
        dispatch({ type :"SET_LOADER", payload: true});
        const { data}  = await axiosinstance.get(`/domains/detail/${_id}`);
         dispatch({type : "SET_CURRUNT_DOMAIN", payload : data.data.result[0]});
        dispatch({ type :"SET_LOADER", payload : false});
    }
    catch(error){
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}