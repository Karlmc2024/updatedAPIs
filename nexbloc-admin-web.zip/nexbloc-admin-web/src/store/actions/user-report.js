

/*****************************************   USER REPORT *******************************/
import axiosinstance from '../../config/axios';
import { toastsuccess, toastError } from '../../handler/index';
import {updatelocalUser, changelocalImage} from '../../config/index';
import { formatUserDaytodayData, formatUserYearlyData , formatUserMonthlydata} from '../../helper/user-helper';
export const getCurruntMonthUserReports = (formdata , toast)=> async (dispatch)=>{
    try{
      
        dispatch({ type : "SET_LOADER", payload : true});
        const {data}  = await axiosinstance.get(`/users/currunt-month?startdate=${formdata.startdate}&enddate=${formdata.enddate}`);
        
        dispatch({ type :"SET_DAY_TO_DAY_USER_REPORT", payload :formatUserDaytodayData(data.result) });
        dispatch({type :"SET_LOADER" , payload : false});

    }
    catch(error){
        
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}

export const  getYearlyUserReport  = (formdata , toast)=> async  (dispatch)=>{
    try{
        dispatch({ type : "SET_LOADER", payload : true});
        const {data } = await axiosinstance.get(`/users/yearly?startyear=${formdata.startyear}&endyear=${formdata.endyear}`);
       console.log("the yearly user", data.data.result);
        dispatch({ type : "SET_YEARLY_USER_REPORT",  payload :formatUserYearlyData(data.data.result)});
        dispatch({type :"SET_LOADER" , payload : false});
    }
    catch(error){
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}

export const getMonthWiseReport = (formdata , toast)=> async (dispatch)=>{
    try{
        dispatch({ type : "SET_LOADER", payload : true});
        const {data }  = await axiosinstance.get(`/users/monthly?startmonth=${formdata.startmonth}&endmonth=${formdata.endmonth}`);   
        dispatch({  type : "SET_MONTHLY_USER_REPORT", payload : formatUserMonthlydata(data.result)});
        dispatch({type :"SET_LOADER" , payload : false});
    }
    catch(error){
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
} 
