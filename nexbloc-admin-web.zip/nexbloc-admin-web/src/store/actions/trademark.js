import axiosinstance from '../../config/axios';
import { toastError, toastsuccess } from '../../handler/index';
import exportfromjson from 'export-from-json';

export const getTrademark =  (formdata, toast)=> async (dispatch)=>{
    try {
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/trademark/?start=${formdata.start}&end=${formdata.end}`);
        dispatch({type :"SET_TRADEMARKS", payload: {rows : data.data.result   , isfirstpage: true  , islastpage: true   }});

        dispatch({ type: "SET_LOADER", payload: false });
        
        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}
export const downloadTrademark =  (formdata, toast)=> async (dispatch)=>{
    try {
        
        dispatch({ type: "SET_FILE_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/trademark/?start=${formdata.start}&end=${formdata.end}`);
        exportfromjson({ data: data.data.result, fileName: `nexbloc-file-${formdata.start}-${formdata.end}`, exportType: formdata.filetype})
        dispatch({ type: "SET_FILE_LOADER", payload: false });
        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}

export const searchTrademark  =  (formdata, toast)=> async (dispatch)=>{
    try {
        dispatch({ type: "SET_LOADER", payload: true });
        const { data } = await axiosinstance.get(`/trademarks/?start=${formdata.start}&end=${formdata.end}`);
        dispatch({ type: "SET_LOADER", payload: false });
        
        return true;
    }
    catch (error) {
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}
