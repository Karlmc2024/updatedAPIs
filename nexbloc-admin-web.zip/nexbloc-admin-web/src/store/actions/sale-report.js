

/*****************************************   SALE REPORT *******************************/
import axiosinstance from '../../config/axios';
import { toastsuccess, toastError } from '../../handler/index';
import {updatelocalUser, changelocalImage} from '../../config/index';
import exportfromjson from 'export-from-json';

import {formatSaleMonthlydata , formatSaleDaytodayData, formatSaleYearlyData} from '../../helper/index';
export const getCurruntMonthSaleReports = (formdata , toast)=> async (dispatch)=>{
    try{
        dispatch({ type : "SET_LOADER", payload : true});
        const {data}  = await axiosinstance.get(`/sale/currunt-month?startdate=${formdata.startdate}&enddate=${formdata.enddate}`);       
        dispatch({ type :"SET_DAY_TO_DAY_SALE_REPORT", payload :formatSaleDaytodayData(data.result) });
        dispatch({type :"SET_LOADER" , payload : false});
    }
    catch(error){
        
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}

export const  getYearlySaleReport  = (formdata , toast)=> async  (dispatch)=>{
    try{
        dispatch({ type : "SET_LOADER", payload : true});
        const {data } = await axiosinstance.get(`/sale/yearly?startyear=${formdata.startyear}&endyear=${formdata.endyear}`);
        dispatch({ type : "SET_YEARLY_SALE_REPORT",  payload :formatSaleYearlyData(data.result)});
        dispatch({type :"SET_LOADER" , payload : false});
    }
    catch(error){
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}

export const getMonthWiseReport = (formdata , toast)=> async (dispatch)=>{
    try{
        dispatch({ type : "SET_LOADER", payload : true});
        const {data }  = await axiosinstance.get(`/sale/monthly?startmonth=${formdata.startmonth}&endmonth=${formdata.endmonth}`);
        
        dispatch({  type : "SET_MONTHLY_SALE_REPORT", payload : formatSaleMonthlydata(data.result)});
        dispatch({type :"SET_LOADER" , payload : false});

    }
    catch(error){
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
} 

export const gettotalSale  = (toast)=> async (dispatch)=>{
    try{
        dispatch({ type : "SET_LOADER", payload : true});
        const { data}  = await axiosinstance.get('/sale/total-sale');
        dispatch({ type :"SET_TOTAL_SALE" , payload :  data.result});
        dispatch({type :"SET_LOADER" , payload : false});
    }
    catch(error){
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }
    }
}

export const downloadSale  = (formdata , toast)=>async (dispatch)=>{
    try{
        dispatch({type :"SET_LOADER", payload: true});
        const { data }  = await axiosinstance.get(`/sale/report?startdate=${formdata.startdate}&enddate=${formdata.enddate}`);
        
        exportfromjson({ data: data.result, fileName: `nexbloc-file-${formdata.startdate}-${formdata.enddate}`, exportType: formdata.filetype})
    
        dispatch({ type :"SET_LOADER", payload : false }) 
    }
    catch(error){
        if (error.response && error.response.data) {
            dispatch({ type: "SET_LOADER", payload: false });
            toastError(error.response.data.message, toast);
            return false;
        }

    }
}