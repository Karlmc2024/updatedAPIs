
export const formatSaleMonthlydata = (data) => {



    let result = { xaxies: [], yaxies: [] };
    let dsale = 0;
    let psale = 0;
    const curmonth = new Date().getMonth() + 1;
    const curyear = new Date().getFullYear();
    for (let i = 1; i <= curmonth; i++) {

        let flag = false;

        for (let index in data) {
            if (data[index]._id.month == i) {
                result.xaxies.push(`${data[index]._id.month}-${data[index]._id.year}`);
                result.yaxies.push(data[index].amount);
                dsale += parseInt(data[index].amount);
                flag = true;
            }
        }
        if (flag === false) {
            result.xaxies.push(`${i}-${curyear}`);
            result.yaxies.push(0);

        }
    }
    return { xaxies: result.xaxies, yaxies: [{ name: "Sale", data: result.yaxies }], domain: dsale, premiumdomain: psale, total: psale + dsale };
}

export const formatSaleYearlyData = (data) => {
    let result = { xaxies: [], yaxies: [] };
    let dsale = 0;
    let psale = 0;
    let uptolastyearssale = 0;
    const curyear = new Date().getFullYear();
    for (let i = 2020;i<=curyear ;i++) {
        let flag = false;

        for (let index in data) {
            if (data[index]._id.year == i) {
                result.xaxies.push(data[index]._id.year);
                if (parseInt(data[index]._id.year) < curyear) {
                    uptolastyearssale += parseInt(data[index].amount);
                }
                result.yaxies.push(data[index].amount);
                dsale += parseInt(data[index].amount);
                flag = true;
                break;
            }
        }
        if(flag== false){
            result.xaxies.push(i);
            result.yaxies.push(0);
        
        }
    }
    return { xaxies: result.xaxies, yaxies: [{ name: "Sale", data: result.yaxies }], domain: dsale, premiumdomain: psale, total: psale + dsale, uptolastyearssale: uptolastyearssale };

}

export const formatSaleDaytodayData = (data) => {
    let result = { xaxies: [], yaxies: [] };
    let dsale = 0;
    let psale = 0;
    const curdate = new Date().getDate();
    const curyear = new Date().getFullYear();
    const curmonth = new Date().getMonth() + 1;
    for (let i = 1; i <= curdate; i++) {
        let flag = false;
        for (let index in data) {
            if (data[index]._id.dayOfMonth == i) {
                result.xaxies.push(`${data[index]._id.dayOfMonth}-${data[index]._id.month}-${data[index]._id.year}`);

                result.yaxies.push(data[index].amount);
                dsale += parseInt(data[index].amount);
                flag = true;
                break;

            }

        }
        if (flag === false) {
            result.xaxies.push(`${i}-${curmonth}-${curyear}`);
            result.yaxies.push(0);

        }

    }

    return { xaxies: result.xaxies, yaxies: [{ name: "Sale", data: result.yaxies }], domain: dsale, premiumdomain: psale, total: dsale + psale };
}
