// import
import Dashboard from "views/Dashboard/Dashboard.js";
import Profile from "views/Dashboard/Profile.js";
import SignIn from "views/Pages/SignIn.js";
import SignUp from "views/Pages/SignUp.js";
import Forgot from "views/Pages/forgot";
import Resetpassword from 'views/Pages/Resetpassword';
import Admins from 'views/Dashboard/Admins';
import Users from "views/Dashboard/Users";
import Domains from 'views/Dashboard/Domain/index';

import Sales from 'views/Dashboard/Sales';
import UserDomains  from "views/Dashboard/User-domains";
import Reports from "views/Dashboard/Reports";
import DomainDetail from  'views/Dashboard/Domain-detail';
import Trademarks  from 'views/Dashboard/Trademark/index';
import TrademarksRequests from "views/Dashboard/Trademark/TrademarkRequests";
import {
  HomeIcon,
  StatsIcon,
  CreditIcon,
  PersonIcon,
  DocumentIcon,
  RocketIcon,
  SupportIcon,
} from "components/Icons/Icons";
import { signin } from "store/actions/auth";

var dashRoutes = [
  {
    path: "/dashboard",
    name: "Dashboard",
    icon: <HomeIcon color="inherit" />,
    component: Dashboard,
    layout: "/admin",
  },
  {
    path: "/sales",
    name: "Sale Report",
    icon: <CreditIcon color="inherit" />,
    component: Sales,
    layout: "/admin",
  },
  {
    path: "/Admins",
    name: "Admin",
    icon: <PersonIcon color="inherit" />,
    component: Admins,
    layout: "/admin",
  },
  
  {
    path: "/trademarks",
    name: "Trademark",
    icon: <CreditIcon color="inherit" />,
    component: Trademarks,
    layout: "/admin",
  },
  
  {
    path: "/Users",
    name: "User",
    icon: <PersonIcon color="inherit" />,
    component: Users,
    layout: "/admin",
  },
  {
    path: "/domains",
    name: "Domain",
    icon: <CreditIcon color="inherit" />,
    component: Domains,
    layout: "/admin",
  },
  

  
  {
    name: "Account",
    category: "account",
    state: "pageCollapse",
    views: [
      {
        path: "/profile",
        name: "Profile",
        icon: <PersonIcon color="inherit" />,
        secondaryNavbar: true,
        component: Profile,
        layout: "/admin",
      },
      {
        path: "/user-domains/:id",
        name: "User Domains",
        icon: <PersonIcon color="inherit" />,
        secondaryNavbar: true,
        component: UserDomains,
        layout: "/admin",
      },
      {
        path: "/reset-password/:id",
        name: "Reset password",
        icon: <DocumentIcon color="inherit" />,
        component: Resetpassword,
        layout: "/auth",
      },
      {
        path: "/forgot-password",
        name: "Forgot Password",
        icon: <DocumentIcon color="inherit" />,
        component: Forgot,
        layout: "/auth",
      },
      {
        path: "/signin",
        name: "Sign in",
        icon: <DocumentIcon color="inherit" />,
        component: SignIn,
        layout: "/auth",
      },
      {
        path: "/domain-detail/:_id",
        name: "Domain Detail",
        icon: <CreditIcon color="inherit" />,
        component: DomainDetail,
        layout: "/admin",
      },
      
      {
        path: "/signup/:token",
        name: "Sign up",
        icon: <DocumentIcon color="inherit" />,
        component: SignUp,
        layout: "/auth",
      }
    ],
  },
];
export default dashRoutes;
