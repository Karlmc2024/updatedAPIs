import React, { Component } from "react";
import Chart from "react-apexcharts";
import  donwloadicon from 'assets/img/download.png'
export default function PieChart(props) {
  let options = {
    chart: {
    width: 380,
    type: 'pie',
  },
  
title: {
    text: props.title,
    align: 'left',
    margin: 10,
    offsetX: 0,
    offsetY: 0,
    floating: false,
    style: {
      fontSize:  '14px',
      fontWeight:  'bold',
      fontFamily:  undefined,
      color:  '#263238'
    },
  },
  colors: [ '#5b35f9', "#24c0e3"],
  labels: props.labels,
  dataLabels: {
    position: 'top'
  },
  responsive: [{
    breakpoint: 480,
    options: {
      chart: {
        width: 300
      },
      legend: {
        position: 'bottom'
      }
    }
  }]
  };
  let series= props.series;

  return (
    <>
          <Chart
            options={options}
            series = {series}
            type="pie"
            width="400"
          />
    </>
  );
}

