import React, { Component } from "react";
import Chart from "react-apexcharts";
import donwloadicon from 'assets/img/download.png'
export default function BarChart(props) {
  let options = {
    responsive: [{
      breakpoint: 480,
      options: {
        chart: {
          width: 300
        },
        legend: {
          position: 'bottom'
        }
      }
    }],
    chart: {
      toolbar: {
        show: true,
        offsetX: 0,
        offsetY: 0,
        tools: {
          download: true,
          selection: true,
          zoom: true,
          zoomin: true,
          zoomout: true,
          pan: true,
          reset: true | '<img src="/static/icons/reset.png" width="20">',
          customIcons: []
        },
        export: {
          csv: {
            filename: `nexbloc-report-${new Date().getTime()}`,
            columnDelimiter: ',',
            headerCategory: 'category',
            headerValue: 'value',
            dateFormatter(timestamp) {
              return new Date(timestamp).toDateString()
            }
          },
          svg: {
            filename: `nexbloc-report-${new Date().getTime()}`,
          },
          png: {
            filename: `nexbloc-report-${new Date().getTime()}`,
          }
        },
        autoSelected: 'zoom'
      },
    },
    xaxis: {
      categories: props.xaxies
    },
    colors: ['#210592', '#00FF00'],

    title: {
      text: props.title,
      align: 'center',
      margin: 10,
      offsetX: 0,
      offsetY: 0,
      floating: false,
      style: {
        fontSize: '14px',
        fontWeight: 'bold',
        fontFamily: undefined,
        color: '#263238'
      },
    }
  }
  let series = props.yaxies;
  return (
    <>
      <Chart
        options={options}
        series={series}
        type="bar"
        width={props.width}
      />
    </>
  );
}

