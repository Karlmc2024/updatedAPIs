module.exports = {
  apps : [{
    name   : "admin-web",
    script : "./node_modules/react-scripts/scripts/start.js"
  }]
}
