import Web3 from "web3"
import registrar from './build/contracts/registrar.json'

export const getWeb3 = () => {
  return new Web3(Web3.givenProvider || 'http://localhost:7545');
}

export const getWeb3Account = (web3) => {
  return web3.eth.requestAccounts();
}

export const createZone = async({web3, sender, zoneName, zoneAddress ,gas}) => {
  let registrarInstance =  new web3.eth.Contract(registrar.abi, '0x2b90a6aE5204a5953a017F2163e1a7d8cB4b4848');
  return registrarInstance.methods.makeRequest(zoneName, zoneAddress).send({gas : gas,from : sender});
}

export const acceptZoneCreation = async({web3, sender, gas}) => {
  let registrarInstance =  new web3.eth.Contract(registrar.abi, '0x2b90a6aE5204a5953a017F2163e1a7d8cB4b4848');
  return registrarInstance.methods.giveApproval().send({gas : gas,from : sender});
}

export const rejectZoneCreation = async({web3, sender, gas}) => {
  let registrarInstance =  new web3.eth.Contract(registrar.abi, '0x2b90a6aE5204a5953a017F2163e1a7d8cB4b4848');
  return registrarInstance.methods.disapproveRequest().send({gas : gas,from : sender});
}


export const withdrawApproval = async({web3, sender, gas}) => {
  let registrarInstance =  new web3.eth.Contract(registrar.abi, '0x2b90a6aE5204a5953a017F2163e1a7d8cB4b4848');
  return registrarInstance.methods.withdrawApproval().send({gas : gas,from : sender});
}


export const getZone = async({web3, sender, gas}) => {
  let registrarInstance =  new web3.eth.Contract(registrar.abi, '0x2b90a6aE5204a5953a017F2163e1a7d8cB4b4848');
  return registrarInstance.methods.getRequest().send({gas : gas,from : sender});
}

export const getZoneAcceptCount = async({web3, sender, gas}) => {
  let registrarInstance =  new web3.eth.Contract(registrar.abi, '0x2b90a6aE5204a5953a017F2163e1a7d8cB4b4848');
  return registrarInstance.methods.getApprovalCount().send({gas : gas,from : sender});
}

export const getZoneRejectCount = async({web3, sender, gas}) => {
  let registrarInstance =  new web3.eth.Contract(registrar.abi, '0x2b90a6aE5204a5953a017F2163e1a7d8cB4b4848');
  return registrarInstance.methods.getDisapprovalCount().send({gas : gas,from : sender});
}
