# Change Log

## [1.0.1] 2021-09-13

### Update v1.0.1

- Added RTL Page
- Bug Fixing

## [1.0.0] 2021-08-20

### Original Release

- Added Chakra UI as base framework
