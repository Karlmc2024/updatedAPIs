import { mode } from "@chakra-ui/theme-tools";

export const globalStyles = {
  colors: {
    gray: {
      700: "#1f2733",
    },
    brand: {
      100: '#9d86fb',
      200: '#8c72fb',
      300: '#7c5dfa',
      400: '#6b49fa',
      500: '#5b35f9',
      600: '#5230e0',
      700: '#492ac7',
      800: '#4025ae',
      900: '#372095',
    },
  },
  styles: {
    global: (props) => ({
      body: {
        bg: mode("gray.50", "gray.800")(props),
        fontFamily: 'Helvetica, sans-serif'
      },
      html: {
        fontFamily: 'Helvetica, sans-serif'
      }
    }),
  },
};
