import React from 'react';
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
} from '@chakra-ui/react';

export default function BasicModal({
  OpenButton, FooterComponent, BodyComponent, header, isOpen, onClose,
}) {
  return (
    <>
      {OpenButton}

      <Modal
        isOpen={isOpen}
        onClose={onClose}
      >
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>{header}</ModalHeader>
          <ModalCloseButton />
          <ModalBody pb={6}>
            {BodyComponent}
          </ModalBody>

          <ModalFooter>
            {FooterComponent}
          </ModalFooter>
        </ModalContent>
      </Modal>
    </>
  );
}
