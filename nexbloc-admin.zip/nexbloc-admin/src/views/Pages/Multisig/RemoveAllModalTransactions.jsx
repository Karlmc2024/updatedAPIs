import React from 'react';
import {
  Button,
  useDisclosure,
  Text,
} from '@chakra-ui/react';
import BasicModal from 'components/Modal/Modal';

export default function RemoveAllModalTransactions() {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const BodyComponent = () => (
    <>
      <Text>
        Are you sure?
      </Text>
    </>
  );
  const FooterComponent = () => (
    <>
      <Button mr={3}>
        Yes
      </Button>
      <Button onClick={onClose} colorScheme="red">No</Button>
    </>
  );
  const OpenButton = () => (
    <Button onClick={onOpen} colorScheme="red">Remove all</Button>
  );
  return (
    <>
      <BasicModal BodyComponent={<BodyComponent />} header="Remove all transactions?" FooterComponent={<FooterComponent />} isOpen={isOpen} onOpen={onOpen} onClose={onClose} OpenButton={<OpenButton />} />
    </>
  );
}
