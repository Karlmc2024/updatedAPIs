import React from 'react';
import {
  Tabs, TabList, TabPanels, Tab, TabPanel, Stack,
} from '@chakra-ui/react';
import MyZones from './MyZones';

export default function Multisig() {
  const tabs = ['My Zones'];
  const tabPanels = [<MyZones />];
  return (
    <Stack width="full" bg="gray.50" height="full" minH="lg" mt="14">
      <Tabs variant="soft-rounded" p="4">
        <TabList>
          {tabs.map((tab) => <Tab>{tab}</Tab>)}
        </TabList>
        <TabPanels>
          {tabPanels.map((tabPanel) => <TabPanel>{tabPanel}</TabPanel>)}
        </TabPanels>
      </Tabs>
    </Stack>
  );
}
