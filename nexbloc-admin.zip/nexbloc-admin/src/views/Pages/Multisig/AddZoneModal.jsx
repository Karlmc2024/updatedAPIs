import React from 'react';
import {
  Button,
  useDisclosure,
  FormControl,
  FormLabel,
  Input,
  Flex,
} from '@chakra-ui/react';
import BasicModal from 'components/Modal/Modal';

export default function AddZoneModal() {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const BodyComponent = () => (
    <>
      <FormControl>
        <FormLabel>Zone Name</FormLabel>
        <Input placeholder="Zone name" />
      </FormControl>

      <FormControl mt={4}>
        <FormLabel>Zone Address</FormLabel>
        <Input placeholder="Zone Address" />
      </FormControl>
    </>
  );
  const FooterComponent = () => (
    <>
      <Button mr={3}>
        Save
      </Button>
      <Button onClick={onClose} colorScheme="red">Cancel</Button>
    </>
  );
  const OpenButton = () => (
    <Flex justifyContent="flex-end">
      <Button onClick={onOpen}>Add Zone</Button>
    </Flex>
  );
  return (
    <>
      <BasicModal BodyComponent={<BodyComponent />} header="Add Zone" FooterComponent={<FooterComponent />} isOpen={isOpen} onOpen={onOpen} onClose={onClose} OpenButton={<OpenButton />} />
    </>
  );
}
