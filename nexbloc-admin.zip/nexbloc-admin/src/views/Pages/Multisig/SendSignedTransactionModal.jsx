import React from 'react';
import {
  Button,
  useDisclosure,
  FormControl,
  FormLabel,
  Textarea,
} from '@chakra-ui/react';
import BasicModal from 'components/Modal/Modal';

export default function SendSignedTransactionModal() {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const BodyComponent = () => (
    <>
      <FormControl mt={4}>
        <FormLabel>Signed Transaction</FormLabel>
        <Textarea placeholder="Address" />
      </FormControl>
    </>
  );
  const FooterComponent = () => (
    <>
      <Button mr={3}>
        Save
      </Button>
      <Button onClick={onClose} colorScheme="red">Cancel</Button>
    </>
  );
  const OpenButton = () => (
    <Button onClick={onOpen}>Send signed transaction</Button>
  );
  return (
    <>
      <BasicModal BodyComponent={<BodyComponent />} header="Send signed transaction" FooterComponent={<FooterComponent />} isOpen={isOpen} onOpen={onOpen} onClose={onClose} OpenButton={<OpenButton />} />
    </>
  );
}
