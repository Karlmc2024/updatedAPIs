import React from 'react';
import {
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Stack,
} from '@chakra-ui/react';
import AddAddressModal from './AddZoneModal';

export default function AddressBook() {
  const addressBookData = [{
    name: 'something', address: 'sd', type: 'somet',
  }];
  return (
    <Stack spacing="8">
      <AddAddressModal />
      <Table variant="simple" boxShadow="sm" bg="white">
        <Thead>
          <Tr>
            <Th>Name</Th>
            <Th>Address</Th>
            <Th>Type</Th>
          </Tr>
        </Thead>
        <Tbody>
          {addressBookData.map(({
            name, address, type,
          }) => (
            <Tr>
              <Td>{name}</Td>
              <Td>{address}</Td>
              <Td>{type}</Td>
            </Tr>
          ))}
        </Tbody>
      </Table>
    </Stack>
  );
}
