import React from 'react';
import {
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Stack,
  HStack,
  Button
} from '@chakra-ui/react';
import AddZoneModal from './AddZoneModal';
import { MdDone, MdClose } from 'react-icons/md'

export default function MyZones() {
  const walletData = [{
    name: 'something', address: 'sd', requiredConfirmations: 'smo'
  }];
  return (
    <Stack spacing="8">
      <AddZoneModal />
      <Table variant="simple" boxShadow="md" bg="white">
        <Thead>
          <Tr>
            <Th>Name</Th>
            <Th>Address</Th>
            <Th>Required confirmations</Th>
            <Th>Actions</Th>
          </Tr>
        </Thead>
        <Tbody>
          {walletData.map(({
            name, address, requiredConfirmations
          }) => (
            <Tr>
              <Td>{name}</Td>
              <Td>{address}</Td>
              <Td>{requiredConfirmations}</Td>
              <Td>
                <HStack>
                  <Button leftIcon={<MdDone/>}>
                    Approve
                  </Button>
                  <Button leftIcon={<MdClose/>} colorScheme="red" variant="outline">
                    Reject
                  </Button>
                </HStack>
              </Td>
            </Tr>
          ))}
        </Tbody>
      </Table>
    </Stack>
  );
}
