import React from 'react';
import {
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Stack,
} from '@chakra-ui/react';
import GetNonceModal from './GetNonce';
import SendSignedTransactionModal from './SendSignedTransactionModal';
import RemoveAllModalTransactions from './RemoveAllModalTransactions';

export default function Transactions() {
  const transactionData = [{
    destination: 'something', value: 'sd', data: 'somet', nonce: 'smo', mined: 'something', logs: 'something',
  }];
  return (
    <Stack spacing="8">
      <Stack direction="row" justifyContent="flex-end">
        <GetNonceModal />
        <SendSignedTransactionModal />
        <RemoveAllModalTransactions />
      </Stack>
      <Table variant="simple" size="md" boxShadow="md" bg="white">
        <Thead>
          <Tr>
            <Th>Destination</Th>
            <Th>Value</Th>
            <Th>Data</Th>
            <Th>Nonce</Th>
            <Th>Mined</Th>
            <Th>Logs</Th>
            <Th>Remove</Th>
          </Tr>
        </Thead>
        <Tbody>
          {transactionData.map(({
            destination, value, data, nonce, mined, logs,
          }) => (
            <Tr>
              <Td>{destination}</Td>
              <Td>{value}</Td>
              <Td>{data}</Td>
              <Td>{nonce}</Td>
              <Td>{mined}</Td>
              <Td>{logs}</Td>
            </Tr>
          ))}
        </Tbody>
      </Table>
    </Stack>
  );
}
