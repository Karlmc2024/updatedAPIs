
module.exports = {
    REQUESTED_CODES: {
        SUCCESS: 'SUCCESS!',
        ERROR: 'ERROR!',
    },
    REQUIRED: ' is required!',
    NOT_VALID: ' is not valid!',
    DB_UPDATE_FAIL: 'Updating data into database failed!',
    EXISTS: ' is already exists with this ',
    NOT_EXISTS: ' does not exists with this ',
    INVALID_CREDENTIALS: 'Invalid user credentials!',
    INACTIVE: ' is not active',
    PASSWORD_ATTEMPTS_ERROR: 'Too many failed login attempts for this email. Please reset your password or contact support',
    HTTPS_OPTIONS: {
        hostname: 'localhost',
        port: 5000,
        path: '/user',
        method: 'GET',
        headers: {'Content-Type': 'application/json'}
    }
};
