'use strict';
import userRouter from './user-service/routes';
import domainRouter from './domain-service/routes';
import notificationRouter from './notification-service/routes';
import cartRouter from './cart-service/routes';
import transactionsRouter from './transaction-service/routes';
import orderRouter from './order-service/routes';
import premiumDomainRouter from './premium-domain/routes';
import tldRouter from './tld-api/routes';
import wishlistRouter from './wishlist-service/routes';
import blockChainRouter from './blockchain-proxy/routes';
import creditRouter from './credit-system/routes';
import tradeMarkRouter from './trademark-service/routes'
const express = require('express');
const router = express.Router();

const {AdminAuth} = require('./admin-service/Auth');
const adminRouter  = require('../api/admin-service/router');

router.use('/admin',  AdminAuth,  adminRouter);
router.use('/',userRouter);
router.use('/cart',cartRouter);
router.use('/domains',domainRouter);
router.use('/notifications',notificationRouter);
router.use('/orders',orderRouter);
router.use('/transactions',transactionsRouter);
router.use('/premium-domain',premiumDomainRouter);
router.use('/wishlist',wishlistRouter);
router.use('/tld',tldRouter);
router.use('/blockchain',blockChainRouter);
router.use('/credits',creditRouter);
router.use('/trademarks',tradeMarkRouter)

module.exports  = router;
