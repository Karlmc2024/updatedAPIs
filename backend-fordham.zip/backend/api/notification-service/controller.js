import {NotificationModel} from './model';


export const createNotification = async(req,res)=>{
    try {
        let {body} = req;
        let domain =  await NotificationModel(body).save();
        return res.status(201).json({data:domain});
    } catch (error) {
        return res.status(400).json({error});   
    }
};


export const getNotificationById = async(req,res)=>{
    try {
        let {id} = req.params;
        let domain =  await NotificationModel.findById(id);
        return res.status(200).json({data:domain});
    } catch (error) {
        return res.status(400).json({error});   
    }
};

export const deleteNotification = async(req,res)=>{
    try {
        let {id} = req.params;
        let domain =  await NotificationModel.deleteOne({_id:id});
        return res.status(200).json({data:domain});
    } catch (error) {
        return res.status(400).json({error});   
    }
};

export const updateNotification = async(req,res)=>{
    try {
        let {body,params} = body;
        let {id} = params;
        let domain =  await NotificationModel.updateOne({_id:id},body);
        return res.status(200).json({data:domain});
    } catch (error) {
        return res.status(400).json({error});   
    }
};
