

const router = require('express').Router();
import {createNotification,getNotificationById,deleteNotification,updateNotification} from './controller';

router.get('/');
router.post('/',createNotification);
router.get('/:id',getNotificationById);
router.put('/:id',updateNotification);
router.delete('/:id',deleteNotification);

export default router;
