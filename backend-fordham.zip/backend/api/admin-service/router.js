/************************ EXPRESS MODULES AND LIBRARIES *********************/
'use strict'
const express  = require('express');
const router = express.Router();

const {getUserReport, getUserDetails, searchUser, getuserDomains, getMonthlyUsersofCurruntyear, getUserCurruntMonthReport, getYearlyusers,getTodayusercount } = require('./controllers/user');
const {searchDomain, getDomainReport, getDomainDetail, gettodaydomaincount, getTotalBookedDoomains}  = require('./controllers/domain');
const {addPremiumDomain, getPremiumDomain, searchPremiumDomain , getPremiumDomainDetails} = require('./controllers/premium-domain');
const  {  getYearlysales , getCurrruntMonthSale , getCurruntyearMonthwiseSale, TotalSale, getSaleReport }  = require('./controllers/sales');
const {getTradeMarkRequests,updateTradeMarkRequestStatus,searchTradeMarkRequest, createTradeMark, getTradeMark, deleteTradeMark}=require('./controllers/trademark');
/**************************** USER  REPORT *************************************/
router.get('/users', getUserReport)
router.get('/search-user', searchUser);
router.get('/user-detail/:_id', getUserDetails);
router.get('/user-domains/:_id', getuserDomains);
router.get('/currunt-year-monthly-users', getMonthlyUsersofCurruntyear);
router.get('/user-yearly-report',getYearlyusers);
router.get('/currunt-month-users', getUserCurruntMonthReport);
router.get('/today-user-count', getTodayusercount);

/*************************** DOMAIN DETAIL REPORT  *****************************/
router.get('/domains', getDomainReport);
router.get('/domain-detail/:_id', getDomainDetail);
router.get('/search-domain',searchDomain);
router.get('/today-domain-count', gettodaydomaincount);
router.get('/total-book-domain', getTotalBookedDoomains);
/*************************** PREMIUM  DOMAIN  REPORT **************************/
router.get('/premium-domains/', getPremiumDomain);
router.post('/add-premium-domain', addPremiumDomain);
router.get('/premium-domain-detail/:_id',getPremiumDomainDetails);
router.get('/search-premium-domain', searchPremiumDomain);

/**************************** SALES REPORT  ****************************************/
router.get('/monthly-sale',getCurruntyearMonthwiseSale);
router.get('/yearly-sale-report', getYearlysales );
router.get('/currunt-month-sale',getCurrruntMonthSale);
router.get('/total-sale', TotalSale)
router.get('/sale-report' ,  getSaleReport  );
/*****************************TradeMark request */

router.post('/trademarks',createTradeMark)
router.get('/trademarks',getTradeMark)
router.delete('/trademarks/:id',deleteTradeMark)
router.get('/trademarks/request',getTradeMarkRequests)
router.get('/trademarks/request/search',searchTradeMarkRequest);
router.put('/trademarks/request/:id',updateTradeMarkRequestStatus);
/******************************** END *********************************************/

module.exports  = router;
