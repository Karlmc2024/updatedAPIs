const { TransactionModel } = require('../../transaction-service/model');


/********************************* SALES REPORT ******************************************/
const getYearlysales = async (req, res) => {
    try {
        const { startyear, endyear } = req.query;
        const start = new Date(startyear, 1, 1);
        const end = new Date(endyear, 12, 0);
        const result = await TransactionModel.aggregate([
            { $match: { createdAt: { $gte: start, $lte: end } } },
            {
                $project: {
                    year: { $year: "$createdAt" },
                    amount : 1
                }
            },
            {
                $group: {
                    _id: {
                        year: "$year",
                    },
                    amount: { $sum: "$amount" }
                }
            },
            { $sort: { "_id.year": 1 } },
            
        ])
        return res.status(200).json({ result });

    }
    catch (error) {
        
        return errorHandler(error, 400, res);
    }
}



/****************************** monthly joined sale in ucrrunt year *******************/
const getCurruntyearMonthwiseSale = async (req, res) => {
    try {
        const now = new Date();
        const { startmonth, endmonth } = req.query;
        const start = new Date(now.getFullYear(), startmonth, 1);
        const end = new Date(now.getFullYear(), Math.abs(endmonth), 0);
        const result = await TransactionModel.aggregate([
            { $match: { createdAt: { $gte: start, $lte: end } } },
            {
                $project: {
                    month: { $month: "$createdAt" },
                    year: { $year: "$createdAt" },
                    amount : 1
                }
            },
            {
                $group: {
                    _id: {
                        year: "$year",
                        month: "$month",
                    },
                    amount: { $sum: "$amount" }
                }
            },
            { $sort: { "_id.month": 1 } },
            
        ])
        return res.status(200).json({ result });
    }
    catch (error) {
        
        return errorHandler(error, 400, res);
    }
}
/************************************* GET DAY BY DAY SALE REPORT OF CURRUNT MONTH  **************/

const getCurrruntMonthSale = async (req, res) => {
    try {
        const { startdate, enddate } = req.query;
        const now = new Date();
        const start = new Date(now.getFullYear(), now.getMonth() , startdate);
        const end = new Date(now.getFullYear(), now.getMonth(), enddate);
        
        const result = await TransactionModel.aggregate([
            { $match: { createdAt: { $gte: start, $lte: end } } },
            {
                $project: {
                    dayOfMonth: { $dayOfMonth: "$createdAt" },
                    month: { $month: "$createdAt" },
                    year: { $year: "$createdAt" },
                    amount : 1
                }
            },
            {
                $group: {
                    _id: {
                        year: "$year",
                        month: "$month",
                        dayOfMonth: "$dayOfMonth"
                    },
                    amount: { $sum: "$amount" }
                }
            },
            { $sort: { "_id.dayOfMonth": 1 } },
            
        ])
        return res.status(200).json({ result });
    }
    catch (error) {
        
        return errorHandler(error, 400, res);
    }
}

const TotalSale  = async (req, res)=>{
    try{
        
        const result  = await TransactionModel.aggregate([
            { $group: { _id: null, amount: { $sum: "$amount" } } }
        ])
        if(result.length ==0 ){
             return res.status(200).json({ result: 0});
        }
        return  res.status(200).json({result:result[0].amount});
    }
    catch(error){
        return errorHandler(error , 400 , res);
    }
}

const getSaleReport  = async (req,res)=>{
    try{
        const { startdate, enddate } = req.query;
        const temp1 = new Date(startdate);
        const temp2 = new Date(enddate);
        const start = new Date(temp1.getFullYear(), temp1.getMonth() , temp1.getDate());
        const end = new Date(temp2.getFullYear(), temp2.getMonth(),  temp2.getDate());
        const result = await TransactionModel.aggregate([
            { $match: { createdAt: { $gte: start, $lte: end } } },
            {
                $lookup:
                {
                    from: "users",
                    localField: "userId",    // field in transation  collection
                    foreignField: "_id",
                    pipeline: [], // field in the  user collection
                    as: "user"
                }
            },
            { $project : {  "user.firstName": 1 , "user.lastName": 1 , "user.phone": 1, "user.email": 1 , amount : 1 ,currency: 1, paymentStatus : 1 , transactionDate: 1 , createdAt: 1 , }},
            { $sort: { "createdAt": 1 } }        
        ])
        return res.status(200).json({ result }); 

    }
    catch(error){
        return errorHandler(error , 400, res);
    }
}

module.exports  = { getYearlysales , getCurrruntMonthSale , getCurruntyearMonthwiseSale, TotalSale, getSaleReport };