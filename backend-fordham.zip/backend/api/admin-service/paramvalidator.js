const joi  = require('@hapi/joi');
const {UserModel } = require('../user-service/model');
import errorHandler from '@lib/utils/error';

const validateUserid  =  async  (req ,res, next)=>{
    try{
        if(req.params._id){
            const userid  = req.params._id;
           const isuser  =  await UserModel.findById(userid);
           if(isuser){
                req.user  = isuser;
                next();
           }
           else{
               return errorHandler({message:"User id required"}, 400, res);
           }
        }
        else{
            return errorHandler(error , 400, res);
        }
         
    }
    catch(error){
        return errorHandler(error , 400, res); 
    }
}


module.exports = { validateUserid}