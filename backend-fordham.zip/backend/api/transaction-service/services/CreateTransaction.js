/* eslint-disable new-cap */
/* eslint-disable camelcase */
import {TransactionModel} from '../model';
const {stripe_key} = require('./constants');
import CoinbaseService from './CoinbaseService';
const stripe = require('stripe')(stripe_key);

export const createTransaction = async (paymentGateway,  finalAmount,currency, userId,req) => {
  let transactionInfo = null;
  let transactionId = null;

  switch (paymentGateway) {
    case 'coinbase':
      transactionInfo = await CoinbaseService.charge({
        name: 'Credit Purchase',
        description: 'Transaction for credit purchase-' + userId,
        local_price: {
          amount: finalAmount,
          currency: currency,
        },
        pricing_type: 'fixed_price',
      });
      transactionId = transactionInfo.id;
      break;
      case 'stripe':
        transactionInfo = await stripe.paymentIntents.create({
          amount: finalAmount * 100,
          currency: currency ,
          description: 'Credit Purchase-' + userId,
          shipping: {
            name: req.me.firstName + ' ' + req.me.lastName,
            address: req.me.resAddress
          }
        });
        transactionId = transactionInfo.id;
        break;
    case 'zeroPayment':
      transactionInfo = {};
      transactionId = new Date().getTime();
      break;
  }
  return await TransactionModel({
    userId,
    amount: finalAmount,
    currency: currency,
    paymentMode: paymentGateway,
    txHash: transactionId,
    status:  'initiated',
    paymentStatus: 'created',
    transactionDate: new Date().getUTCDate(),
    transactionInfo,
    itemsStatus: []
  }).save();
};
