var {stripe_key, paymentStatus} = require('./constants');


let StripeService = {};

StripeService.charge = function (chargeData) {
  return new Promise((resolve, reject) => {
    // Charge.create(chargeData, function (error, response) {
    //   if (error) return Promise.reject(error);
    //   return Promise.resolve(response);
    // });
  });
};

StripeService.events = {
  'charge.created': paymentStatus.CREATED,
  'payment_intent.created': paymentStatus.CREATED,
  'charge.succeeded': paymentStatus.CONFIRMED,
  'charge.payment_failed': paymentStatus.FAILED,
  'charge.canceled': paymentStatus.CANCELED,
  'charge:processing': paymentStatus.PROCESSING,
  'payment_intent.requires_action': paymentStatus.PROCESSING,
  'charge:requires_action': paymentStatus.REQUIRES_ACTION,
  'payment_intent.succeeded': paymentStatus.PROCESSING,
};

module.exports = StripeService;
