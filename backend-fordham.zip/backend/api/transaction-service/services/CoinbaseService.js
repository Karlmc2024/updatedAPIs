const coinbase = require('coinbase-commerce-node');

const compare = require('secure-compare');
const crypto = require('crypto');
const {coinbase_key, coinbaseWebhookSecret, paymentStatus} = require('./constants');
const Client = coinbase.Client;

Client.init(coinbase_key);
const Charge = coinbase.resources.Charge;
let CoinbaseService = {};

CoinbaseService.charge = function (chargeData) {
  return new Promise((resolve, reject) => {
    Charge.create(chargeData, function (error, response) {
      if (error) {
      return reject(error);
}
      return resolve(response);
    });
  });
};

CoinbaseService.parseHook = function rawBody(req, res, next) {
  req.setEncoding('utf8');
  let payload = JSON.stringify(req.body);
  let hash = crypto
    .createHmac('sha256', coinbaseWebhookSecret)
    .update(payload, 'utf8')
    .digest('hex');
  if (compare(hash, req.headers['x-cc-webhook-signature'])) {
    next();
  } else {
    res.status(401).send({});
  }
};

CoinbaseService.events = {
  'charge:created': paymentStatus.CREATED,
  'charge:confirmed': paymentStatus.CONFIRMED,
  'charge:failed': paymentStatus.FAILED,
  'charge:delayed': paymentStatus.DELAYED,
  'charge:pending': paymentStatus.PENDING,
  'charge:resolved': paymentStatus.RESOLVED,
};

module.exports = CoinbaseService;
