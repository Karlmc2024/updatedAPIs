var {paypal_key} = require('./constants');
var {paymentStatus} = require('./constants');

let PaypalService = {};

PaypalService.charge = function (chargeData) {
  return new Promise((resolve, reject) => {
    // Charge.create(chargeData, function (error, response) {
    //   if (error) return Promise.reject(error);
    //   return Promise.resolve(response);
    // });
  });
};

PaypalService.events = {
  'CHECKOUT.ORDER.APPROVED': paymentStatus.CREATED,
  'PAYMENT.CAPTURE.COMPLETED': paymentStatus.CONFIRMED,
  'CHECKOUT.ORDER.COMPLETED': paymentStatus.CONFIRMED,
  'PAYMENT.CAPTURE.DENIED': paymentStatus.CANCELED,
  'PAYMENT.ORDER.CANCELLED': paymentStatus.CANCELED,
  'PAYMENT.CAPTURE.PENDING': paymentStatus.PENDING,
  'PAYMENT.CAPTURE.REVERSED': paymentStatus.RESOLVED,
};

module.exports = PaypalService;
