'use strict';
import mongoose from 'mongoose';
const objectId = mongoose.Schema.Types.ObjectId;

const trademarkSchema = new mongoose.Schema({
    tradeMarkName: {type: String,required: true,unique:true},
    searchCount: {type: Number,required: false,default:0},
});

const trademarkRequestSchema = new mongoose.Schema({
    name: {type: String,required: true},
    email: {type: String,required: true},
    designation:{type:String,required:false},
    phoneNumber:{type:String,required:false},
    userId: {type: objectId,required: true},
    trademark: {type: objectId,required: true},
    tld: {type: objectId,required: true},
    price: {type: Number,required: false,default:0},
    paymentUrl: {type: String,required: false},
    status:{type: String,required: false,default:'pending',enum:['pending','review','rejected','resolved']},
    message: {type: String,required: false},
    domainName:{type:String,required:true},
    company:{type:String,required:false},
    hubspotTicketId:{type:String,required:false}
});

export const trademarkRequestModel = mongoose.model('trademark-request', trademarkRequestSchema);

export const TradeMarkModel = mongoose.model('trademark', trademarkSchema);
