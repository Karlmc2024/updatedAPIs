'use strict'

// error handler 

const ErrorHandler  = (error, res)=>{
    return res.status(400).json({message : error.message });
}
module.exports = {ErrorHandler};
