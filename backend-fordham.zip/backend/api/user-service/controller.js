import {createCart} from '../cart-service/services';
import {UserModel} from './model';
import {ForgotPasswordModel} from './forgotPassword.model';
import {createWishlist} from '../wishlist-service/service';
import {sendEjsEmail} from '../../lib/utils/email';
import errorHandler from '@lib/utils/error';
import { ProductDomainModel } from '../domain-service/model';
import { generateRefercode, handelReferUser } from '../refer-service/controller';
const bcrypt = require('bcrypt');
const randtoken = require('rand-token');
const { getLoginDetails } = require('./service');
const ejs = require('ejs');
const fs = require('fs');
const path = require('path');
const { OAuth2Client } = require('google-auth-library');
const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);
const {addNexbToeknsOnSignup} = require('./service');

const axios = require('axios');
const { createContact } = require('../../lib/utils/hubspot');

const generateLink = (req, userId, token) => {
  let { origin } = req.headers;
  return origin + '/verify-account/' + userId + '/' + token;
};


const userSignup = async (req, res) => {
  try {
    let token = null;
    let {body} = req;
    // if (body.email){
    //   let mailType = body.email.split('@')[1];
    //   let isValid = ['iotric.com','nexbloc.com','avrilar.com'].includes(mailType);
    //   if (!isValid) {
    //     return res.status(400).json({
    //       error: 'Invalid Email Account',
    //     });
    //   }
    //
    // }
    let find = await UserModel.findOne({email: body.email}, {});
    if (find && find.email) {
      return res.status(400).json({
        error: 'Account Already Exist With Given Email, Please Login',
      });
    }
    if (!body.fromSSO) {
      token = randtoken.generate(32);
      body.emailVerifyUrl = token;
    } else {
      body.verified = true;
    }

    let user = await UserModel(body).save();
    const {email} = user;

    await createCart(user._id);
    await createWishlist(user._id);

    if (user) {
      let filePath = path.resolve(
          __dirname + '../../../lib/utils/templates/welcome.ejs'
          ),
          compiled = ejs.compile(fs.readFileSync(filePath, 'utf8')),
          dataToCompile = {
            name: user.firstName,
          },
          Subject = 'Welcome to NexBloc';

      if (token !== null) {
        let verifyEmailTemplate = path.resolve(
            __dirname + '../../../lib/utils/templates/verify-email.ejs'
            ),
            email_compiled = ejs.compile(
                fs.readFileSync(verifyEmailTemplate, 'utf8')
            ),
            emailDataToCompile = {
              name: user.firstName,
              link: generateLink(req, user._id, token),
            };

        sendEjsEmail(
            email,
            user.firstName,
            'Email Verification Request',
            email_compiled(emailDataToCompile)
         );
      }
      sendEjsEmail(email, user.firstName, Subject, compiled(dataToCompile));

      //todo add check if env is production than only add data to contacts
      await createContact({
        firstName: body.firstName,
        lastname: body.lastName,
        email: body.email,
      });

      return res.status(201).json({result: 'Signup Successful'});
    }
    return res.status(400).json({result: 'Something Went Wrong'});
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

const userProfile = async (req, res) => {
  try {
    let user = await UserModel.findOne(
        {_id: req.locals.user._id},
        {secretKey: 0, otp: 0}
    );
    if (user) {
      user = user.toJSON();
      delete user.password;
      delete user.emailVerifyUrl;
      const userDomains = await ProductDomainModel.find({userId: user._id});
      user.totalDomains = userDomains.length || 0;
      return res.status(200).json({result: user});
    }
    return res.status(400).json({error: 'Something Went Wrong'});
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

const userUpdate = async (req, res) => {
  try {
    let body = req.body;
    let user = await UserModel.findOneAndUpdate(
        {_id: req.locals.user._id},
        body,
        {new: true}
    );
    if (user) {
      user = user.toJSON();
      delete user.password;
      delete user.emailVerifyUrl;
      const userDomains = await ProductDomainModel.find({userId: user._id});
      user.totalDomains = userDomains.length || 0;
      return res.status(201).json({result: user});
    }
    return res.status(400).json({error: 'Something Went Wrong'});
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

const resendVerifyEmail = async (req, res) => {
  try {
    let token = randtoken.generate(32);
    let user = await UserModel.findOneAndUpdate(
        {_id: req.locals.user._id},
        {emailVerifyUrl: token},
        (err, docs) => {
          if (err || !docs) {
            return errorHandler(
                {error: 'Email Verification Request Failed'},
                401,
                res
            );
          }
        }
    );

    let verifyEmailTemplate = path.resolve(
        __dirname + '../../../lib/utils/templates/verify-email.ejs'
        ),
        emailCompiled = ejs.compile(fs.readFileSync(verifyEmailTemplate, 'utf8')),
        emailDataToCompile = {
          name: user.firstName,
          link: generateLink(req, user._id, token),
        };

    await sendEjsEmail(
        user.email,
        user.firstName,
        'Subject',
        emailCompiled(emailDataToCompile)
    );
    return res
        .status(200)
        .json({result: 'Email verification link has been sent'});
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

const verifyAccount = async (req, res, next) => {
  try {
    const {token, userId} = req.params;
    let user = await UserModel.findOne({_id: userId}, {});

    if (!user) {
      return errorHandler({error: 'Invalid Verification Link'}, 401, res);
    }

    if (user && user.verified) {
      return res.status(200).json({result: true});
    }

    // eslint-disable-next-line security/detect-possible-timing-attacks
    if (token === user.emailVerifyUrl) {
      await UserModel.findOneAndUpdate(
          {_id: userId},
          {verified: true},
          (err, docs) => {
            if (err || !docs) {
              return errorHandler(
                  {error: 'Invalid Verification Link'},
                  401,
                  res
              );
            }
          }
      );

      addNexbToeknsOnSignup(userId)
      return res.status(200).json({result: true});
    }
    return errorHandler({error: 'Invalid Verification Link'}, 401, res);
  } catch (err) {
    return errorHandler(err, 401, res);
  }
};

const userLogin = async (req, res) => {
  try {
    let {email, password} = req.body;

    let user = await UserModel.findOne({email});
    if (!user) {
      return res.status(400).json({error: 'Incorrect Email or Password'});
    }
    const correctPassword = await bcrypt.compare(password, user.password);
    if (!correctPassword) {
      return res.status(400).json({error: 'Incorrect Email or Password'});

    }
    const loginDetails = await getLoginDetails(user);
    return res.status(200).json({result: loginDetails});
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

const verify = async (req, res) => {
  try {
    return res.status(200).json({result: req.locals.user});
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

const resetPassword = async (req, res) => {
  try {
    const {token, userId} = req.params;
    const {password} = req.body;
    const user = await UserModel.findById(userId);
    if (!user) {
      return res.status(400).send({error: 'invalid link or expired'});
    }
    const forgotPassword = await ForgotPasswordModel.findOne({
      userId: user._id,
      token: req.params.token,
    });
    if (!token) {
      return res
          .status(400)
          .send({error: 'Link  has been expired or invalid link'});
    }
    user.password = password;
    await user.save();
    await forgotPassword.delete();

    res.status(200).json({result: 'password reset successfully.'});
  } catch (err) {
    return errorHandler(err, 401, res);
  }
};

const changePassword = async (req, res) => {
  try {
    const userId = req.me._id;
    const {password} = req.body;
    const user = await UserModel.findById(userId);
    user.password = password;
    await user.save();

    res.status(200).json({result: 'password reset successfully.'});
  } catch (err) {
    return errorHandler(err, 401, res);
  }
};

const forgotPassword = async (req, res) => {
  try {
    const {email} = req.body;
    let {origin} = req.headers;
    const user = await UserModel.findOne({email: email});

    if (!user) {
      return errorHandler(
          {message: 'No account exists with a given email'},
          400,
          res
      );
    }
    let {_id: userId} = user;
    let token = await ForgotPasswordModel.findOne({userId});
    if (!token) {
      token = await new ForgotPasswordModel({
        userId,
        token: randtoken.generate(16),
      }).save();
    }
    let link = origin + '/reset-password/' + userId + '/' + token.token;
    let filePath = path.resolve(
        __dirname + '../../../lib/utils/templates/forgot-password.ejs'
        ),
        compiled = ejs.compile(fs.readFileSync(filePath, 'utf8')),
        dataToCompile = {
          link: link,
          toName: user.firstName,
        },
        Subject = 'Reset Password Link';

    sendEjsEmail(email, user.firstName, Subject, compiled(dataToCompile));

    // let emailSentResult = await sendEmail({to:email,subject:'Reset Password Link',text:`Please use the below link to reset your password ${link}`});
    res.status(200).json({
      result: 'Please check your email for the reset link',
    });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

const googleSignup = async (req, res) => {
  try {
    let {profileObj} = req.body;

    async function verify() {
      const ticket = await client.verifyIdToken({
        idToken: req.body.tokenId,
        audience: process.env.GOOGLE_CLIENT_ID,  // Specify the CLIENT_ID of the app that accesses the backend
      });
      const payload = ticket.getPayload();
      return payload
    }

    verify()
        .then(async (data)=>{
              if (profileObj.email === data.email && data.email_verified) {
                let user = await axios.post(process.env.URL + '/api/signup', {
                  email: profileObj.email,
                  firstName: profileObj.givenName,
                  lastName: profileObj.familyName,
                  password: profileObj.googleId,
                  fromSSO: 'google'
                }, {
                  headers: {
                    origin: req.headers.origin
                  }
                })

                //let userData = await UserModel.findOne({email:profileObj.email },{_id:1})
                // addNexbToeknsOnSignup(userData._id);

                return res.status(201).json({result: 'Signup Successful'});
              } else {
                return errorHandler(
                    {
                      error: 'Google auth expired',
                    },
                    400,
                    res
                );
              }
            }
        )
        .catch((e)=> {
          return errorHandler(e.error || e.response.data, 401, res);
        });

  } catch (e) {
    return errorHandler(e.error || e.response.data, 401, res);
  }
};

const googleLogin = async (req, res) => {
  try {
    let {profileObj} = req.body;

    async function verify() {
      const ticket = await client.verifyIdToken({
        idToken: req.body.tokenId,
        audience: process.env.GOOGLE_CLIENT_ID,  // Specify the CLIENT_ID of the app that accesses the backend
      });
      const payload = ticket.getPayload();
      return payload
    }
    verify()
        .then(async (data)=>{
              if (profileObj.email === data.email && data.email_verified) {
                let user = await UserModel.findOne({email: data.email});
                if (!user) {
                  return errorHandler(
                      {message: 'Incorrect Email or Password'},
                      400,
                      res,
                      false
                  );
                }
                const loginDetails = await getLoginDetails(user);
                return res.status(200).json({result: loginDetails});
              } else {
                return errorHandler(
                    {
                      error: 'Google auth expired',
                    },
                    400,
                    res
                );
              }
            }
        )
        .catch(console.error);

  } catch (e) {
    
    logger.error(e)
    return errorHandler(e.error || e.response.data, 401, res);
  }
};


module.exports = {
  userSignup,
  verifyAccount,
  userLogin,
  userUpdate,
  userProfile,
  verify,
  resetPassword,
  forgotPassword,
  googleSignup,
  googleLogin,
  resendVerifyEmail,
  changePassword,
};
