const router = require('express').Router();
const {validateUserSignUp,validateUserLogin,verifyAccount} = require('./validator');
const  {UserController} = require('@api/controllers');
const { validate}  =require('./apivalidator');

router.post('/signup',validateUserSignUp,UserController.userSignup);
router.post('/login',validateUserLogin,UserController.userLogin);
router.get('/verify-account/:userId/:token',verifyAccount, UserController.verifyAccount);
router.get('/verify', UserController.verify);
router.put('/user',UserController.userUpdate);
router.get('/user',UserController.userProfile);
router.put('/reset-password/:userId/:token',verifyAccount, UserController.resetPassword);
router.put('/change-password', UserController.changePassword);
router.post('/forgot-password',UserController.forgotPassword);
router.post('/resend-verification-email',UserController.resendVerifyEmail);

router.post('/google-signup', UserController.googleSignup);

router.post('/google-login', UserController.googleLogin);

module.exports = router;
