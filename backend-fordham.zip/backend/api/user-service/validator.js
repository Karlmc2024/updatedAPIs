const Joi = require('@hapi/joi');

const getToken = (req, res, next) => {
    const schema = Joi.object({
        refreshToken: Joi.string().required(),
        userId: Joi.string().required()
    });
    const {error} = schema.validate(req.body);
    if (error) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        logger.error('error', message);
        return res.status(400).json({error:{message:message}});
    }
    next();
};


const updateUser = (req, res, next) => {
    const schema = Joi.object({
        firstName: Joi.string(),
        lastName: Joi.string(),
    });
    const {error} = schema.validate(req.body);
    if (error) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        logger.error('error', message);
        return res.status(400).json({error:{message:message}});
    }
    next();
};

const forgotPassword = (req, res, next) => {
    const schema = Joi.object({
        email: Joi.string().required()
    });
    const {error} = schema.validate(req.query);
    if (error) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        logger.error('error', message);
        return res.status(400).json({error:{message:message}});
    }
    next();
};

const resetPassword = (req, res, next) => {
    const schema = Joi.object({
        password: Joi.string().pattern(/(?=^.{8,64}$)(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&])(?!.*\s).*$/).required(),
        confirmPassword: Joi.string().pattern(/(?=^.{8,64}$)(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&])(?!.*\s).*$/).required()
    });
    const {error} = schema.validate(req.body);
    if (error) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        logger.error('error', message);
        return res.status(400).json({error:{message:message}});
    }
    next();
};

const changePassword = (req, res, next) => {
    const schema = Joi.object({
        password: Joi.string().required(),
        newPassword: Joi.string().pattern(/(?=^.{8,64}$)(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&])(?!.*\s).*$/).required()
    });
    const {password, newPassword} = req.body;
    const {error} = schema.validate({password, newPassword});
    if (error) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        logger.error('error', message);
        return res.status(400).json({error:{message:message}});
    }
    next();
};

const params = (req, res, next) => {
    const schema = Joi.object({
        userId:  Joi.string().required()
    });
    const {error} = schema.validate(req.params);
    if (error) {
        return res.status(400).json({error: {message:'User Id is missing'}});
    }

    next();
};

const resetPasswordParam = (req, res, next) => {
    const schema = Joi.object({
        resetId:  Joi.string().required()
    });
    const {error} = schema.validate(req.params);
    if (error) {
        return res.status(400).json({error: {message:'resetId is missing'}});
    }
    next();
};

const validateUserSignUp = (req, res, next) => {
        const schema = Joi.object({
            password: Joi.string().pattern(/(?=^.{6,64}$)(?=.*\d)(?!.*\s).*$/).required(),
            email: Joi.string().pattern(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/).required(),
            referBy : Joi.string().allow(null).optional(),
            firstName: Joi.string().required(),
            lastName: Joi.string().required(),
            address:Joi.array().items(Joi.object({
                address: Joi.string().required(),
                alias: Joi.string().required(),
            })),
            fromSSO: Joi.string()
        });
        let {error} = schema.validate(req.body);
        if (error && error.details) {
            const {details} = error;
            const message = details.map(i => i.message).join(',');
            return res.status(400).json({error:message});
        }
    next();
};

const validateUserLogin = (req, res, next) => {
    const schema = Joi.object({
        password: Joi.string().required(),
        email: Joi.string().required(),
    });
    let {error} = schema.validate(req.body);
    if (error && error.details) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        return res.status(400).json({error:message});
    }
next();
};

const verifyAccount = (req, res, next) => {
    const schema = Joi.object({
        userId: Joi.string().required(),
        token: Joi.string().required(),
    });
    const {error} = schema.validate(req.params);
    if (error && error.details) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        return res.status(400).json({error:message});
    }
    next();
};


module.exports = {
    validateUserSignUp,
    validateUserLogin,
    verifyAccount
};




