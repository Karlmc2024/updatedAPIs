'use strict';

/**
 * Import All Controller Here
 */

const UserController            = require('./user-service/controller');
const TldListController         = require('./tld-api/controller');

module.exports = {
    UserController:UserController,
    TldListController
};
