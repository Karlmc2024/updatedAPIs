import {TldModel} from './model';
import errorHandler from '@lib/utils/error';

export const getTld = async(req,res)=>{
    try {
        let tld =  await TldModel.find({});
        return res.status(200).json({result:tld});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};

export const isMintable = async(req,res)=>{
    try {
        let {tldName} = req.params;
        let tld =  await TldModel.findOne({tldName:tldName});
        let mintStatus = tld.mintable;
        return res.status(200).json({result:mintStatus});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};

// export const addTld = async(req,res)=>{
//     try {
//         let tld =  await TldModel.insertMany({});
//         return res.status(200).json({result:tld});
//     } catch (error) {
//         return errorHandler (error,400,res);
//     }
// };
