const  {TldModel} = require('./model');

let tld = [
    {
        tldName: '.lern',
        active: true,
    },
    {
        tldName: '.w3c',
        active: false,
    },
    {
        tldName: '.xdc',
        active: false,
    }
];

function doMigration () {
    TldModel.remove({},(err) => {
        if (err) {
            
        } else {
            try {
                tld.forEach(async (data, index)=> {
                    if (index <= tld.length - 1) {
                        
                        let docs = await  TldModel(data).save();
                        if (index === tld.length - 1) {
                            
                            process.exit(1);
                        }
                    }
                });
            } catch (e){
                
            }
        }
    });
}

doMigration();

module.exports = tld;
