
const router = require('express').Router();
import {addItemToWishlist, clearWishlist, deleteWishlistItem, getMyWishlist, updateWishlist,moveToCart} from './controller';


// get all cart items
// clear items
// delete one item
// add one item
router.get('/',getMyWishlist);
// router.delete('/:id',clearWishlist);
router.post('/',addItemToWishlist);
router.delete('/:itemId',deleteWishlistItem);
router.put('/',updateWishlist);
router.put('/:itemId/move-to-cart',moveToCart);

export default router;
