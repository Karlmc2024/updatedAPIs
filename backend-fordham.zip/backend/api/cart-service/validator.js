const Joi = require('@hapi/joi');

const addToCart = (req, res, next) => {
    const schema = Joi.array().items(Joi.object({
        domainName: Joi.string(),
        price: Joi.number()
    }));
    const {error} = schema.validate(req.body);

    if (error) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        logger.error('error', message);
        return res.status(400).json({error:{message:message}});
    }
    next();
};

const updateCart = (req, res, next) => {
    const schema = Joi.object({
        domainName: Joi.string(),
        price: Joi.number(),
    });
    const {error} = schema.validate(req.body);

    if (error) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        logger.error('error', message);
        return res.status(400).json({error:{message:message}});
    }
    next();
};

const params = (req, res, next) => {
    const schema = Joi.object({
        sessionId:  Joi.string().required()
    });
    const {error} = schema.validate(req.params);
    if (error) {
        return res.status(400).json({error: {message:'User Id is missing'}});
    }
    next();
};

module.exports = {
    addToCart,
    updateCart,
    params
};
