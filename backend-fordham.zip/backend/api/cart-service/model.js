'use strict';
import mongoose from 'mongoose';
const objectId = mongoose.Schema.Types.ObjectId;

const itemSchema = new mongoose.Schema({
    domainName: {type: String,required: true},
    productId: {type: objectId, required: false},
    price: {type: Number,default:true},
    tld        : {type: objectId},
});

const CartSchema = new mongoose.Schema({
  items                 : [itemSchema],
  totalQuantity         : {type: Number, required: true},
  totalCost             : {type: String, required: true},
  currency              : {type: String, required: true, default: 'usd'},
  userId                : {type: objectId, required: false,unique:true, ref:'User'},
  currentOrderId        : {type: objectId},
  
}, {timestamps: true, versionKey: false});

export const CartModel = mongoose.model('Cart', CartSchema);
