import {ethers} from 'ethers';
import {sendTransaction} from './services';

export const getResolveURL = async(req,res)=>{
  // needs to send following parameters to the blockchain
  
  res.send('getResolveURL');
};

export const createResolveURL = async(req,res)=>{
  res.send('Create ResolveURL');
};

export const getResolveAddress = async(req,res)=>{
   // needs to send following parameters to the blockchain
  //input
   // token_id
  // currency -- array
  // output 
  // addresses -- array

  res.send('getResolve address');
};

export const createResolveAddress = async(req,res)=>{
   // needs to send following parameters to the blockchain
  //  -- input
  //  token_id
  //  currency -- array
  //  addresses -- array
  res.send('Create Resolve Address');
};

export const greeter = async(req,res)=>{
  const {address, privateKey} = req.body;
  const abi = [
    {
      'inputs': [
        {
          'internalType': 'string',
          'name': '_greeting',
          'type': 'string'
        }
      ],
      'stateMutability': 'nonpayable',
      'type': 'constructor'
    },
    {
      'inputs': [],
      'name': 'greet',
      'outputs': [
        {
          'internalType': 'string',
          'name': '',
          'type': 'string'
        }
      ],
      'stateMutability': 'view',
      'type': 'function'
    },
    {
      'inputs': [
        {
          'internalType': 'string',
          'name': '_greeting',
          'type': 'string'
        }
      ],
      'name': 'setGreeting',
      'outputs': [],
      'stateMutability': 'nonpayable',
      'type': 'function'
    }
  ];
  const transaction = await sendTransaction({address,abi,privateKey,value:ethers.utils.parseEther('0.1')});
  return res.send(transaction);
};
