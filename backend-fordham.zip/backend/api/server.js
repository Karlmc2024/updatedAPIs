'use strict';
import express from 'express';
// import createRoutes from './routes';
import serverSetup from '../middleware/express-setup';
import errorHandlerFunc from '../middleware/error-handler';
import startSwagger from '../middleware/start-swagger';
import authenticator from '../middleware/authentication';
/**
 * Module dependencies
 */

require('module-alias/register');
require('@env/index');
require('../lib/logger/logger');

const app = express();

/**
 * Start Node Server
 */

require('../middleware/start-server')(app);

// authenticator(app);
/**
 * Initialize Express
 */

require('../middleware/express-setup')(app);
require('../middleware/express-router')(app);

serverSetup(app);
errorHandlerFunc(app);
/**
 * Connect routes
 */

//  createRoutes(app); 


/**
 * Initialize MongoDB Collections
 */
require('./model');

/**
 * Initialize Swagger Docs
 */
 startSwagger(app);

require('../lib/rollbar');


export {
    app
};
