'use strict';
import mongoose from 'mongoose';

const PremiumDomainSchema = new mongoose.Schema(
  {
    domainName: {type: String, required: true},
    price: {type: Number, required: true},
    currency: {type: String, require: true},
    soldOut: {type: Boolean, default: false}
  },
  {timestamps: true, versionKey: false}
);

export const PremiumDomainModel = mongoose.model(
  'PremiumDomain',
  PremiumDomainSchema
);
