/* eslint-disable max-statements */
import {ProductDomainModel} from './model';
import {PremiumDomainModel} from '../premium-domain/model';
import {LockedDomainModel} from '../order-service/model';
const ud = require('urban-dictionary');
import errorHandler from '@lib/utils/error';
import {TradeMarkModel} from '../trademark-service/model';
import {TldModel} from '../model';

 const calculateValue = async (text,domainName,tld) => {
    if (!text) {
    return {};
    }

    let ifPremiumDomain = await PremiumDomainModel.find({domainName: domainName});
    if (ifPremiumDomain.length > 0) {
        return ({price:ifPremiumDomain[0].price,isPremium:true});
    }

     if(tld.basePrice === 0) {
         return ({price:0,isPremium:false});
     }

    let price = tld.basePrice || 50;


    let domainLength  = text.length;
    let isDomainMeaningful = false;
     await ud.autocomplete(text).then((results) => {
         isDomainMeaningful = true;

     }).catch((error) => {
         console.error(`autocomplete (promise) - error ${error.message}`);
     });

    if (domainLength < 6) {
        price = price * 1;
    } else if (domainLength < 9 ){
        price = price-15;
    } else if (domainLength < 12 ){
        price = price-20;
    } else if (domainLength < 15 ){
        price = price-25;

    } else {
        price = price-30;
    }

     if (isDomainMeaningful) {
         price =  price +  10;
     }

    return ({price:price,isPremium:false});
};

export const createDomain = async(req,res) => {
    try {
        let {body} = req;
        let domain =  await ProductDomainModel(body).save();
        return res.status(201).json({data:domain});
        } catch (error) {
        return errorHandler (error,400,res);
    }
};

export const searchDomain = async(req,res) => {
    try {
        let domainText = req.query.domainName.split('.')[0];
        let tldName = req.query.domainName.split('.')[1];
        let tld = await TldModel.findOne({tldName:'.'+tldName},{})
        let domainName = req.query.domainName;
        let domainValue = await calculateValue(domainText,domainName,tld);
        let domainNameRegex = `^${domainName}$`;
        let domain =  await ProductDomainModel.findOne({domainName:{'$regex':domainNameRegex,'$options':'i'}});
        let isAvaliable = domain ? false : true;
        if (!isAvaliable) {
            return res.status(200).json({result:{domainName,available:isAvaliable}});
        }
        let tradeMark = await TradeMarkModel.findOne({tradeMarkName:{'$regex':domainText,'$options':'i'}});
        
        if (tradeMark) {
            tradeMark.searchCount = tradeMark.searchCount + 1;
            await tradeMark.save();
            return res.status(200).json({result:{domainName,isDomainTradeMarked: true, available: true}});
        }

        let ifDomainLocked = await LockedDomainModel.findOne({domainName:{'$regex':domainNameRegex,'$options':'i'}});
        if (ifDomainLocked) {
            return res.status(200).json({result:{domainName,available:false}});
        }
        //todo generate a productID
        let obj = {
            isPremium: domainValue.isPremium,// will be done on Blockchain API
            domainName,
            price : domainValue.price,
            available : isAvaliable,
            wishlisted: false,
            premiumObj: {},
        };
        return res.status(200).json({result:obj});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};

export const getDomianById = async(req,res)=>{
    try {
        let {id} = req.params;
        let domain =  await ProductDomainModel.findById(id);
        return res.status(200).json({data:domain});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};

export const deleteDomain = async(req,res)=>{
    try {
        let {id} = req.params;
        let domain =  await ProductDomainModel.deleteOne({_id:id});
        return res.status(200).json({data:domain});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};

export const updateDomain = async(req,res)=>{
    try {
        let {body,params} = req;
        let {id} = params;
        let domain =  await ProductDomainModel.updateOne({_id:id},body);
        return res.status(200).json({data:domain});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};

export const getMyDomains = async(req, res) => {
    try {
        let userId = req.me._id;
        let domain =  await ProductDomainModel.find({userId: userId}, null, {sort: {_id: -1}}).populate('tld');
        return res.status(200).json({data:domain});
    } catch (error) {
        
        return errorHandler (error,400,res);
    }
};
