'use strict';
import mongoose from 'mongoose';
const objectId = mongoose.Schema.Types.ObjectId;
const uniqueValidator = require('mongoose-unique-validator');

const ProductDomainSchema = new mongoose.Schema(
  {
    domainName:  {type: String, required: true, unique: true},
    type:        {type: String, required: true, default: 'domain'},
    domainOwner: {type: String, required: true},
    resolveType: {type: String},
    tld:       {type: objectId, ref: 'Tld'},
    resolveString: {type: String},
    deployedOnChain: {type: Boolean, require: true, default: false},
    chainLocation: {type: String},
    purchaseDate: {type: Date},
    userId: {type: objectId, required: true, ref: 'User'},
    expiresAt: {type: Date},
    orderId: {type: objectId, required: true, ref: 'Order'},
    productId: {type: String, required: true, unique: true},
    assets: {'website_url': String, 'btc_addr': String, 'eth_addr': String, 'xdc_addr': String}
  },
  {timestamps: true, versionKey: false}
);

ProductDomainSchema.plugin(uniqueValidator, {
  message: 'Duplicate Entry {PATH}',
});
export const ProductDomainModel = mongoose.model(
  'ProductDomain',
  ProductDomainSchema
);
