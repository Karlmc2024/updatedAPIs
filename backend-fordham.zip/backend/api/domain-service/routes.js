const router = require('express').Router();
import {
  createDomain,
  deleteDomain,
  updateDomain,
  getDomianById,
  searchDomain,
  getMyDomains,
} from './controller';

router.get('/', getMyDomains);
// router.post('/', createDomain);
router.post('/search', searchDomain);
router.get('/:id', getDomianById);
router.put('/:id', updateDomain);
router.delete('/:id', deleteDomain);
export default router;
