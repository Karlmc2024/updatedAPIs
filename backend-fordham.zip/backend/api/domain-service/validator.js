const Joi = require('@hapi/joi');

const params = (req, res, next) => {
    const schema = Joi.object({
        userId:  Joi.string().required()
    });
    const {error} = schema.validate(req.params);
    if (error) {
        return res.status(400).json({error: {message:'User Id is missing'}});
    }

    next();
};

const searchDomain = (req, res, next) => {
    const schema = Joi.object({
        domain:  Joi.string().required()
    });
    const {error} = schema.validate(req.params);
    if (error) {
        return res.status(400).json({error: {message:'Domain name is missing'}});
    }
    next();
};

const createDomain = (req, res, next) => {
    const schema = Joi.object({
        domainName: Joi.number().required()
    });
    let {error} = schema.validate(req.body);
    if (error && error.details) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        return res.status(400).json({error:{message:message}});
    }
    next();
};

module.exports = {
    createDomain,
    searchDomain
};




