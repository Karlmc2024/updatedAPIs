import {OrderModal} from './model';

export const checkIfDomainIsAlreadyBought = (domainName)=>{
  return OrderModal.findOne({'cart.items.domainName':domainName});
};
