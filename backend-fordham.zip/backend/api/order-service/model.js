'use strict';
import mongoose from 'mongoose';
const objectId = mongoose.Schema.Types.ObjectId;

const OrderSchema = new mongoose.Schema(
    {
        userId: {type: String, required: true},
        status: {
            type: String,
            required: true,
            enum: [
                'created',
                'paymentStarted',
                'paymentDone',
                'paymentFailed',
                'domainInitiated',
                'domainDone',
            ],
            default: 'created',
        },
        cart: {
            totalQty: {
                type: Number,
                default: 0,
                required: true,
            },
            totalCost: {
                type: Number,
                default: 0,
                required: true,
            },
            currency: {type: String, required: true, default: 'usd'},
            items: [
                {
                    productId: {
                        type: objectId,
                        ref: 'Product',
                    },
                    tld: {
                        type: objectId,
                    },
                    price: {
                        type: Number,
                        default: 0,
                    },
                    domainName: {
                        type: String,
                    },
                    domainOwner: {
                        type: String,
                    },
                },
            ],
        },
        createdAt: {
            type: Date,
            default: Date.now,
        },
        transactionId: {type: String},
        discount: {type: mongoose.Schema.Types.Mixed},
        finalAmount: {type: Number},
    },
    {timestamps: true, versionKey: false}
);

export const OrderModel = mongoose.model('Order', OrderSchema);

export const DiscountModel = mongoose.model(
    'DiscountCoupons',
    new mongoose.Schema({
        couponCode: {type: String},
        discount: {type: Number},
        applyTo: {type: mongoose.Schema.Types.Mixed},
        applyAuto: {type: Boolean},
    })
);

export const LockedDomainModel = mongoose.model(
    'LockedDomains',
    new mongoose.Schema({
        userId: {
            type: objectId,
            ref: 'User',
        },
        orderId: {
            type: objectId,
            ref: 'Order',
        },
        domainName: {type: String},
        expireAt: {type: Date},
    })
);
