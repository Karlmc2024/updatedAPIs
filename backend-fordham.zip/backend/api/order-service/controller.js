import {OrderModel, DiscountModel, LockedDomainModel} from './model';
import {CartModel as CartModelTrue} from '../cart-service/model';
import {ProductDomainModel} from '../domain-service/model';
import {TldModel} from '../tld-api/model';
import errorHandler from '@lib/utils/error';
import {AssetsModel} from '../assets-service/model';

const PinataService = require('../domain-service/services/PinataService');


export const createCart = async (req, res) => {
  try {
    let {body} = req;
    let domain = await OrderModel(body).save();
    return res.status(201).json({data: domain});
  } catch (error) {
    return errorHandler (error,400,res);
  }
};

export const getCartById = async (req, res) => {
  try {
    let {id} = req.params;
    let domain = await OrderModel.findById(id);
    return res.status(200).json({data: domain});
  } catch (error) {
    return errorHandler (error,400,res);
  }
};

export const deleteCart = async (req, res) => {
  try {
    let {id} = req.params;
    let domain = await OrderModel.deleteOne({_id: id});
    return res.status(200).json({data: domain});
  } catch (error) {
    return errorHandler (error,400,res);
  }
};

export const updateCart = async (req, res) => {
  try {
    let {body, params} = body;
    let {id} = params;
    let domain = await OrderModel.updateOne({_id: id}, body);
    return res.status(200).json({data: domain});
  } catch (error) {
    return errorHandler (error,400,res);
  }
};

export const getMyOrders = async (req, res) => {
  try {
    let orders = await OrderModel.find({userId: req.me._id}).sort({
      _id: -1,
    });
    return res.status(200).json({data: orders});
  } catch (error) {
    return errorHandler (error,400,res);
  }
};

export const createOrder = async (req, res) => {
  try {
    let {cartBody} = req.body;
    let {cartId} = req.locals.user;
    let domains = await ProductDomainModel.find({
      domainName: {$in: cartBody.map((domain) => domain.name)},
    },{});

    if (domains.length > 0) {
      res.status(400).send({
        error: 'Domains exist',
        message:
            domains.map((domain) => domain.domainName).join(', ') +
            ' already exists',
      });
    }

    // let userDomains = await ProductDomainModel.find({
    //   userId: req.me._id,
    // }).exec();
    //
    // if (userDomains.length >= process.env.orderLimit) {
    //   res.status(400).json({
    //     error:  'Exceeded Domain Purchase Limit'
    //   });
    // }

    let cart = await CartModelTrue.findOne({userId: req.me._id});

    let domain;

    if (cart.currentOrderId) {
      domain = await OrderModel.findOneAndUpdate(
          {_id: cart.currentOrderId},
          {
            $set: {
              cart: {
                totalQty: cartBody.length,
                totalCost: cartBody.reduce(
                    (partial_sum, {price}) => partial_sum + Number(price),
                    0
                ),
                items: cartBody,
              },
              finalAmount: cartBody.reduce(
                  (partial_sum, {price}) => partial_sum + Number(price),
                  0
              ),
            },
          }
      );
      const lockedDomains = cartBody.map(item => ({
        userId: req.me._id,
        orderId: cart.currentOrderId,
        domainName: item.domainName,
        expireAt: new Date(new Date().getTime() + 30 * 6000)
      }));
      await LockedDomainModel.deleteMany({orderId: cart.currentOrderId});
      await LockedDomainModel.insertMany(lockedDomains);
    } else {
      domain = await OrderModel({
        userId: cart.userId,
        status: 'created',
        cart: {
          totalQty: cartBody.length,
          totalCost: cartBody.reduce(
              (partial_sum, {price}) => partial_sum + Number(price),
              0
          ),
          items: cartBody,
        },
        discount: null,
        finalAmount: cartBody.reduce(
            (partial_sum, {price}) => partial_sum + Number(price),
            0
        ),
      }).save();
      await CartModelTrue.findOneAndUpdate(
          {_id: cart._id},
          {
            $set: {
              currentOrderId: domain._id,
            },
          }
      );

      const lockedDomains = cartBody.map(item => ({
        userId: req.me._id,
        orderId: domain._id,
        domainName: item.domainName,
        expireAt: new Date(new Date().getTime() + 30 * 60000)
      }));
      await LockedDomainModel.insertMany(lockedDomains);
    }

    return res.status(200).json({data: domain._id});
  } catch (error) {
    return errorHandler (error,400,res);
  }
};

export const getOrder = async (req, res) => {
  try {
    let {orderId} = req.params;
    let order = await OrderModel.findById(orderId);
    return res.status(200).json({data: order});
  } catch (error) {
    return errorHandler (error,400,res);
  }
};

export const getDomainToConfigure = async (req, res) => {
  //todo for not mintable domain add validation
  try {
    let domains = await ProductDomainModel.find({
      orderId: req.params.orderId,
      resolveString: {$exists: false},
    },{});
    return res.status(200).json({data: domains});
  } catch (e) {
    return errorHandler (e,400,res);
  }
};

export const getOneDomainToConfigure = async (req, res) => {
  try {
    let domain = await ProductDomainModel.findOne({
      _id: req.params.domainId
    },{}).populate('tld');
    
    return res.status(200).json({data: domain});
  } catch (e) {
    return errorHandler (e,400,res);
  }
};

export const cancelOrderTransaction = async (req, res) => {
  try {
    const {id:orderId} = req.params;
    await OrderModel.updateOne(
      {_id: orderId},
      {
        $set: {
          status:'created'
        },
      }
    );
    const order = await OrderModel.findOne({_id: orderId});
    
    return res.status(200).json({data: order});
  } catch (e) {
    return errorHandler (e,400,res);
  }
};

export const completeDomainRegistration = async (req, res) => {
  try {
    let updatedDomain = await ProductDomainModel.findOneAndUpdate(
        {_id: req.params.domainId},
        {
          resolveType: req.body.resolveType,
          resolveString: req.body.resolveString,
          domainOwner: req.body.domainOwner
        });

    return res.status(200).json({data: updatedDomain});
  } catch (e) {
    return errorHandler (e,400,res);
  }
};

export const getAvailableCoupons = async (req, res) => {
  try {
    let coupons = await DiscountModel.find({applyTo: 'all'});
    return res.status(200).json({data: coupons});
  } catch (e) {
    return errorHandler (e,400,res);
  }
};

export const applyCoupon = async (req, res) => {
  try {
    let {discountCoupon, orderId} = req.body;
    let discount = await DiscountModel.find({
      couponCode: discountCoupon,
      applyTo: 'all',
    });
    if (discount.length < 1) {
      return res.status(400).json({message: 'Coupon is not valid'});
    }
    let discountToApply = discount[0];
    let order = await OrderModel.findById(orderId);
    let finalAmount = Math.round(
        order.cart.totalCost * (1 - discountToApply.discount / 100)
    );
    let updatedOrder = await OrderModel.findByIdAndUpdate(
        orderId,
        {
          finalAmount: finalAmount,
          discount: discountToApply,
        },
        {new: true}
    );
    return res.status(200).json({data: updatedOrder});
  } catch (e) {
    return errorHandler (e,400,res);
  }
};

