const router = require('express').Router();
import {
  createCart,
  getCartById,
  updateCart,
  deleteCart,
  getMyOrders,
  createOrder,
  getOrder,
  getDomainToConfigure,
  getOneDomainToConfigure,
  completeDomainRegistration,
  getAvailableCoupons,
  applyCoupon,
  cancelOrderTransaction,
} from './controller';

router.get('/myorders', getMyOrders);
router.get('/:orderId', getOrder);
router.post('/', createOrder);
router.get('/getDomainsToConfigure/:orderId', getDomainToConfigure);
router.get('/getDomainToConfigure/:domainId', getOneDomainToConfigure);
router.post(
  '/complete-domain-registration/:domainId',
  completeDomainRegistration
);
router.get('/coupons/getAvailableCoupons', getAvailableCoupons);
router.post('/applyCoupon', applyCoupon);
router.post('/cancel-order-transaction/:id',cancelOrderTransaction);

export default router;
