// /**
//  * Import All  Mongoose Model Here
//  */

/**
 * Import All  Mongoose Model Here
 */
 import {CartModel} from './cart-service/model';
 import {ProductDomainModel} from './domain-service/model';
 import {NotificationModel} from './notification-service/model';
 import {UserModel} from './user-service/model';
 import {TransactionModel} from './transaction-service/model';
 import {WalletModel} from './wallet-service/model';
 import {TldModel} from './tld-api/model';
 import {TradeMarkModel} from './trademark-service/model';
 import {CreditModel} from './credit-system/model';
 import {influencerModel} from './credit-system/model';
 import {trademarkRequestModel} from './trademark-service/model';

export {
   CartModel,
   ProductDomainModel,
   NotificationModel,
   UserModel,
   TransactionModel,
   WalletModel, TldModel, CreditModel, TradeMarkModel,influencerModel,trademarkRequestModel
 };
 
 
