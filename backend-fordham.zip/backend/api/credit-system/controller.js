import {CreditModel,influencerModel} from '../model';
import mongoose from 'mongoose';

import errorHandler from '@lib/utils/error';
import {calculateTokenAllocation} from './services';
import {createTransaction} from '../transaction-service/services/CreateTransaction';

export const getCredits = async(req,res)=>{
    try {
        let availableCredits = await CreditModel.findOne({userId: req.locals.user._id})
        return res.status(200).json({result:availableCredits});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};

export const getHistory = async(req,res)=>{
    try {
        let availableCredits = await CreditModel.aggregate([{$match: {userId:  mongoose.Types.ObjectId(req.locals.user._id)}},
            { $unwind: '$transactionHistory' },
            { $sort: {
                    'transactionHistory.createdAt': -1
                }},
            { $group: { _id: '$_id', transactionHistory: { $push: '$transactionHistory'}}}
        ])
        return res.status(200).json({result:availableCredits && availableCredits[0]});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};





export const getTokens = async(req,res)=>{
    try {
        let tokens = calculateTokenAllocation(req.body.amount);
        return res.status(200).json({result:tokens});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};

export const getInfluencer = async(req,res)=>{
    try {
        let influencers = await influencerModel.find({})
        return res.status(200).json({result:influencers});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};

export const addCredits = async(req,res)=>{
    try {

        let body  = Object.assign({}, req.body);

        let generateTransaction = await createTransaction(body.paymentGateway,body.amount,'usd',req.locals.user._id,req);

        let obj = {};
        obj.userId = req.locals.user._id;
        const transaction  = {
            purchasedCredit: req.body.amount,
            allocatedTokens: calculateTokenAllocation(req.body.amount),
            transactionId:generateTransaction._id,
            status:generateTransaction.status,
            influencer:body.influencer,
            transactionHash: generateTransaction.txHash
        };

        let updateCredit = await CreditModel.findOneAndUpdate({userId:req.locals.user._id},{...obj ,
            $push:{
                transactionHistory:transaction
            }
        },{upsert:true, new : true});

        return res.status(201).json({result:generateTransaction});

    } catch (error) {
        
        return errorHandler (error,400,res);
    }
};

export const getCreditEnum = async(req,res)=>{
    try {
        let creditEnum = [100,250,500,1000,2500,5000];
        return res.status(200).json({result:creditEnum});
    } catch (error) {
        return errorHandler (error,400,res);
    }
};
