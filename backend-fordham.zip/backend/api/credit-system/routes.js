
const router = require('express').Router();
import {getCredits,getCreditEnum,addCredits,getHistory, getTokens,getInfluencer} from './controller';
import {addCredit,tokens} from './validator';

router.get('/',getCredits);
router.get('/history',getHistory);
router.get('/amounts',getCreditEnum);
router.get('/influencer',getInfluencer);
router.post('/tokens',tokens,getTokens);
router.post('/',addCredit, addCredits);

export default router;
