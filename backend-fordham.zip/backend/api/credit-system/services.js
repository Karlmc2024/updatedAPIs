import {CreditModel,UserModel} from '../model';
import errorHandler from '@lib/utils/error';
import sendOrderConfirmation from '@lib/utils/orderConfirmation';

const multiple = 0.03;

const transactionOrderStatusMapping = {
    confirmed: 'paymentDone',
    failed: 'paymentFailed',
    canceled: 'paymentFailed',
  };

export const calculateTokenAllocation = (creditValue) => {
    return (creditValue / multiple).toFixed(2);
};

export const burnCredits = async (creditValue,orderId,req,res) => {
    try {
        let availableCredits = await CreditModel.findOne({userId: req.locals.user._id});
        if (availableCredits.amount === 0) {
            return 0;
        } else if (availableCredits.amount < creditValue){
            return false;
        } else {
            let credits = availableCredits.amount - creditValue;
            let creditUsesHistory = {
                initialCredit:availableCredits.amount,
                remainingCredit: credits,
                usedCredit:creditValue, 
                orderId:orderId,
                status: 'paymentDone'
            };

          let update =   await CreditModel.findByIdAndUpdate({_id: availableCredits._id},
                {$push:{creditUsesHistory:creditUsesHistory},amount:credits,},{new:true});
            return update;
        }

    } catch (error){
        return errorHandler(error, 400, res);
    }

};

export const sendMail = async (data) => {
    let user = await UserModel.findOne({_id: data.userId},{})
    sendOrderConfirmation({
        name: user.firstName + ' ' + user.lastName,
        orderId: data._id,
        price: data.amount,
        nexbTokens: data.nexbTokens
    }, null, user.email,true);
}

export const creditHistoryStatus = async (transactionId,status) => {
    const credit = await CreditModel.findOne({'transactionHistory.transactionHash': transactionId});
    if (credit){
        const transactionHistory =  credit.transactionHistory.find(history => history.transactionHash === transactionId);
        if (transactionHistory){
            transactionHistory.status = transactionOrderStatusMapping[status];
            if (status === 'confirmed') {
                {credit.amount = credit.amount + transactionHistory.purchasedCredit;}
                credit.nexbTokens = credit.nexbTokens + transactionHistory.allocatedTokens;
                sendMail(credit);
            }
            await credit.save();
        }
    }
    return credit;
};



// pk_live_51KgMm6SEY531WZgM6qB5GrHZ9XbhtOwxAoKAKWvfouESOUOVyPUrNg0gBXlyioy89GMonRW1yXrfM9w5KGFUXMcK00xNyWOyYV
