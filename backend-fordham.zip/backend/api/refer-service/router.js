const express  =require('express');
const router  = express.Router();
const { validateEmail , validateid }  = require('./validator');
const controller = require('./controller');


router.get('/', controller.getAllRefer)
router.get('/refer-detail/:_id' , validateid, controller.getReferDetail );
router.post('/', validateEmail, controller.ReferUser);
router.get('/success', controller.getSuccessRefers);
router.get('/fail', controller.getFailRefers);
router.get('/success-count', controller.getCountSuccessRefers);
router.get('/fail-count', controller.getCountFailRefers);


module.exports  = router;
