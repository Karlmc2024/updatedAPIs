const  joi = require('@hapi/joi');

const validateid  = (req, res, next)=>{
    const schema  =  joi.object({
        _id : joi.string().required()
    })
    const  {error }  = schema.validate( req.params);
    if(error){
        return res.status(400).json({message: error.message});
         
    }
    else {
    
        next();
    }
}

const validateEmail  = (req, res, next)=>{
    const schema  = joi.object({
        email: joi.string().email({ minDomainSegments: 2, tlds: { allow: ['com', 'net'] } }).required()
    })
    const {error } = schema.validate(req.body);
    if(error){
        return res.status(400).json({message : error.message })
    }
    else {
        next();
    }
}


module.exports  = {validateEmail , validateid};
