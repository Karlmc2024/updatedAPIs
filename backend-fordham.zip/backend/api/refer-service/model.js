const mongoose = require('mongoose');

const Referschema = new mongoose.Schema({
    email: {
        type: String,
        required: true
    },
    status: {
        type: String,
        required: true,
        default: "Pending"
    },
    isaccepted: {
        type: String,
        required: true,
        default: false
    },
    referBy:{
      type :String,
      required: true   
    },
    belongto: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "users",
        allowNull : true,
        required: false
    }
}, { timestamps: true })
const ReferModel = mongoose.model('referral', Referschema);
module.exports = { ReferModel };
