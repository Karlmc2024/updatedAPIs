// import {OrderModel, DiscountModel, LockedDomainModel} from './model';
// import {CartModel as CartModelTrue} from '../cart-service/model';
// import {ProductDomainModel} from '../domain-service/model';
// import errorHandler from '@lib/utils/error';

// const PinataService = require('../domain-service/services/PinataService');


// export const addAssets = async (req, res) => {
//   try {
//     let {body} = req;
//     let domain = await OrderModel(body).save();
//     return res.status(201).json({data: domain});
//   } catch (error) {
//     return errorHandler (error,400,res);
//   }
// };
