const swaggerUi         = require('swagger-ui-express');
const swaggerDocument   = require('../docs/swagger/swagger.json');
const cart   = require('../docs/swagger/cart.json');


const startSwagger = (app) => {

    app.use((req, res, next) => {
        let hostname = req.headers.host;
        if (process.env.NODE_ENV === 'production') {
            swaggerDocument.host = hostname ;
        } else {
            swaggerDocument.host = 'localhost:' + 9000;
        }
        next();
    });

    app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
    app.use('/cart-docs', swaggerUi.serve, swaggerUi.setup(cart));
};

export default startSwagger;
