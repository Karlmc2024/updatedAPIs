const pathNeedAuth = ['/api/transactions'];
const authenticator = async (app) => {
  app.use((req, res, next) => {
    // if (req.headers.auth && pathNeedAuth.includes(req.path)) {
      req.me = {
        firstName: 'Samrat',
        lastname: 'Das',
        _id: '61554468a0b26a3884839d62',
        address: {
          line1: '510 Townsend St',
          postal_code: '98140',
          city: 'San Francisco',
          state: 'CA',
          country: 'US',
        },
      };
      next();
    // } else {
    //   res.status(401).json({
    //     error: "Please Login to continue",
    //   });
    // }
  });
};

export default authenticator;
