const jwt = require('jsonwebtoken');

const exceptAuthRoutes = [
  'login',
  'signup',
  'forgot-password',
  'reset-password',
  'test-session',
  'forgotpassword',
  'paypal-webhook',
  'stripe-webhook',
  'coinbase-webhook',
  'domains/search',
  'verify-account',
  'paymentstatussubscribe',
  'test',
  'tld',
  'admin/api/today-domain-count',
  'credits/amounts',
  'premium-domain',
  'total-sale',
  'credits/influencer',
  'executeCartMail',
  'admin'
];

const {UserModel} = require('../api/model');
import errorHandler from '@lib/utils/error';
const verifyToken = (token, next, res) => {
  const secret = process.env.TOKEN_SECRET;
  const options = {algorithm: 'HS256'};
  // eslint-disable-next-line no-undef
  return new Promise((resolve, reject) => {
    return jwt.verify(token, secret, options, (err, decoded) => {
      if (err && err.name === 'TokenExpiredError') {
        return res
          .status(401)
          .send({error: 'Access token expired. Please login again'});
      }
      if (err && err.name === 'JsonWebTokenError') {
        return res.status(401).send(
          {error: 'UnAuthorized Access. Please login again'}
        );
      }
      return resolve(decoded);
    });
  });
};
const verifyAuth = (req, res, next) => {
  try {
    
    let token = req.headers['authorization'];
    token = token.split(' ')[1];
    if (!token) {
      return res.status(401).send({message: 'Access token is required'});
    }
    return verifyToken(token, next, res)
      .then((decoded) => {
        let query = {};
        if (decoded && decoded._id) {
          query._id = decoded._id;
          if (decoded.email){
            query.email = decoded.email;
          }
          //If user not found throw 401
          
          return UserModel.findOne(query, function(err, user) {
            if (!user){
              return res.status(401).send({message: 'User not found'});
            }
            user = user.toJSON();
            delete user.password;
            delete user.emailVerifyUrl;
            req.locals = {user: user};
            req.me = user;
            if (req.me) {
              //todo
              req.me.resAddress = {
                line1: '510 Townsend St',
                postal_code: '98140',
                city: 'San Francisco',
                state: 'CA',
                country: 'US',
              };
            } // Dummy address for payments
            next();
          });
        }
      })
      .catch((err) => {
        return errorHandler(err, 400, res);
      });
  } catch (err) {
    logger.error('token error',err);
    return res.status(401).send({message: 'Invalid Auth. Pleas Login Again'});
  }
};

const auth = async  (req, res, next) => {
  let exception = false;
  

  for (let exceptedRoute of exceptAuthRoutes) {
    if (req.originalUrl.includes(exceptedRoute)) {
      exception = true;
      break;
    }
  }
  if (exception) {
    return  next();
  } else {
    return verifyAuth(req, res, next);
  }
};

module.exports = {auth: auth};
