'use strict';

/**
 * Module dependencies.
 */

const express   = require('express');
const router    = express.Router();
const {auth} = require('./auth');
const createRoutes = require('./../api/routes');
const { validateApiKey } = require('./validate-api-key');
// console.log(createRoutes,'apiRouter');


/**
 * Expose
 */

module.exports = app => {

  router.get('/', (req, res, next) => {
    try {
      res.send(' Server');
    } catch (e) {
      logger.error(e, 'err in / path');
      next(e);
    }
  });
  app.use('/api',auth,validateApiKey,createRoutes);

};