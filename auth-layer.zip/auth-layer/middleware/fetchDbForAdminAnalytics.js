const { EnterpriseModel } = require("@api/enterprise-service/model");
import errorHandler from '@lib/utils/error'


export const fetchDbForAdmin = async(req,res,next) => {
    try{
        const enterpriseId = req.params.enterpriseId || req.me.enterpriseId
        console.log(req.params)  
        if(!enterpriseId){
            const error = new Error("Please pass enterpriseId")
            return errorHandler(error,400,res)
        }
        const enterprise = await EnterpriseModel.findById(enterpriseId)
        if(!enterprise){
            const error = new Error("No such enterprise exist")
            return errorHandler(error,400,res)
        }
        req.headers.dbName = enterpriseId;
        console.log(req.headers)
        next();
    }
    catch(err){
        console.log("middleware eror")
        console.log(err.message)
        return errorHandler(err,400,res)
    }
}