const jwt = require("jsonwebtoken");

const exceptAuthRoutes = [
  "login",
  "signup",
  "user/forgot-password",
  "reset-password",
  "test-session",
  "forgotpassword",
  "paypal-webhook",
  "stripe-webhook",
  "coinbase-webhook",
  "domains/search",
  "verify-account",
  "paymentstatussubscribe",
  "/api/tld",
  "/api/premium-domain",
  "admin/api/today-domain-count",
  "credits/amounts",
  "credits/influencer",
  "executeCartMail",
  "enterprise/create",
  "update-onboarding-status",
  "update-spinup-status",
  "app-live-email",
  "update-cache",
  "spin-portal-local",
  "enterprise/search-tld",
];

const { UserModel } = require("@api/enterprise-user/model");
const errorHandler = require("errorhandler");

const verifyToken = (token, next, res) => {
  const secret = process.env.TOKEN_SECRET;
  const options = { algorithm: "HS256" };
  // eslint-disable-next-line no-undef
  return new Promise((resolve, reject) => {
    return jwt.verify(token, secret, options, (err, decoded) => {
      if (err && err.name === "TokenExpiredError") {
        return res
          .status(401)
          .send({ error: "Access token expired. Please login again" });
      }
      if (err && err.name === "JsonWebTokenError") {
        return res
          .status(401)
          .send({ error: "UnAuthorized Access. Please login again" });
      }
      return resolve(decoded);
    });
  });
};
const verifyAuth = (req, res, next) => {
  try {
    let token = req.headers["authorization"];
    token = token.split(" ")[1];
    if (!token) {
      return res.status(401).send({ message: "Access token is required" });
    }
    return verifyToken(token, next, res)
      .then((decoded) => {
        let query = {};
        if (decoded && decoded._id) {
          query._id = decoded._id;
          if (decoded.email) {
            query.email = decoded.email;
          }

          //If user not found throw 401

          return UserModel.findOne(query).then((user) => {
            if (!user) {
              return res.status(401).send({ message: "User not found" });
            }
            user = user.toJSON();
            delete user.password;
            delete user.emailVerifyUrl;
            req.locals = { user: user };
            req.me = user;
            if (req.me) {
              req.me.resAddress = {
                line1: "510 Townsend St",
                postal_code: "98140",
                city: "San Francisco",
                state: "CA",
                country: "US",
              };
            } // Dummy address for payments
            req.isVerifiedRequest = true;
            next();
          });
        }
      })
      .catch((err) => {
        return errorHandler(err, 400, res);
      });
  } catch (err) {
    console.log(err);
    //logger.error('token error',err);
    return res.status(401).send({ message: "Invalid Auth. Pleas Login Again" });
  }
};

const auth = async (req, res, next) => {
  let exception = false;
  for (let exceptedRoute of exceptAuthRoutes) {
    if (req.originalUrl.includes(exceptedRoute)) {
      exception = true;
      break;
    }
  }
  if (exception) {
    req.isVerifiedRequest = true;
    return next();
  } else {
    return verifyAuth(req, res, next);
  }
};

const isAdmin = async (req, res, next) => {
  if (!["SUPER_ADMIN", "ADMIN"].includes(req.me.role)) {
    return res.status(400).json({
      error: "Only admins have access to this service",
    });
  }
  next();
};

const isSuperAdmin = async (req, res, next) => {
  try {
    if (!["SUPER_ADMIN"].includes(req.me.role)) {
      return res.status(404).json({
        error: "No such service exist",
      });
    }
    next();
  } catch (err) {
    return errorHandler(err, 400, res);
  }
};

const isProvisioner = (req, res, next) => {
  try {
    let token = req.headers["authorization"];
    if (!token) {
      return res.status(401).send({ message: "Token is required" });
    }
    if (token !== process.env.PROVISIONER_API_KEY) {
      return res.status(401).send({ message: "Invalid api key" });
    }
    next();
  } catch (error) {
    console.log(error);
    return res.status(401).send({ message: "Invalid Access" });
  }
};

module.exports = {
  auth: auth,
  isAdmin: isAdmin,
  isProvisioner: isProvisioner,
  isSuperAdmin: isSuperAdmin,
};
