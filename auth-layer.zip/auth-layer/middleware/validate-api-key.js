import {
  EnterpriseModel,
  EnterpriseKeyModel,
} from "@api/enterprise-service/model";
import errorHandler from "@lib/utils/error";
import cacheData from "@lib/utils/cache";

const exceptApiKeyRoutes = [
  "login",
  "signup",
  "forgot-password",
  "reset-password",
  "admin-registration",
  "test-session",
  "change-password",
  /* 'paypal-webhook',
    'stripe-webhook',
    'coinbase-webhook',*/
  "verify-account",
  "enterprise",
  "user/me",
  "admin/",
  "enterprise/search-tld",
];

export const validApiKey = async (req, res, next) => {
  try {
    let client = req.headers.referer || `http://${req.get("host")}`;
    console.log(req.headers.referer);
    client = client.split(".");

    let customer = "sder";//(client[0] === 'staging'? client[1]:client[0]).replace("https://", "");
    let enterprise;
    const cacheDataForEnterprise = cacheData.get(customer);
    if (cacheDataForEnterprise) {
      enterprise = cacheDataForEnterprise;
    } else {
      const selectHiddenFields = [
        "orderLimit",
        "SPARKPOST_API_KEY",
        "HUBSPOT_API_KEY",
        "STRIPE_SECRET_KEY",
        "S3_region",
        "S3_bucket",
        "XDC_PRIVATE_KEY",
        "XDC_REGISTRAR_CONTRACT_ADDRESS",
      ];
      var orgRegex = new RegExp(["^", customer, "$"].join(""), "i");
      enterprise = await EnterpriseModel.findOne({ organizationName: orgRegex })
        .select(selectHiddenFields)
        .populate({
          path: "keys",
          sort: "-createdAt",
        });
      //decrypting the database keys then saving in cache
      cacheData.put(customer, {
        _id: enterprise._id,
        orderlimit: enterprise.orderlimit || "",
        sparkpost_api_key: enterprise.sparkpost_api_key || "",
        hubspot_api_key: enterprise.hubspot_api_key || "",
        stripe_secret_key: enterprise.stripe_secret_key || "",
        s3_region: enterprise.s3_region || "",
        s3_bucket: enterprise.s3_bucket || "",
        xdc_private_key: enterprise.xdc_private_key || "",
        xdc_registrar_contract_address:
          enterprise.xdc_registrar_contract_address || "",
        ipfs_base_url: req.headers.referer || "http://www.ipfs.io",
      });
    }
    req.headers.dbname = enterprise._id;
    (req.headers.orderlimit = enterprise.orderlimit || ""),
      (req.headers.sparkpost_api_key = enterprise.sparkpost_api_key || ""),
      (req.headers.hubspot_api_key = enterprise.hubspot_api_key || ""),
      (req.headers.stripe_secret_key = enterprise.stripe_secret_key || ""),
      (req.headers.s3_region = enterprise.s3_region || ""),
      (req.headers.s3_bucket = enterprise.s3_bucket || " "),
      (req.headers.xdc_private_key = enterprise.xdc_private_key || ""),
      (req.headers.xdc_registrar_contract_address =
        enterprise.xdc_registrar_contract_address || "");
    req.headers.ipfs_base_url = req.headers.origin || "http://www.ipfs.io";

    //---------------------------------------check for api key if did not got any token in request-----------------
    if (!req.isVerifiedRequest) {
      const apiKey = req.headers["x-api-key"];
      let isValidApiKey = false;
      if (apiKey.startsWith("Nxb-test") && client[0] === "staging") {
        //check if the test key passed is current active test key of that enterprise using find method of array
        const activeTestKey = enterprise.keys.find(
          (element) => element.type === "test" && element.active === true
        );

        if (activeTestKey) {
          isValidApiKey = activeTestKey.key === apiKey ? true : false;
        }
      } else if (apiKey.startsWith("Nxb-live") && client[0] !== "staging") {
        //check if the live key passed is current active test key of that enterprise
        const activeLiveKey = enterprise.keys.find(
          (element) => element.type === "live" && element.active === true
        );
        if (activeLiveKey) {
          isValidApiKey = activeLiveKey.key === apiKey ? true : false;
        }
      }
      console.log("isValidApiKey", isValidApiKey);
      if (!isValidApiKey) {
        return res
          .status(400)
          .json({ error: "Invalid Api Key.Please contact your provider" });
      }
    }
    next();
  } catch (error) {
    console.log(error);
    return errorHandler(error, 400, res);
  }
};
export const validateApiKey = async (req, res, next) => {
  let exception = false;
  for (let exceptedRoute of exceptApiKeyRoutes) {
    if (req.originalUrl.includes(exceptedRoute)) {
      exception = true;
      break;
    }
  }
  if (exception) {
    if (req.originalUrl.includes("/user/signup")) {
      //if we are signing up and request comes from customer web ui we should give enterpriseId in req.body.enterpriseId not if it comes from admin portal ie why we have check if(enterprise)
      let client = req.headers.referer || `http://${req.get("host")}`;
      client = client.split(".");
      let customer = "sder";//client[0] === 'staging'? client[1]:client[0]
      customer = customer.split("://")[1];
      var orgRegex = new RegExp(["^", customer, "$"].join(""), "i");
      const enterprise = await EnterpriseModel.findOne({
        organizationName: orgRegex,
      });

      if (enterprise) {
        req.body.enterpriseId = enterprise._id;
      }
    }
    return next();
  } else {
    return validApiKey(req, res, next);
  }
};
