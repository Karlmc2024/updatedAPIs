"use strict";

/**
 * Module dependencies.
 */
const compression = require("compression");
const methodOverride = require("method-override");
const cors = require("cors");
const helmet = require("helmet");
const hsts = require("hsts");
const env = process.env.NODE_ENV || "development";
const sixtyDaysInSeconds = 31536000;
const useragent = require("express-useragent");
const csp = require("helmet-csp");
const bodyParser = require("body-parser");
const task = require("@lib/crons/deleteExpiredCoupon");

/**
 * Expose
 */

module.exports = (app) => {
	app.use(helmet());
	app.use(helmet.noSniff());
	app.use(helmet.frameguard({ action: "SAMEORIGIN" }));

	app.use(
		helmet.contentSecurityPolicy({
			directives: {
				defaultSrc: ["'self'"],
			},
			referrerPolicy: { policy: "same-origin" },
		})
	);

	app.use(
		hsts({
			maxAge: 31536000, // Must be at least 1 year to be approved
			includeSubDomains: true, // Must be enabled to be approved
			preload: true,
		})
	);

	app.use((req, res, next) => {
		res.locals.session = req.session;
		next();
	});

	app.use(
		csp({
            useDefaults: true,
			directives: {
				scriptSrc: ["'self'", "'unsafe-inline'"],
				sandbox: ["allow-forms", "allow-scripts"],
				objectSrc: ["'none'"],
                upgradeInsecureRequests: [],
			}
		})
	);

	app.use(useragent.express());
	app.disable("x-powered-by");

	// Compression middleware (should be placed before express.static)
	app.use(compression());

	//todo
	app.use(cors());
	app.set("view engine", "ejs");
	app.use(bodyParser.json({ limit: "50mb" }));
	app.use(bodyParser.urlencoded({ limit: "50mb", extended: true }));

	app.use(
		methodOverride((req) => {
			if (
				req.body &&
				typeof req.body === "object" &&
				"_method" in req.body
			) {
				// look in urlencoded POST bodies and delete it
				const method = req.body._method;
				delete req.body._method;
				return method;
			}
		})
	);

	if (env === "development") {
		app.locals.pretty = true;
	}
	task.start()
};
