"use strict";

const express = require("express");
const router = express.Router();

const enterpriseRouter = require('@api/enterprise-service/routes')
const userRouter = require('@api/enterprise-user/routes');
const domainRouter =require('@api/domain-service/routes');
const premiumDomainRouter = require('@api/premium-domain-service/routes')
const tradeMarkRouter = require('@api/trademark-service/routes');
const cartRouter = require('@api/cart-service/routes');
const orderRouter = require('@api/order-service/routes');
const transactionRouter = require('@api/transaction-service/routes');
const assetsRouter = require('@api/assets-service/routes')
// const ipfsRouter = require('@api/ipfs-service/routes')
const tldRouter = require('@api/tld-service/routes')
const notificationRouter = require("@api/notification-service/routes")
const wishlistRouter = require("@api/wishlist-service/routes")
const creditRouter = require("@api/credit-service/routes")
const referRouter = require("@api/refer-service/routes")
const blockChainRouter = require("@api/blockchain-proxy/routes")
const domainTransferRouter = require("@api/domain-transfer-service/routes")
const adminRouter = require("@api/admin-service/routes");
const logRouter = require("@api/logs-service/routes")
const cryptoTransferRouter = require('@api/crypto-transfer-service/routes')
const superAdminRouter = require("@api/super-admin-service/routes")
const ipfsRouter = require("@api/ipfs-service/routes")


// const logRouter = require("@api/logs-service/routes")

router.use('/enterprise',enterpriseRouter);
// router.use('/',userRouter);
router.use('/user',userRouter);
router.use('/domains',domainRouter);
router.use('/assets',assetsRouter)
router.use('/cart',cartRouter)
router.use('/premium-domain',premiumDomainRouter);
router.use('/trademarks',tradeMarkRouter);
router.use('/orders',orderRouter);
router.use('/transactions',transactionRouter)
// router.use('/ipfs',ipfsRouter)
router.use('/tld',tldRouter)
router.use('/notifications',notificationRouter)
router.use('/wishlist',wishlistRouter)
router.use('/credits',creditRouter)
router.use('/refer',referRouter)
router.use('/blockchain',blockChainRouter)
router.use("/domain-transfer", domainTransferRouter);
router.use('/admin',adminRouter)
router.use('/logs',logRouter)
router.use("/cryptotransfer",cryptoTransferRouter)
router.use("/super-admin",superAdminRouter)
router.use('/ipfs',ipfsRouter)
// router.use("/logs",logRouter)
//implementing unhandled route middleware
router.all('*', (req,res) => {
return res.status(400).json({
    message:"No such route exist"
})
})

module.exports = router;
