import { commonHandler } from '@api/common-service/handler';

const router = require('express').Router();


router.get('/',commonHandler);
router.post('/', commonHandler);
router.get('/paymentStatusSubscribe/:txHash', commonHandler);
router.get('/test/:id/:status', commonHandler);
router.post('/updatePaypal/:transactionId', commonHandler);
router.get('/total', commonHandler);
router.get('/:id', commonHandler);
router.put('/:id', commonHandler);
router.delete('/:id', commonHandler);
router.post('/coinbase-webhook', commonHandler);
router.post('/stripe-webhook', commonHandler);
// router.post('/paypal-webhook', paypalWebhook);

module.exports = router
