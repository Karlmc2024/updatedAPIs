import { commonHandler } from '@api/common-service/handler';
import { uploadIPFSImage } from '@lib/utils/upload';
import { generateServiceLayerTokens } from '@api/common-service/configuration';
import { validateMetaData } from './validator';
import errorHandler from '@lib/utils/error';
const httpProxy = require('http-proxy');

//
// Create a proxy server with custom application logic
//
const proxy = httpProxy.createProxyServer({});
const router = require('express').Router();

const proxyMiddlewareForWebsite = async(req,res) => {
    try{
    req.headers['authorization'] =  "Bearer "+generateServiceLayerTokens({ service: "SERVICE_LAYER" })
    req.headers.me = JSON.stringify(req.me)
    proxy.web(req, res, { target: `http://127.0.0.1:9000/api/ipfs/` });
    }
    catch(err){
        return errorHandler(error,400,res)
    }
}

router.post('/upload',uploadIPFSImage,validateMetaData,commonHandler);
router.post('/upload/website/:domainId',proxyMiddlewareForWebsite);
router.put('/reset-meta-data',validateMetaData,commonHandler)

module.exports = router;