import { commonHandler } from '@api/common-service/handler';
const router = require('express').Router();


import {addCredit,tokens} from './validator';

router.get('/',commonHandler);
router.get('/history',commonHandler);
router.get('/amounts',commonHandler);
router.get('/influencer',commonHandler);
router.post('/tokens',tokens,commonHandler);
router.post('/',addCredit, commonHandler);

module.exports = router;