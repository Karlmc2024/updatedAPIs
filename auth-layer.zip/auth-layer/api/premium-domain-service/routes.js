import { commonHandler } from '@api/common-service/handler';

const router = require('express').Router();

router.get('/', commonHandler);
router.post('/', commonHandler);
router.delete('/:id', commonHandler);

module.exports = router;