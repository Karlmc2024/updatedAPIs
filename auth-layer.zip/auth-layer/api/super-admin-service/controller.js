
import { sendEjsEmail } from '@lib/utils/email'
import { UserModel } from '@api/enterprise-user/model'
import path from 'path'
const ejs = require('ejs')
const fs = require('fs')

const { default: errorHandler } = require('@lib/utils/error')
const {OnboardingInvitationModel} = require('./model')


//send New Invitation




export const sendInvitationForOnboarding = async (req,res,next) => {
    try{

        const {email} = req.body
        if(!email){
            const error = new Error("Please provide email")
            return errorHandler(error,400,res)
        }
        const isEmailAreadyExist = await UserModel.findOne({email})
        if(isEmailAreadyExist){
            const error = new Error("User already exist")
            return errorHandler(error,400,res)
        }
        //do not create new Invitation if already invited
        let invitation
        invitation = await OnboardingInvitationModel.findOne({email:email})
       
        //check if any invitation already exist then only push userid of person who invited in that invitedBy Array
        if(invitation){
            if(invitation.status === 'completed'){
                    const error = new Error("This User is Already Registered")
                    return errorHandler(error,400,res)
            }
            //if this user already invited just send mail do not create new Invitation
            if(!invitation.invitedBy.includes(req.me._id)){

                invitation = await OnboardingInvitationModel.findByIdAndUpdate(invitation._id,
                    {$push:{invitedBy:req.me._id}},
                    {new:true})
                }
        }
        //create new onboarding invitation
        else{
            invitation = await OnboardingInvitationModel.create({
                email,
                invitedBy:[req.me._id],
                status:'pending'
            })
        }

        let filePath = path.resolve(
        __dirname + "../../../lib/utils/templates/onboarding-invite.ejs"
        )
        
        const compiled = ejs.compile(fs.readFileSync(filePath, "utf8")),
        dataToCompile = {
            name: req.body.email.split('@')[0],
            senderName:req.me.firstName+ " "+req.me.lastName,
            organizationName:"NEXBLOC",
            onboardingLink :`https://www.sdk-admin.nexbloc.com/signup?email=${req.body.email}`
        },
        
        Subject = `Invitation from NEXBLOC-SDK`;


        sendEjsEmail(
                req.body.email,
                req.body.email.split('@')[0],
                Subject,
                compiled(dataToCompile)
        );
        return res.status(200).json({message:"Invitation Sent Successfully"})
    }
    catch(err){
        return errorHandler(err,400,res)
    }

}


export const getAllPrimaryAdminOrInvitation = async(req,res,next) => {
    try{
        const primaryAdminQuery = UserModel.find({isPrimaryAdmin:true}).select('-password -emailVerifyUrl')
        const invitedBySupAdminQuery = OnboardingInvitationModel.find({status:'pending'})
        const [primaryAdmin,invitedBySupAdmin] = await Promise.all([primaryAdminQuery,invitedBySupAdminQuery])
        const result = [...primaryAdmin,...invitedBySupAdmin]
        return res.status(200).json({
            result
        })
    }
    catch(err){
        console.log(err)
        return errorHandler(err,400,res)
    }
}