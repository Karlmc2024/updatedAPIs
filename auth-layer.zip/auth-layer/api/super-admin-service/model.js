const mongoose = require('mongoose')
const objectId = mongoose.Schema.Types.ObjectId;

const onboardingInvitationSchema = new mongoose.Schema({
    email:{
        type:String,
        required:[true,"email id is required"]
    },
    invitedBy:[{
        type:objectId,
        ref:"User"
    }],
    status:{
        type:String,
        enum:["pending","signup"]
    }
})

export const OnboardingInvitationModel = mongoose.model("OnboardingInvitation",onboardingInvitationSchema)