
const express  = require('express');
const { isSuperAdmin } = require('@middleware/auth');
const router  = express.Router();
const {getAllPrimaryAdminOrInvitation,sendInvitationForOnboarding} = require('./controller')

router.get('/all-admins',isSuperAdmin,getAllPrimaryAdminOrInvitation)
router.post('/invite-to-onboard',isSuperAdmin,sendInvitationForOnboarding)


module.exports  = router;