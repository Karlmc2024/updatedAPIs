import { commonHandler } from '@api/common-service/handler';

const router = require('express').Router();


router.get('/');
router.post('/',commonHandler);
router.get('/:id',commonHandler);
router.put('/:id',commonHandler);
router.delete('/:id',commonHandler);

module.exports = router