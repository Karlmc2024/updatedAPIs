import { commonHandler } from '@api/common-service/handler';
const router = require('express').Router();

router.get('/myorders', commonHandler);
router.get('/:orderId', commonHandler);
router.post('/', commonHandler);
router.get('/getDomainsToConfigure/:orderId', commonHandler);
router.get('/getDomainToConfigure/:domainId', commonHandler);
router.post(
  '/complete-domain-registration/:domainId',
  commonHandler
);
router.get('/coupons/getAvailableCoupons', commonHandler);
router.post('/applyCoupon', commonHandler);
router.post('/removeCoupon', commonHandler);


router.post('/cancel-order-transaction/:id', commonHandler);


module.exports = router;
