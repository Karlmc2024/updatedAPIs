const router = require("express").Router();
import { commonHandler } from "@api/common-service/handler";


import { domainSearch } from "./validator";
const { validateApiKey } = require("@middleware/validate-api-key");
router.get("/", commonHandler);
router.post("/search",domainSearch,commonHandler);
router.post("/searchMultipleTlds",commonHandler);
router.post("/mint", commonHandler);
router.get("/:id",commonHandler);
router.put("/:id",commonHandler);
// router.delete("/:id", deleteDomain);*/
module.exports = router;