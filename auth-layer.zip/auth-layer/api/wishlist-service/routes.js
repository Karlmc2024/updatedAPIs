const { commonHandler } = require('@api/common-service/handler');

const router = require('express').Router();

commonHandler


// get all cart items
// clear items
// delete one item
// add one item
router.get('/',commonHandler);
// router.delete('/:id',clearWishlist);
router.post('/',commonHandler);
router.delete('/:itemId',commonHandler);
router.put('/',commonHandler);
router.put('/:itemId/move-to-cart',commonHandler);

module.exports = router;
