
const router = require('express').Router();

import { commonHandler } from '@api/common-service/handler';
import {mitableTld} from  './validator';
commonHandler

router.get('/',commonHandler);
router.get('/mintable/:tldName',mitableTld,commonHandler);

module.exports = router;