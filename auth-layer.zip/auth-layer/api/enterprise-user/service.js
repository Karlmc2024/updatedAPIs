import { EnterpriseModel } from '@api/enterprise-service/model';
import { sendEjsEmail } from "../../lib/utils/email";
const ejs = require('ejs')
const path = require("path");
const fs = require("fs")
const generateLink = (req, userId, token) => {
	let { origin } = req.headers || `http://localhost:3000`;
	return origin + "/verify-account/" + userId + "/" + token
};
//import {CreditModel} from '../credit-system/model';
const jwt = require('jsonwebtoken');

//import {CartModel} from '../cart-service/model';

export const generateAccessToken = (payload)=>{
    return     jwt.sign(payload, process.env.TOKEN_SECRET, {
        algorithm: 'HS256',
        expiresIn: process.env.JWT_TOKEN_EXPIRY_MIN
    });
  };

/*const addNexbToeknsOnSignup = async(userId)=>{
    try {

        let obj = {};
        obj.userId = userId;
        obj.amount = 0;
        obj.nexbTokens = 50;
        const transaction  = {
            purchasedCredit: 0,
            allocatedTokens: 50,
            status:'custom',
            influencer:'none',
            transactionHash: ''
        };

        await CreditModel.findOneAndUpdate({userId:userId},{...obj ,
            $push:{
                transactionHistory:transaction
            }
        },{upsert:true, new : true});

    } catch (error) {
        logger.error(error);
    }
};*/


export const getLoginDetails = async(user)=>{
  /*let cart = await CartModel.findOne({userId:user._id});
  cart = cart.toJSON();*/
  user = user.toJSON();
  delete user.password;
  delete user.emailVerifyUrl;
  //user.cartId = cart._id;
  const token = generateAccessToken({_id:user._id, email:user.email});
  return {token,user};
};

export const sendSignUpEmail = async function (req,user,token) {
   try{
        let filePath = path.resolve(
            __dirname + "../../../lib/utils/templates/welcome.ejs"
        ),
        compiled = ejs.compile(fs.readFileSync(filePath, "utf8")),
        dataToCompile = {
            name: user.firstName,
        },
        Subject = "Welcome to NexBloc";

        if (token !== null) {
            sendVerificationMail(req,user,token)
        }
        sendEjsEmail(
        user.email,
        user.firstName,
        Subject,
        compiled(dataToCompile)
        );
   }
   catch(er){
        console.log(er.message)
   }
}

export const sendVerificationMail = async function (req,user,token){ 
    try{
        let verifyEmailTemplate = path.resolve(
            __dirname + "../../../lib/utils/templates/verify-email.ejs"
        ),
        emailCompiled = ejs.compile(
            fs.readFileSync(verifyEmailTemplate, "utf8")
        ),
        emailDataToCompile = {
            name: user.firstName,
            link: generateLink(req, user._id, token),
        };

        sendEjsEmail(
        user.email,
        user.firstName,
        "Email Verification",
        emailCompiled(emailDataToCompile)
        );
    }

    catch(err){
        console.log(err.message)
    }

}