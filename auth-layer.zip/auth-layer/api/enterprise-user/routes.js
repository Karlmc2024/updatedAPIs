const router = require('express').Router();

const UserController = require('./controller')
const {validateUserSignUp,verifyAccount} = require('./validator')

router.get("/me",UserController.getCurrentLoggedInUser)
router.put("/me",UserController.userUpdate)
router.post("/signup",UserController.registration);
router.post("/login",UserController.userLogin);
router.post("/admin-registration",UserController.adminRegistration)
router.get(
	"/verify-account/:userId/:token",
    verifyAccount,
	UserController.verifyAccount
);
router.put(
	"/reset-password/:userId/:token",
	verifyAccount,
	UserController.resetPassword
);
router.put("/change-password", UserController.changePassword);
router.post("/forgot-password", UserController.forgotPassword);
router.post("/resend-verification-email", UserController.resendVerifyEmail);

router.post("/google-signup",UserController.googleSignup);

router.post("/google-login", UserController.googleLogin);



module.exports = router;