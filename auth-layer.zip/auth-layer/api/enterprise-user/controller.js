import errorHandler from '../../lib/utils/error';
import { sendEjsEmail } from "../../lib/utils/email";
import { EnterpriseModel } from '@api/enterprise-service/model';
import { generateServiceLayerTokens } from '@api/common-service/configuration';
import { InvitationModel } from '@api/admin-service/invitation-service/model';
import {pusher} from '@lib/utils/pusher/pusher-util';
import { resolve } from 'path/win32';
const ejs = require('ejs')
const path = require("path");
const fetch = require('node-fetch')
const objectID = require('mongodb').ObjectID;
const fs = require("fs")
const randtoken = require("rand-token");
const {UserModel} = require('./model')
const {ForgotPasswordModel} = require('./forgot-password.model')
const {getLoginDetails, sendSignUpEmail, sendVerificationMail} = require('./service')
const { OAuth2Client } = require("google-auth-library");
const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);
const {promisify} = require('util')

export const registration = async (req, res) => {
	try {
		let token = null;
		let { body } = req;
		
		let find = await UserModel.findOne({ email: body.email }, {});
		if (find && find.email) {
            if(body.isPrimaryAdmin || body.isSuperAdmin){
				//if user already exist and trying to create admin or super admin return false as request will be from create api so that will send response
				return false;
			}

			return res.status(400).json({
				error: "Account Already Exist With Given Email, Please Login",
			});
		}
		if (!body.fromSSO) {
			token = randtoken.generate(32);
			body.emailVerifyUrl = token;
		} else {
			body.verified = true;
		}
		/*let twoFactorQR = "";
		if (body.twoFA) {
			secret = speakeasy.generateSecret({ name: "nexbloc" });
			body.secretTwoFactor = secret.base32;
			twoFactorQR = await QRCode.toDataURL(secret.otpauth_url);
		}*/
		//assigning object id manually here so that object id would be same on both auth layer and service layer
        const objectId = new objectID();
		body._id = objectId;
		//creating copy of user first on service layer if he is not admin
		
		if(!body.isPrimaryAdmin && !body.isSuperAdmin){
		body.role = "USER";
			const requestConfig = {
				method:req.method.toLowerCase(),
				body:JSON.stringify(body),
				headers:{
					'content-type':"application/json",
					'authorization':"Bearer "+generateServiceLayerTokens({service: "SERVICE_LAYER"}),
					'dbName':req.body.enterpriseId
				},
				
			}
			const userCopyPromise = await fetch('http://127.0.0.1:9000/api/signup',requestConfig)
		if(userCopyPromise.statusText !== 'Created'){
			//if creating admin or super admin failed

			if(body.isPrimaryAdmin || body.isSuperAdmin){
				return false
			}
				return res.status(400).json({ result: "Something Went Wrong" });
		}
	}
	else{
		body.role = req.body.isSuperAdmin ? "SUPER_ADMIN" :"ADMIN"
		console.log(body.role)
	}
		let user = await UserModel(body).save();
		const { email } = user;
		user.password = undefined;
		user.emailVerifyUrl = undefined
		

		//await createCart(user._id);
		//await createWishlist(user._id);
		if (user) {
			//mail sending will work in background and will not block rest of code for user
			sendSignUpEmail(req,user,token).then(resp => console.log('mail sent success'))

			//todo add check if env is production than only add data to contacts
			/*await createContact({
				firstName: body.firstName,
				lastname: body.lastName,
				email: body.email,
			});
			if (body.twoFA) {
				return res
					.status(201)
					.json({ result: "Signup Successful", qr: twoFactorQR });
			}*/
            if(body.isPrimaryAdmin ||body.isSuperAdmin){
			return user
            }
			//check if any invitation exist and update for this user
			const invitation = await InvitationModel.findOneAndUpdate({email},{status:"completed"},{new:true})
            return res.status(200).json({result:"Signup Successful"})
		}
		//if the request came from enterprise creation and user is not created return false and response will be sent using that api
		else if(body.isPrimaryAdmin ||body.isSuperAdmin){
			return false;
		}
		return res.status(400).json({ result: "Something Went Wrong" });
	} catch (error) {
		console.log(error)
		return errorHandler(error, 400, res);
	}
};


export const adminRegistration = async (req, res) => {
	try {
		let { body } = req;
		if(!["ADMIN","SUPER_ADMIN"].includes(req.me.role)){
			return res.status(400).json({
				error:"You do not have access to this service"
			})
		}
		let token = null;
		if(req.me.role === 'ADMIN')
		body.enterpriseId = req.me.enterpriseId;
		else if(req.me.role === 'SUPER_ADMIN')
		body.enterpriseId = req.me.currentOrganization
		
		let find = await UserModel.findOne({ email: body.email}, {});
		if (find && find.email) {
			return res.status(400).json({
				error: "Account Already Exist With Given Email, Please Login",
			});
		}
		if (!body.fromSSO) {
			token = randtoken.generate(32);
			body.emailVerifyUrl = token;
		} else {
			body.verified = true;
		}
		body.role = body.role || "ADMIN"
        const objectId = new objectID();
		body._id = objectId;
		//creating copy of user first on service layer if he is not admin
		body.role = 'ADMIN';
			const requestConfig = {
				method:req.method.toLowerCase(),
				body:JSON.stringify(body),
				headers:{
					'content-type':"application/json",
					'authorization':"Bearer "+generateServiceLayerTokens({service: "SERVICE_LAYER"}),
					'dbName':req.body.enterpriseId
				},
				
			}
		const userCopyPromise = await fetch('http://127.0.0.1:9000/api/signup',requestConfig)
		if(userCopyPromise.statusText !== 'Created'){
				return res.status(400).json({ result: "Something Went Wrong" });
		}
		let user = await UserModel(body).save();
		
		//await createCart(user._id);
		//await createWishlist(user._id);
		if (user) {
			
			//mail sending will work in background and will not block rest of code for user
			sendSignUpEmail(req,user,token).then(resp => console.log('mail sent success'))
			//todo add check if env is production than only add data to contacts
			/*await createContact({
				firstName: body.firstName,
				lastname: body.lastName,
				email: body.email,
			});
			if (body.twoFA) {
				return res
					.status(201)
					.json({ result: "Signup Successful", qr: twoFactorQR });
			}*/
            return res.status(200).json({result:"Signup Successful"})
		}
		return res.status(400).json({ result: "Something Went Wrong" });
	} catch (error) {
		console.log(error)
		return errorHandler(error, 400, res);
	}
};
export const verifyAccount = async (req, res, next) => {
	try {
		const { token, userId } = req.params;		
		let user = await UserModel.findOne({ _id: userId }, {});
		if (!user) {
			return errorHandler(
				{ error: "Invalid Verification Link" },
				401,
				res
			);
		}

		if (user && user.verified) {
			return res.status(200).json({ result: true });
		}
		// eslint-disable-next-line security/detect-possible-timing-attacks
		if (token == user.emailVerifyUrl) { 
			const updateUser = await UserModel.findByIdAndUpdate(userId,
				{ verified: true },{new:true}
			);
			if(!updateUser){
				return errorHandler(
					{ error: "Invalid Verification Link" },
					401,
					res
				);
			}
			//update onboarding status of enterprise if user is primary Admin
			if(updateUser.isPrimaryAdmin){
				await EnterpriseModel.findByIdAndUpdate(updateUser.enterpriseId,{
					onboardingStatus: 'Approved' //'EmailVerification' TODO Status skipped to auto approve
				})
				const pusherEventObj = {
					toUserIds: updateUser._id,
					fromEmail: updateUser.email,
					fromName: `${updateUser.firstName} ${updateUser.lastName}`,
		
				}
				pusher.trigger(`Nexbloc-sdk-${updateUser.enterpriseId}`,'status-update',pusherEventObj)
			}

			//addNexbToeknsOnSignup(userId);
			return res.status(200).json({ result: true });
		}
		return errorHandler({ error: "Invalid Verification Link" }, 401, res);
	} catch (err) {
		return errorHandler(err, 401, res);
	}
};

export const userLogin = async (req, res) => {
	try {
		let { email, password} = req.body;
		let user = await UserModel.findOne({ email});
		if (!user) {
			return res
				.status(400)
				.json({ error: "Incorrect Email or Password" });
		}
		const correctPassword = await user.isValidPassword(password);
		if (!correctPassword) {
			return res
				.status(400)
				.json({ error: "Incorrect Email or Password" });
		}

		if (user.twoFA) {
			return res.status(200).json({ twoFAEnabled: user.twoFA, user });
		}
		const loginDetails = await getLoginDetails(user);

		if (user.firstLogin) {
			await UserModel.findByIdAndUpdate(user._id, {
				firstLogin: false,
			});
		}
		return res.status(200).json({ result: loginDetails });
	} catch (error) {
		return errorHandler(error, 400, res);
	}
};
export const adminLogin = async (req, res) => {
	try {
		let { email, password} = req.body;
		let user = await UserModel.findOne({ email}).populate({
			path:'enterpriseId',
			select:'onboardingStatus'
		})
		if (!user) {
			return res
				.status(400)
				.json({ error: "Incorrect Email or Password" });
		}
		const correctPassword = await user.isValidPassword(password);
		if (!correctPassword) {
			return res
				.status(400)
				.json({ error: "Incorrect Email or Password" });
		}
        if(user.role !=='ADMIN' && user.role!=="SUPER_ADMIN"){
			return res.status(400).json({
				error:"Only Admins have access to this service"
			})
		}
		if (user.twoFA) {
			return res.status(200).json({ twoFAEnabled: user.twoFA, user });
		}
		const loginDetails = await getLoginDetails(user);

		if (user.firstLogin) {
			await UserModel.findByIdAndUpdate(user._id, {
				firstLogin: false,
			});
		}
		return res.status(200).json({ result: loginDetails });
	} catch (error) {
		return errorHandler(error, 400, res);
	}
};
export const userUpdate = async (req, res) => {
	try {
		let body = req.body;
		const requestConfig = {
			method:req.method.toLowerCase(),
			body:JSON.stringify(body),
			headers:{
				'content-type':"application/json",
				'authorization':"Bearer "+generateServiceLayerTokens({service: "SERVICE_LAYER"}),
				'me':JSON.stringify(req.me),
				'dbName':req.me.enterpriseId
			},
			
		}
		const userCopyPromise = await fetch('http://127.0.0.1:9000/api/user',requestConfig)
		if(userCopyPromise.statusText !== 'Created'){
			return res.status(400).json({ result: "User Update Failed" });
		}
		const serviceLayerUser = await userCopyPromise.json()
		let user = await UserModel.findOneAndUpdate(
			{ _id: req.me._id },
			body,
			{ new: true }
		);
		if (user) {
			user = user.toJSON();
			delete user.password;
			delete user.emailVerifyUrl;
			user.totalDomains = serviceLayerUser.totalDomains || 0
			return res.status(201).json({ result: user });
		}
		return res.status(400).json({ error: "Something Went Wrong" });
	} catch (error) {
		return errorHandler(error, 400, res);
	}
};
export const resetPassword = async (req, res) => {
	try {
		const { token, userId} = req.params;
		const { password } = req.body;
		const user = await UserModel.findOne({_id:userId});
		if (!user) {
			return res.status(400).send({ error: "invalid link or expired" });
		}
		const forgotPassword = await ForgotPasswordModel.findOne({
			userId: user._id,
			token: req.params.token,
		});
		if (!token) {
			return res
				.status(400)
				.send({ error: "Link  has been expired or invalid link" });
		}
		user.password = password;
		await user.save();
		await forgotPassword.delete();

		res.status(200).json({ result: "password reset successfully." });
	} catch (err) {
		return errorHandler(err, 401, res);
	}
};

export const changePassword = async (req, res) => {
	try {
		const userId = req.me._id;
		const { password } = req.body;
		const user = await UserModel.findOne({_id:userId});
		if(!user){
			const error = new error("No such user exist on this enterprise")
			return errorHandler(error,400,res)
		}
		user.password = password;
		await user.save();

		res.status(200).json({ result: "password reset successfully." });
	} catch (err) {
		return errorHandler(err, 401, res);
	}
};

export const forgotPassword = async (req, res) => {
	try {
		const { email} = req.body;
		let { origin } = req.headers;
		const user = await UserModel.findOne({ email: email});

		if (!user) {
			return errorHandler(
				{ message: "No account exists with a given email" },
				400,
				res
			);
		}
		let { _id: userId } = user;
		let token = await ForgotPasswordModel.findOne({ userId });
		if (!token) {
			token = await new ForgotPasswordModel({
				userId,
				token: randtoken.generate(16),
			}).save();
		}
		let link = origin + "/reset-password/" + userId + "/" + token.token;
		let filePath = path.resolve(
				__dirname + "../../../lib/utils/templates/forgot-password.ejs"
			),
			compiled = ejs.compile(fs.readFileSync(filePath, "utf8")),
			dataToCompile = {
				link: link,
				toName: user.firstName,
			},
			Subject = "Reset Password Link";

		sendEjsEmail(email, user.firstName, Subject, compiled(dataToCompile));
		// let emailSentResult = await sendEmail({to:email,subject:'Reset Password Link',text:`Please use the below link to reset your password ${link}`});
		res.status(200).json({
			result: "Please check your email for the reset link",
		});
	} catch (error) {
		return errorHandler(error, 400, res);
	}
};

export const googleSignup = async (req, res) => {
	try {
		let{ profileObj } = req.body;

		async function verify() {
			const ticket = await client.verifyIdToken({
				idToken: req.body.tokenId,
				audience: process.env.GOOGLE_CLIENT_ID, // Specify the CLIENT_ID of the app that accesses the backend
			});
			const payload = ticket.getPayload();
			return payload;
		}

		verify()
			.then(async (data) => {
				if (profileObj.email === data.email && data.email_verified) {
					let user = await axios.post(
						process.env.URL + "/api/user/signup",
						{
							email: profileObj.email,
							firstName: profileObj.givenName,
							lastName: profileObj.familyName,
							password: profileObj.googleId,
							fromSSO: "google",
						},
						{
							headers: {
								origin: req.headers.origin,
							},
						}
					);

					//let userData = await UserModel.findOne({email:profileObj.email },{_id:1})
					// addNexbToeknsOnSignup(userData._id);

					return res
						.status(201)
						.json({ result: "Signup Successful" });
				} else {
					return errorHandler(
						{
							error: "Google auth expired",
						},
						400,
						res
					);
				}
			})
			.catch((e) => {
				console.log(e)
				return errorHandler(e.response && e.response.data, 401, res);
			})
	} catch (e) {
		return errorHandler(e.response && e.response.data, 401, res);
	}
};

export const googleLogin = async (req, res) => {
	try {
		let { profileObj } = req.body;

		async function verify() {
			const ticket = await client.verifyIdToken({
				idToken: req.body.tokenId,
				audience: process.env.GOOGLE_CLIENT_ID, // Specify the CLIENT_ID of the app that accesses the backend
			});
			const payload = ticket.getPayload();
			return payload;
		}
		verify()
			.then(async (data) => {
				if (profileObj.email === data.email && data.email_verified) {
					let user = await UserModel.findOne({ email: data.email});
					if (!user) {
						return errorHandler(
							{ message: "Incorrect Email or Password" },
							400,
							res,
							false
						);
					}
					const loginDetails = await getLoginDetails(user);

					if (user.firstLogin) {
						await UserModel.findByIdAndUpdate(loginDetails._id, {
							firstLogin: false,
						});
					}
					return res.status(200).json({ result: loginDetails });
				} else {
					return errorHandler(
						{
							error: "Google auth expired",
						},
						400,
						res
					);
				}
			})
			.catch(e => console.log(e));
		
	} catch (e) {
		logger.error(e);
		return errorHandler(e.response && e.response.data, 401, res);
	}
};

export const resendVerifyEmail = async (req, res) => {
	try {
		let token = randtoken.generate(32);
		let user = await UserModel.findOneAndUpdate(
			{ _id: req.locals.user._id },
			{ emailVerifyUrl: token },
			{new:true}
		);
		if(!user){
			return errorHandler(
				{ error: "Email Verification Request Failed" },
				401,
				res
			);
		}
		await sendVerificationMail(req,user,token)
		return res
			.status(200)
			.json({ result: "Email verification link has been sent" });
	} catch (error) {
		return errorHandler(error, 400, res);
	}
};

export const getAllAdminsByEnterprise = async(req,res,next) => {
	try{
       const {enterpriseId} = req.params
	   if(!enterpriseId){
			const error = new Error("Please provide enterprise id");
			return errorHandler(error,400,res)
	   }
	   const enterpriseAdmins = await UserModel.find({
		enterpriseId,
		role:"ADMIN"
	   }).select('-password -emailVerifyUrl')
	   return res.status(200).json({result:enterpriseAdmins})
	}
	catch(error){
		return errorHandler(error,400,res)
	}
}

export const getAdminDetails = async(req,res,next) => {
	try{
		const adminId = req.params.id;
		if(!adminId){
			const error = new Error("Please provide id");
			return errorHandler(error,400,res)
		}
		const admin = await UserModel.findOne({role:"ADMIN",enterpriseId:req.me.enterpriseId,_id:adminId}).select('-password -emailVerifyUrl')
		if(!admin){
            const error = new Error("No such user exist")
			return errorHandler(error,400,res)
		}
        return res.status(200).json({result:admin})
		
	}
	catch(error){
        return errorHandler(error,400,res)
	}
}


export const deleteAdmin = async(req,res,next) => {
	try{
		const adminId = req.params.id;
		if(!adminId){
			const error = new Error("Please provide id");
			return errorHandler(error,400,res)
		}
		const user = await UserModel.findOne({_id:adminId,role:"ADMIN"})
		const isPrimaryAdmin = user && user.isPrimaryAdmin
		if(!user || (isPrimaryAdmin)){
			const message =  isPrimaryAdmin ? "Primary Admin cannot be deleted":"No such user exist"
			const error = new Error(message);
			return errorHandler(error,400,res)
		}
		//if the one who delete is admin check if both are part of same enterprise
		if(req.me.role ==='ADMIN' && (req.me.enterpriseId.toString() != user.enterpriseId.toString())){
			const error = new Error("You dont have access to this service")
			return errorHandler(error,400,res)
		}
		//finally delete it from here
		try{
			await user.delete()
		}
		catch(err){
			const error = new Error("Something went wrong while deleting user")
			return errorHandler(error,400,res)
		}
		return res.status(200).json({result:{message:"User Deleted Successfully"}})
	}
	catch(error){
		console.log(error)
        return errorHandler(error,400,res)
	}
}




export const revokeAdminAccess = async(req,res,next) => {
	try{
		const adminId = req.params.id;
		if(!adminId){
			const error = new Error("Please provide id");
			return errorHandler(error,400,res)
		}
		const user = await UserModel.findOne({_id:adminId,role:"ADMIN"})
		const isPrimaryAdmin = user && user.isPrimaryAdmin
		if(!user || (isPrimaryAdmin)){
			const message =  isPrimaryAdmin ? "Primary Admin cannot be deleted":"No such user exist"
			const error = new Error(message);
			return errorHandler(error,400,res)
		}
		//if the one who delete is admin check if both are part of same enterprise
		if(req.me.role ==='ADMIN' && (req.me.enterpriseId.toString() != user.enterpriseId.toString())){
			const error = new Error("You dont have access to this service")
			return errorHandler(error,400,res)
		}
		//finally revoke role  from here
		try{
			user.role = 'USER';
			await user.save()
		}
		catch(err){
			const error = new Error("Something went wrong while revoking access")
			return errorHandler(error,400,res)
		}
		return res.status(200).json({result:{message:"Access Revoked Successfully"}})
	}
	catch(error){
		console.log(error)
        return errorHandler(error,400,res)
	}
}

export const getCurrentLoggedInUser = async(req,res,next) => {
	try{
		if(!req.me){
			const error = new Error("Please Log In Again")
			return errorHandler(error,400,res)
		}
		if(req.me.role === "ADMIN" && req.me.enterpriseId) {
			const result = req.me;
			const exterprise = await EnterpriseModel.findById(req.me.enterpriseId);
			result['enterpriseId'] = exterprise;
			return res.status(200).json({
				result:result
			});
		} else {
			return res.status(200).json({
				result:req.me
			})
		}
	}
	catch(err){
		return errorHandler(err,400,res)
	}
}
