const mongoose = require('mongoose');
const objectId = mongoose.Schema.Types.ObjectId;
const bcrypt = require("bcrypt");
export const UserSchema = new mongoose.Schema({
    firstName:{
       type:String,
       required:[true,'firstName is required']
    },
    lastName:{
       type:String,
       required:[true,'lastName is required']
    },
    email:{
        type:String,
        required:[true,'email is required'],
        unique:true
    },
    password:{
        type:String,
        required:true,
      
    },
    isPrimaryAdmin:{
        type:Boolean,
        default:false
    },
    verified: {
        type: Boolean, 
        default: false
    },
	emailVerifyUrl: {
         type: String
    },
	emailNotifications: {
         type: Boolean,
          default: false 
    },
	secretTwoFactor: { 
        type: String, 
        required: false 
    },
	firstLogin: {
         type: Boolean, 
         default: true 
    },
    role:{
        type:String,
        enum:["SUPER_ADMIN","ADMIN","USER"],
        default:"USER"
    },
    currentOrganization:{
        type:objectId,
        ref:"Enterprise"
    },
    enterpriseId:{
        type:objectId,
        ref:"Enterprise"
    }

},{ timestamps: true, versionKey: false })

UserSchema.pre("save", async function(next) {
	//Replace the plain text password with the hash
	let salt = await bcrypt.genSalt(parseInt(process.env.HASH_COST));
	this.password = await bcrypt.hash(this.password, salt);
	next();
});

// compare the body password with encrypted password
UserSchema.methods.isValidPassword = async function(password) {
	const doc = await this.model("User").findOne({ _id: this._id }, "password");
	return await bcrypt.compare(password, doc.password);
};
export const UserModel = mongoose.model('User',UserSchema);