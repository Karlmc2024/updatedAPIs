const express = require('express');
const router = express.Router();
const invitationController = require('./controller')

router.post('/',invitationController.sendInvitationToEmail)
router.get('/list',invitationController.getAllInvitationOfEnterprise)
router.get('/:id',invitationController.getSingleInvitationDetail)
router.get('/by-user/:userId',invitationController.getAllInvitationByUser)

module.exports = router