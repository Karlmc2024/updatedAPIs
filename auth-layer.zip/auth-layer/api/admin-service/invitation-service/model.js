const mongoose = require('mongoose')
const objectId = mongoose.Schema.Types.ObjectId;

const invitationSchema = new mongoose.Schema({
    email:{
        type:String,
        required:[true,"email id is required"]
    },
    invitedBy:[{
        type:objectId,
        ref:"User"
    }],
    enterpriseId:{
        type:objectId,
        ref:"Enterprise"
    },
    status:{
        type:String,
        enum:["pending","completed"]
    }
})

export const InvitationModel = mongoose.model("InvitedUser",invitationSchema)