import { UserModel } from '@api/enterprise-user/model'
import { EnterpriseModel } from '@api/enterprise-service/model'
import { sendEjsEmail } from '@lib/utils/email'
import path from 'path'
const ejs = require('ejs')
const fs = require('fs')

const { default: errorHandler } = require('@lib/utils/error')
const {InvitationModel} = require('./model')


//send New Invitation


export const sendInvitationToEmail = async (req,res,next) => {
    try{

        const {email} = req.body
        
        let invitation
        invitation = await InvitationModel.findOne({
            email
        })

        //check if any invitation already exist then only push userid of person who invited in that invitedBy Array
        if(invitation){
            if(invitation.status === 'completed'){
                    const error = new Error("This User is Already Registered")
                    return errorHandler(error,400,res)
            }
            //if this user already invited just send mail do not create new Invitation
            if(!invitation.invitedBy.includes(req.me._id)){

                invitation = await InvitationModel.findByIdAndUpdate(invitation._id,
                    {$push:{invitedBy:req.me._id}},
                    {new:true})
                }
            
        }
        else{
            invitation = await InvitationModel.create({
                email,
                invitedBy:[req.me._id],
                enterpriseId:req.me.enterpriseId,
                status:"pending"
            })
       }

        let filePath = path.resolve(
        __dirname + "../../../../lib/utils/templates/invitation-email.ejs"
        )
        const enterprise = await EnterpriseModel.findById(req.me.enterpriseId)
        const compiled = ejs.compile(fs.readFileSync(filePath, "utf8")),
        dataToCompile = {
            name: req.body.email.split('@')[0],
            senderName:req.me.firstName+ " "+req.me.lastName,
            organizationName:enterprise.organizationName
        },
        
        Subject = `Invitation from ${enterprise.organizationName}`;


        sendEjsEmail(
                req.body.email,
                req.body.email.split('@')[0],
                Subject,
                compiled(dataToCompile)
        );
        return res.status(200).json({message:"Invitation Sent Successfully"})
    }
    catch(err){
        return errorHandler(err,400,res)
    }

}



//getAllInvitation by user
export const getAllInvitationByUser = async(req,res,next) => {
    try{
        const {userId} = req.params
        //if user exist for which we try to find invitation
        if(!userId){
            const error = new Error("User Id is Required")
            return errorHandler(error,400,res)
        }
        const isUserExist = await UserModel.findOne({_id:userId})
        if(!isUserExist){
            const error = new Error("No such user exist")
            return errorHandler(error,400,res)
        }
        const allInvitation = await InvitationModel.find({invitedBy:{
            $in:[userId]
        }})
        return res.status(200).json({result:allInvitation})

    }
    catch(err){
        return errorHandler(err,400,res)
    }
}

//getAllInvitation of enterprise
export const getAllInvitationOfEnterprise = async(req,res,next) => {
    try{
        const invitations = await InvitationModel.find({enterpriseId:req.me.enterpriseId})
        if(invitations.length <= 0){
            const error = new Error("No invitation exist for this enterprise")
            return errorHandler(error,400,res)
        }
        return res.status(200).json({result:invitations})
    }
    catch(err){
        return errorHandler(err,400,res)
    }
}


//getSingleInvitationDetail

export const getSingleInvitationDetail = async(req,res,next) => {
    try{
        const invitationId = req.params.id
        if(!invitationId){
            const error = new Error("Please provide invitation Id")
            return errorHandler(error,400,res)
        }
        const invitation = await InvitationModel.findById(invitationId)
        if(!invitation){
            const error = new Error("No such invitation exist")
            return errorHandler(error,400,res)
        }
        return res.status(200).json({result:invitation})

    }
    catch(err){
        return errorHandler(err,400,res)
    }
}