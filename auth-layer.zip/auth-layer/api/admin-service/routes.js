/************************ EXPRESS MODULES AND LIBRARIES *********************/
/*eslint-disable*/
'use strict';
const express = require('express');
const router = express.Router();
import { commonHandler } from '@api/common-service/handler';
import { fetchDbForAdmin } from '@middleware/fetchDbForAdminAnalytics';
import { isAdmin } from '@middleware/auth';
const invitationRouter = require('./invitation-service/routes')

router.use('/invitations',isAdmin,invitationRouter)


/****************************USER AND SALE  DASHBOARD REPORT  ******************/
router.get("/:entepriseId/dashboard-sale-report", isAdmin,fetchDbForAdmin,commonHandler);
router.get("/:entepriseId/dashboard-user-report",isAdmin,fetchDbForAdmin, commonHandler);

/**************************** USER  REPORT *************************************/
router.get('/:enterpriseId/users', isAdmin,fetchDbForAdmin,commonHandler);
router.get('/:enterpriseId/search-user', isAdmin,fetchDbForAdmin,commonHandler);
router.get('/:enterpriseId/user-detail/:_id', isAdmin,fetchDbForAdmin,commonHandler);
router.get('/:enterpriseId/user-domains/:_id', isAdmin,fetchDbForAdmin,commonHandler);
router.get('/:enterpriseId/current-year-monthly-users',isAdmin,fetchDbForAdmin,commonHandler);
router.get('/:enterpriseId/user-yearly-report',isAdmin,fetchDbForAdmin, commonHandler);
router.get('/:enterpriseId/current-month-users',isAdmin,fetchDbForAdmin,commonHandler);
router.get('/:enterpriseId/today-user-count', isAdmin,fetchDbForAdmin,commonHandler);

/*************************** DOMAIN DETAIL REPORT  *****************************/
router.get('/:enterpriseId/domains',isAdmin,fetchDbForAdmin,commonHandler);
router.get('/:enterpriseId/domain-detail/:_id',isAdmin,fetchDbForAdmin, commonHandler);
router.get('/:enterpriseId/search-domain',isAdmin,fetchDbForAdmin,commonHandler);
router.get('/:enterpriseId/today-domain-count',isAdmin,fetchDbForAdmin, commonHandler);
router.get('/:enterpriseId/total-book-domain',isAdmin,fetchDbForAdmin, commonHandler);
router.get('/:enterpriseId/total-sold-premium-domains',isAdmin,fetchDbForAdmin, commonHandler);
router.get('/:enterpriseId/bought-domain/:userId',isAdmin,fetchDbForAdmin,commonHandler)
router.get('/:enterpriseId/bought-domain',isAdmin,fetchDbForAdmin,commonHandler)
/*************************** PREMIUM  DOMAIN  REPORT **************************/
router.get('/:enterpriseId/premium-domains/',isAdmin,fetchDbForAdmin,commonHandler);
router.post('/:enterpriseId/add-premium-domain',isAdmin,fetchDbForAdmin, commonHandler);
router.get('/:enterpriseId/premium-domain-detail/:_id',isAdmin,fetchDbForAdmin, commonHandler);
router.get('/:enterpriseId/search-premium-domain',isAdmin,fetchDbForAdmin, commonHandler);
router.get('/:enterpriseId/premium-domain-count',isAdmin,fetchDbForAdmin,commonHandler)
router.get('/:enterpriseId/premium-domain/sold-by-total',isAdmin,fetchDbForAdmin,commonHandler)

/**************************** SALES REPORT  ****************************************/
router.get('/:enterpriseId/monthly-sale',isAdmin,fetchDbForAdmin, commonHandler);
router.get('/:enterpriseId/yearly-sale-report',isAdmin,fetchDbForAdmin, commonHandler);
router.get('/:enterpriseId/current-month-sale',isAdmin,fetchDbForAdmin, commonHandler);
router.get('/:enterpriseId/total-sale',isAdmin,fetchDbForAdmin, commonHandler);
router.get('/:enterpriseId/sale-report',isAdmin,fetchDbForAdmin,commonHandler);
router.get('/:enterpriseId/today-sale-count', isAdmin,fetchDbForAdmin,commonHandler);

/*****************************TradeMark request */

router.post('/:enterpriseId/trademarks',isAdmin,fetchDbForAdmin, commonHandler);
router.get('/:enterpriseId/trademarks', isAdmin,fetchDbForAdmin,commonHandler);
router.delete('/:enterpriseId/trademarks/:id',isAdmin,fetchDbForAdmin, commonHandler);
router.get('/:enterpriseId/trademarks/request', isAdmin,fetchDbForAdmin,commonHandler);
router.get('/:enterpriseId/trademarks/request/search',isAdmin,fetchDbForAdmin, commonHandler);
router.put('/:enterpriseId/trademarks/request/:id',isAdmin,fetchDbForAdmin, commonHandler);

/****************************** Tld  **********************************/
router.get('/:enterpriseId/tld',isAdmin,fetchDbForAdmin, commonHandler);
router.put('/:enterpriseId/tld/:id', isAdmin,fetchDbForAdmin,commonHandler);
router.post('/:enterpriseId/tld',isAdmin,fetchDbForAdmin, commonHandler);

/*************Discounts ************************ */
router.route('/:enterpriseId/discounts').post(isAdmin,fetchDbForAdmin,commonHandler).get(isAdmin,fetchDbForAdmin,commonHandler)
router.route('/:enterpriseId/discounts/:id').get(isAdmin,fetchDbForAdmin,commonHandler).put(isAdmin,fetchDbForAdmin,commonHandler).delete(isAdmin,fetchDbForAdmin,commonHandler)

/******************************** END *********************************************/
module.exports = router;
