const router = require('express').Router();
import { commonHandler } from "@api/common-service/handler";
import { validateLog } from "./validator";
commonHandler

router.post('/',validateLog,commonHandler)
router.put('/sync',commonHandler);
router.put('/:id',commonHandler)


module.exports = router;
