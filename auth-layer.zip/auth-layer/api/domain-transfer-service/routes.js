const router = require("express").Router();

import { commonHandler } from "@api/common-service/handler";
import {
	validateDomainTransferRequest,
	validateUpdateDomainTransferRequest,
	params,
} from "./validator";

router.post("/", validateDomainTransferRequest, commonHandler);
router.get("/", commonHandler);
router.get("/:id",commonHandler);
router.put(
	"/:id",
	params,
	validateUpdateDomainTransferRequest,
	commonHandler
);
router.delete("/:id", params, commonHandler);

module.exports = router;