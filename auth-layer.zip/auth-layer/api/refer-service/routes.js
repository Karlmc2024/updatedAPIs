const { commonHandler } = require('@api/common-service/handler');
const express  = require('express');
const router  = express.Router();
const {validateEmail , validateid}  = require('./validator');
commonHandler


router.get('/', commonHandler);
router.get('/refer-detail/:_id' , validateid, commonHandler);
router.post('/', validateEmail, commonHandler);
router.get('/success', commonHandler);
router.get('/fail', commonHandler);
router.get('/success-count',commonHandler);
router.get('/fail-count', commonHandler);


module.exports  = router;