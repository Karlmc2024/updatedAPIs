import { commonHandler } from '@api/common-service/handler';
const router = require('express').Router();


// get all cart items
// clear items
// delete one item
// add one item
router.get('/resolve-url',commonHandler);
router.post('/resolve-url',commonHandler);
router.get('/resolve-address',commonHandler);
router.post('/resolve-address',commonHandler);
router.post('/greeter',commonHandler);

module.exports = router;