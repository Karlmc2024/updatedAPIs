



const fetch = require('node-fetch');

export const sendRequestToServiceLayer = async (requestConfig) => {
    try{
        const url = requestConfig.url
        delete requestConfig.url
        const responsePromise = await fetch(url,requestConfig)
        const response = await responsePromise.json()
        if(responsePromise.status >= 400 ){
            return {success:false,response:response || "Error in Response"}
        }
        return {success:true,response:response}
    }
    catch(error){
        return {success:false,response:error.message}
    }
}