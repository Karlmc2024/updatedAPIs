


const jwt = require('jsonwebtoken')


export function generateServiceLayerTokens(payload) {
  
    const accessTokenSecret = process.env.ACCESS_TOKEN_SECRET
    const accessToken = jwt.sign(payload, accessTokenSecret, {
        expiresIn: '5m'
    });
    return accessToken;
}


export const createConfig = (url, method, body, headers) => {
  try{
      if (!url || !method) {
          return {success:false,message:"Invalid Request"}
      }
      delete headers.authorization
      delete headers['x-api-key']
      delete headers ['content-type']

      let requestConfig = {
          method:method.toLowerCase(),
          url:process.env.SERVICE_LAYER_URL+url,
          headers: {
          "content-type": "application/json",
          "authorization": "Bearer "+generateServiceLayerTokens({ service: "SERVICE_LAYER" }),
          ...headers
          },
      }
      if (['post','patch','put'].includes(requestConfig.method)) {
        if(!body){
          return {success:false,message:"Invalid Request"}
        }
        body = JSON.stringify(body)
        requestConfig.body = body 
      }
      return {success:true,config:requestConfig}
  }
  catch(error){
    console.log(error.message)
  }
}