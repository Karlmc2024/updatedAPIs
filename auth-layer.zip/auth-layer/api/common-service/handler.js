import errorHandler from "@lib/utils/error"
import { createConfig } from "./configuration"
import { sendRequestToServiceLayer } from "./request"


export const commonHandler = async(req,res) => {
    try{
        const requestUrl = req.originalUrl
        const body = req.body || {}
        req.headers.me = JSON.stringify(req.me || {})
        const requestConfiguration = createConfig(requestUrl,req.method,body,req.headers)
    
        if(!requestConfiguration.success){
            return errorHandler({error:requestConfiguration.message || 'something went wrong'},400,res)
        }
        const serviceLayerResponse =await sendRequestToServiceLayer(requestConfiguration.config)
        if(!serviceLayerResponse.success){
            return errorHandler(serviceLayerResponse.response,400,res)
        }
        return res.status(200).json(serviceLayerResponse.response)
    }
    catch(error){
        //console.log(error);
        return errorHandler(error,400,res)
    }
}