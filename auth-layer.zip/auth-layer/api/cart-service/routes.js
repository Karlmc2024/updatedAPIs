import { commonHandler } from '@api/common-service/handler';

const router = require('express').Router();

router.route('/')
.post(commonHandler)
.get(commonHandler)
.put(commonHandler)

router.delete('/:itemId',commonHandler);

router.put('/:itemId/move-to-wishlist',commonHandler);
router.put('/executeCartMail/:userId', commonHandler);

module.exports = router