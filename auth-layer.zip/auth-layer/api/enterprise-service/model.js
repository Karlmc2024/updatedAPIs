


const mongoose = require('mongoose');
const crypto = require("crypto-js");
const objectId = mongoose.Schema.Types.ObjectId;
const mixed = mongoose.Schema.Types.Mixed;
const enterpriseSchema = new mongoose.Schema({
    organizationName:{
        type:String,
        required:[true,"enterprise must have name"],
        unique:true
    },
    brandText:{
        type:String,
        required:false
    },
    brandLogo:{
        type:String,
        required:false
    },
    favicon:{
        type:String,
        required:false
    },
    platformName:{
        type:String,
        default:""
    },
    themePrimaryColor:{
        type:String,
        default:"#000000"
    },
    themeSecondaryColor:{
        type:String,
        default:"#000000"
    },
    homepageH1Title:{
        type:String,
        required:false
    },
    completionIndicator:{
        registration:{
            type:Boolean,
            default:false
        },
        profileForm:{
            type:Boolean,
            default:false
        },
        metaInfoForm:{
            type:Boolean,
            default:false
        },
        isMinted:{
            type:Boolean,
        },
        isSetupCompleted:{
            type:Boolean,
        },
    },
    industryType:{},
    description:{
        type:String
    },
    onboardingStatus:{
          type:String,
          enum:['Invited','SignedUp','AddedByAdmin','EmailVerification','Approved','Rejected','OnboardingSubmission','ApprovedToPay','Paid','SettingUp','SpinedUp','Complete'],
    },
    spinUpStatus: {
        type: String,
        enum: ['ContractsDeployed', 'DBSetupDone', 'AssetsCreated', 'Web3Provisioned', 'FrontendEnvGenerated', 'BackendEnvGenerated', 'APIGatewayDone', 'DNSDone']
    },
    heroImage:{
        type:String,
        required:false,
    },
    backgroundColor:{
        type:String,
        required:false
    },
    navbarColor:{
        type:String,
        required:false
    },
    contactEmail:{
        type:String,
        required:false
    },
    //-------environment variable for each enterprise-----------------

	HUBSPOT_API_KEY : {type:String,alias:'hubspot_api_key',select:false,},
	S3_bucket : {type:String,alias:"s3_bucket",select:false},
	S3_region: {type:String,alias:"s3_region",select:false},
	SPARKPOST_API_KEY : {type:String,alias:"sparkpost_api_key",select:false},
	STRIPE_SECRET_KEY : {type:String,alias:"stripe_secret_key",select:false},
	XDC_PRIVATE_KEY :{type:String,alias:"xdc_private_key",select:false},
	XDC_REGISTRAR_CONTRACT_ADDRESS : {type:String,alias:"xdc_registrar_contract_address",select:false},
	orderLimit:{type:Number,select:false}

},{toJSON:{virtuals:true},toObject:{virtuals:true}, timestamps: true, versionKey: false })

const metaDataAdditionalInfoSchema = new mongoose.Schema({
    label:{
    type:String,
    default:''
    },
    key:{
        type:String,
        default:''
    },
    type:{
        type:String,
        enum:["url","text","address","folder"]
    }
},{_id:false})

const enterpriseMetaDataSchema = new mongoose.Schema({
    enterpriseId:{
        type:objectId,
        required:true,
        ref:'Enterprise'
    },
    socialMedia:{
        linkedin:String,
        facebook:String,
        instagram:String,
        twitter:String
    },
    tlds: {
        type:Array,
        required:false,
        default:[]
    },
    restrictedSignup:{
        type:Boolean,
        required:false,
        default: false 
    },
    allowedEmailType:{
        type:Array,
        required:false,
        default: [] 
    },
    domainLimit:{
        type:Number,
        required:false,
        default:100000 
    },
    additionalInfo:[metaDataAdditionalInfoSchema],
    componentsEnabled:{
        premiumDomain: {type: Boolean, default: false},
        domainTransfer: {type: Boolean, default: false},
        discountingModule: {type: Boolean, default: false},
        userAuthMfa: {type: Boolean, default: false},
    },
    chainSupport:String,
    landingPageTemplate:{
        domainSearch: {type: Boolean, default: false},
        premiumDomain: {type: Boolean, default: false}
    }

},{ timestamps: true, versionKey: false })
const enterpriseKeySchema = new mongoose.Schema({
    enterpriseId:{
        type:objectId,
        required:true
    },
    key:{
        type:String,
        required:true
    },
    type:{
        type:String,
        enum:['test','live'],
        required:true
    },
    active:{
        type:Boolean,
        default:true
    }
},{timestamps: true, versionKey: false })

//virtual populate
enterpriseSchema.virtual('keys',{
    ref:'EnterpriseKey',
    foreignField:'enterpriseId',
    localField:'_id'
})

//encrypt the key before saving it

enterpriseKeySchema.pre("save", async function(next) {
	if (this.key) {
		this.key= crypto.AES.encrypt(
			this.key,
			process.env.API_KEY_SECRET
		).toString();
	}
	next();
});

//decrypt key mongoose methods
enterpriseKeySchema.methods.decryptApiKey = function(){
    if(this.key){
    const decryptKey = crypto.AES.decrypt(this.key,process.env.API_KEY_SECRET);
    this.key = decryptKey.toString(crypto.enc.Utf8);
    }
    return;
}

export const EnterpriseModel = mongoose.model('Enterprise',enterpriseSchema);

export const EnterpriseMetaDataModel = mongoose.model('EnterpriseMetaData',enterpriseMetaDataSchema);

export const EnterpriseKeyModel = mongoose.model('EnterpriseKey',enterpriseKeySchema);