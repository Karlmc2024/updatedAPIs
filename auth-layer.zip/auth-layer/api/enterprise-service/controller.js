import cacheData from "@lib/utils/cache";
import errorHandler from "../../lib/utils/error";
import { getS3Obj } from "@lib/utils/upload";
import { UserModel } from "@api/enterprise-user/model";
import { sendEjsEmail } from "@lib/utils/email";
import { pusher } from "@lib/utils/pusher/pusher-util";
const { v4: uuidv4 } = require("uuid");
const { registration } = require("../enterprise-user/controller");
const {
  EnterpriseModel,
  EnterpriseMetaDataModel,
  EnterpriseKeyModel,
} = require("./model");
const path = require("path");
const ejs = require("ejs");
const fs = require("fs");
const objectID = require("mongodb").ObjectID;
const STATUS_CONST = require("./status");

const fetch = require("node-fetch");
export const createEnterprise = async (req, res, next) => {
  try {
    const email = req.body.email;
    let result = {};
    req.isSuperAdmin =
      email.includes("iotric.com") || email.includes("nexbloc.com");
    if (!req.isSuperAdmin) {
      // if the signup email do not have nexbloc.com then only create new enterprise otherwise just create 'SUPER_ADMIN' user
      if (!req.body.organizationName) {
        const error = new Error("Please provide your organization Name");
        return errorHandler(error, 400, res);
      }
      const enterpriseBody = {
        organizationName: req.body.organizationName,
        completionIndicator: { registration: true },
        onboardingStatus: "SignedUp",
      };
      const isOrganizationExist = await EnterpriseModel.findOne({
        organizationName: {
          $regex: enterpriseBody.organizationName,
          $options: "i",
        },
      });
      if (isOrganizationExist) {
        const error = new Error(
          `Enterprise already exist with this ${enterpriseBody.organizationName}`
        );
        return errorHandler(error, 400, res);
      }

      req.body.isPrimaryAdmin = true;
      //keep enterprise Id same in both user and enterprise without saving enterprise before user
      req.body.enterpriseId = new objectID();
      enterpriseBody._id = req.body.enterpriseId;
      req.body.enterpriseBody = enterpriseBody;
    } else {
      req.body.isSuperAdmin = true;
    }
    const user = await registration(req, res, next);
    if (!user) {
      const error = new Error(
        "User already exist with given email.Please Use New One"
      );
      return errorHandler(error, 400, res);
    }
    if (user.isPrimaryAdmin) {
      const enterprise = await EnterpriseModel.create(req.body.enterpriseBody);
      result.enterprise = enterprise;
      //send event for status update
      const pusherEventObj = {
        toUserIds: user._id,
      };
      pusher.trigger(
        `Nexbloc-sdk-${user.enterpriseId}`,
        "status-update",
        pusherEventObj
      );
    }

    result.user = user;
    return res.status(200).json({ result });
  } catch (error) {
    console.log(error);
    return errorHandler(error, 400, res);
  }
};

export const getEnterprise = async (req, res, next) => {
  try {
    const id = req.params.id;
    if (!id) {
      const error = new Error("Please provide id");
      return errorHandler(error, 400, res);
    }
    const enterprise = await EnterpriseModel.findById(id);
    if (!enterprise) {
      const error = new Error(`NO enterprise exist with this ${id} id`);
      return errorHandler(error, 400, res);
    }
    return res.status(200).json({ result: enterprise });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};
export const createEnterpriseProfile = async (req, res, next) => {
  try {
    const id = req.params.enterpriseId;
    if (!id) {
      const error = new Error("Please provide id");
      return errorHandler(error, 400, res);
    }
    const enterprise = await EnterpriseModel.findById(id);
    if (!enterprise.completionIndicator.registration) {
      const error = new Error("Please complete registration first");
      return errorHandler(error, 400, res);
    }
    enterprise.brandLogo = req.body.brandLogo;
    enterprise.brandText = req.body.brandText;
    enterprise.description = req.body.description;
    enterprise.favicon = req.body.favicon;
    enterprise.themePrimaryColor = req.body.themePrimaryColor;
    enterprise.themeSecondaryColor = req.body.themeSecondaryColor;
    enterprise.homepageH1Title = req.body.homepageH1Title;
    enterprise.industryType = req.body.industryType;
    enterprise.completionIndicator.profileForm = true;
    await enterprise.save();
    return res.status(200).json({ result: enterprise });
  } catch (err) {
    console.log(err);
  }
};

export const updateEnterprise = async (req, res, next) => {
  try {
    const id = req.params.id;
    if (!id) {
      const error = new Error("Please provide id");
      return errorHandler(error, 400, res);
    }
    const updatedEnterprise = await EnterpriseModel.findByIdAndUpdate(
      id,
      req.body,
      { new: true }
    );
    return res.status(200).json({ result: updatedEnterprise });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

export const createEnterpriseMetaData = async (req, res, next) => {
  try {
    const enterpriseId = req.params.enterpriseId;
    if (!enterpriseId) {
      const error = new Error("Please provide id");
      return errorHandler(error, 400, res);
    }
    const enterprise = await EnterpriseModel.findById(enterpriseId);
    if (!enterprise) {
      const error = new Error("No such enterprise exist");
      return errorHandler(error, 400, res);
    }
    if (!enterprise.completionIndicator.registration) {
      const error = new Error("Please complete your enterprise profile first");
      return errorHandler(error, 400, res);
    }
    const enterpriseMetadataObj = { ...req.body, enterpriseId };
    const enterpriseMetaData = await EnterpriseMetaDataModel.create(
      enterpriseMetadataObj
    );
    enterprise.completionIndicator.metaInfoForm = true;
    enterprise.onboardingStatus = "Paid"; // 'OnboardingSubmission' AutoApprove TODO
    //update profileCompletion Indicator
    await enterprise.save();
    // find primary Admin and send status update event to him
    const primaryAdmin = await UserModel.findOne({
      enterpriseId,
      isPrimaryAdmin: true,
    });
    const pusherEventObj = {
      toUserIds: primaryAdmin._id,
    };
    pusher.trigger(
      `Nexbloc-sdk-${enterpriseId}`,
      "status-update",
      pusherEventObj
    );
    fetch(
      `http://localhost:8000/api/enterprise/${enterpriseId}/spin-portal-local`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      }
    );
    return res.status(200).json({ result: enterpriseMetaData });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

export const getEnterpriseMetaData = async (req, res, next) => {
  try {
    const enterpriseId = req.params.enterpriseId;
    if (!enterpriseId) {
      const error = new Error("Please provide id");
      return errorHandler(error, 400, res);
    }
    const enterpriseMetaData = await EnterpriseMetaDataModel.findOne({
      enterpriseId,
    });
    if (!enterpriseMetaData) {
      const error = new Error(
        "No meta exist for this enterprise. Please add One"
      );
      return errorHandler(error, 400, res);
    }
    return res.status(200).json({
      result: enterpriseMetaData,
    });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

export const updateEnterpriseMetaData = async (req, res, next) => {
  try {
    const enterpriseId = req.params.enterpriseId;

    if (!enterpriseId) {
      const error = new Error("Please provide id");
      return errorHandler(error, 400, res);
    }
    const metaDataBody = { ...req.body };

    const socialMedia = metaDataBody.socialMedia;

    delete metaDataBody.socialMedia;
    //update only the field that we got in socialMedia not entire social Media
    const updatedMetaData = await EnterpriseMetaDataModel.findOneAndUpdate(
      { enterpriseId },
      {
        $set: {
          ...metaDataBody,
          "socialMedia.linkedin": socialMedia.linkedin,
          "socialMedia.twitter": socialMedia.twitter,
          "socialMedia.facebook": socialMedia.facebook,
          "socialMedia.instagram": socialMedia.instagram,
        },
      },
      { new: true }
    );

    if (!updatedMetaData) {
      const error = new Error(
        "No meta exist for this enterprise. Please add One"
      );
      return errorHandler(error, 400, res);
    }
    return res.status(200).json({ result: updatedMetaData });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

export const createEnterpriseApiKey = async (req, res, next) => {
  try {
    const enterpriseId = req.params.enterpriseId;
    const enterprise = await EnterpriseModel.findById(enterpriseId);
    const isProfileCompleted = enterprise.completionIndicator;

    if (
      !isProfileCompleted.profileForm ||
      !isProfileCompleted.metaInfoForm ||
      !isProfileCompleted.registration
    ) {
      return errorHandler(
        { error: "Please complete your profile first" },
        400,
        res
      );
    }
    const keyType = req.query.type || "test";
    //set all the existing active key for enterprise to false
    await EnterpriseKeyModel.updateMany(
      { enterpriseId, active: true, type: keyType },
      { $set: { active: false } }
    );
    //generate test key and live key
    const key =
      keyType === "test" ? `Nxb-test-${uuidv4()}` : `Nxb-live-${uuidv4()}`;
    //before saving to database encrypt the keys using pre-save middleware
    const keyDoc = await EnterpriseKeyModel.create({
      key,
      enterpriseId,
      type: keyType,
      active: true,
    });
    keyDoc.decryptApiKey();
    return res.status(200).json({ result: keyDoc });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};
export const getActiveEnterpriseApiKey = async (req, res, next) => {
  try {
    const enterpriseId = req.params.enterpriseId;
    const keys = await EnterpriseKeyModel.find({
      enterpriseId,
      active: true,
    }).sort("-createdAt");
    if (keys.length <= 0) {
      const error = new Error(
        "No active Api key exist for this enterprise.Please create one"
      );
      return errorHandler(error, 400, res);
    }
    //mongoose instance method defined in schema
    keys.forEach((element) => element.decryptApiKey());
    return res.status(200).json({ result: keys });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

export const getKeysByEnterprise = async (req, res, next) => {
  try {
    const enterpriseId = req.params.enterpriseId;
    const allKeys = await EnterpriseKeyModel.find({ enterpriseId }).sort(
      "-createdAt"
    );
    if (allKeys.length < 0) {
      const error = new Error(
        "No Api key exist for this enterprise.Please create one"
      );
      return errorHandler(error, 400, res);
    }
    //decrypting all the keys
    allKeys.forEach((element) => element.decryptApiKey());
    return res.status(200).json({ result: allKeys });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

export const softDeleteKey = async (req, res, next) => {
  try {
    const keyId = req.params.keyId;
    if (!keyId) {
      const error = new Error("Please provide key id");
      return errorHandler(error, 400, res);
    }
    if (req.me.role !== "ADMIN") {
      const error = new Error("You dont have access to perform this operation");
      return errorHandler(error, 400, res);
    }
    const keyDelete = await EnterpriseKeyModel.findByIdAndUpdate(keyId, {
      active: false,
    });
    res.status(200).json({ message: "key deleted successfully" });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

export const isEnterpriseMinted = async (req, res, next) => {
  try {
    const metaDataId = req.params.id;
    const metaData = await EnterpriseMetaDataModel.findById(
      metaDataId
    ).populate("enterpriseId");
    const enterprise = metaData.enterpriseId;
    const isProfileCompleted = [
      enterprise.completionIndicator.registration,
      enterprise.completionIndicator.profileForm,
      enterprise.completionIndicator.metaInfoForm,
    ];
    if (isProfileCompleted.includes(false)) {
      const error = new Error(
        "Please complete your profile before performing this step"
      );
      return errorHandler(error, 400, res);
    }

    //make call to blockchain and if it gives us status then update that in enterprise  - test promise for now
    const statusPromise = await new Promise((resolve, reject) => {
      const randomNum = Math.random();
      if (randomNum >= 0.5) {
        resolve({ status: "success" });
      }
      reject({ status: "failed" });
    });
    //using then instead of await as this request takes time so for serving response
    if (statusPromise.status === "success") {
      await EnterpriseModel.findByIdAndUpdate(enterprise._id, {
        completionIndicator: {
          registration: true,
          profileForm: true,
          metaInfoForm: true,
          isMinted: true,
        },
      });
    } else {
      return res.status(200).json({
        message:
          "Your enterprise is not published to chain.Please wait or mail us your concern at support@nexbloc.com",
      });
    }
    return res.status(200).json({
      message:
        "Your profile is submitted.We will inform you as soon as you are live on blocckhain",
    });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

export const getPrimaryAdminOfEnterprise = async (req, res, next) => {
  try {
    const enterpriseId = req.params.enterpriseId;
    if (!enterpriseId) {
      const error = new Error("Please provide enterpriseId");
      return errorHandler(error, 400, res);
    }
    const primaryAdmin = await UserModel.findOne({
      enterpriseId,
      isPrimaryAdmin: true,
    }).populate({
      path: "enterpriseId",
      select: "onboardingStatus organizationName",
    });
    if (!primaryAdmin) {
      const error = new Error("No user exist for the enterprise");
      return errorHandler(error, 400, res);
    }
    return res.status(200).json({ result: primaryAdmin });
  } catch (err) {
    return errorHandler(err, 400, res);
  }
};

export const updateCacheDataByEnterprise = async (req, res, next) => {
  try {
    const enterpriseId = req.params.enterpriseId;
    if (!enterpriseId) {
      const error = new Error("Please provide enterprise Id");
      return errorHandler(error, 400, res);
    }
    const selectHiddenFields = [
      "orderLimit",
      "SPARKPOST_API_KEY",
      "HUBSPOT_API_KEY",
      "STRIPE_SECRET_KEY",
      "S3_region",
      "S3_bucket",
      "XDC_PRIVATE_KEY",
      "XDC_REGISTRAR_CONTRACT_ADDRESS",
    ];
    const enterprise = await EnterpriseModel.findById(enterpriseId)
      .select(selectHiddenFields)
      .populate({
        path: "keys",
        sort: "-createdAt",
      });
    if (!enterprise) {
      const error = new Error("No such enterprise exist");
      return errorHandler(error, 400, res);
    }
    enterprise.keys.forEach((key) => key.decryptApiKey());
    const updateCacheDataBody = {
      _id: enterpriseId,
      keys: enterprise.keys,
      orderlimit: enterprise.orderlimit,
      sparkpost_api_key: enterprise.sparkpost_api_key,
      hubspot_api_key: enterprise.hubspot_api_key,
      stripe_secret_key: enterprise.stripe_secret_key,
      s3_region: enterprise.s3_region,
      s3_bucket: enterprise.s3_bucket,
      xdc_private_key: enterprise.xdc_private_key,
      xdc_registrar_contract_address: enterprise.xdc_registrar_contract_address,
    };
    const updatedCacheData = await cacheData.put(
      enterprise.organizationName,
      updateCacheDataBody
    );
    return res.status(200).json({ result: updatedCacheData });
  } catch (err) {
    return errorHandler(err, 400, res);
  }
};

export const updateSpinupStatus = async (req, res) => {
  try {
    const { enterpriseId } = req.params;
    const { status } = req.body;
    if (!enterpriseId || !status) {
      const error = new Error("EnterpriseId and status is required");
      return errorHandler(error, 400, res);
    }
    const updatedEnterprise = await EnterpriseModel.findByIdAndUpdate(
      enterpriseId,
      { spinUpStatus: status },
      { new: true }
    );
    if (!updatedEnterprise) {
      const error = new Error("No such enterprise exist");
      return errorHandler(error, 400, res);
    }
    return res.status(200).json({ result: updatedEnterprise });
  } catch (err) {
    console.log(err);
    return errorHandler(err, 400, res);
  }
};

export const updateOnboardingStatusOfEnterprise = async (req, res, next) => {
  try {
    const { enterpriseId } = req.params;
    const { status } = req.body;
    if (!enterpriseId || !status) {
      const error = new Error("EnterpriseId and status is required");
      return errorHandler(error, 400, res);
    }
    const updatedEnterprise = await EnterpriseModel.findByIdAndUpdate(
      enterpriseId,
      { onboardingStatus: status },
      { new: true }
    );
    if (!updatedEnterprise) {
      const error = new Error("No such enterprise exist");
      return errorHandler(error, 400, res);
    }

    const primaryAdmin = await UserModel.findOne({
      isPrimaryAdmin: true,
      enterpriseId,
    });

    const pusherEventObj = {
      toUserIds: primaryAdmin._id,
      fromEmail: "contact@nexbloc.com",
      fromName: `${primaryAdmin.firstName} ${primaryAdmin.lastName}`,
    };

    pusher.trigger(
      `Nexbloc-sdk-${enterpriseId}`,
      "status-update",
      pusherEventObj
    );

    let filePath = path.resolve(
      __dirname + "../../../lib/utils/templates/app-status.ejs"
    );
    const compiled = ejs.compile(fs.readFileSync(filePath, "utf8"));

    const dataToCompile = {
      name: primaryAdmin.firstName + " " + primaryAdmin.lastName,
      status: status,
      org: updatedEnterprise.organizationName,
    };
    const Subject = `Status Update`;

    sendEjsEmail(
      primaryAdmin.email,
      primaryAdmin.firstName + " " + primaryAdmin.lastName,
      Subject,
      compiled(dataToCompile)
    );
    //sending email for all status update to primary admin
    return res.status(200).json({ result: updatedEnterprise });
  } catch (err) {
    console.log(err);
    return errorHandler(err, 400, res);
  }
};

// this is post setup(after db and portal is spinned) api for an enterprise to create copy of primary admin on respective database and send app live email to primary admin

export const sendAppLiveMail = async (req, res, next) => {
  try {
    if (!req.params.enterpriseId) {
      const error = new Error("enterprise id is required");
      return errorHandler(error, 400, res);
    }
    const domainLink = req.body.domain;
    const enterprise = await EnterpriseModel.findById(req.params.enterpriseId);
    if (!enterprise) {
      const error = new Error("No such enterprise exist");
      return errorHandler(error, 400, res);
    }
    const primaryAdmin = await UserModel.findOne({
      isPrimaryAdmin: true,
      enterpriseId: req.params._id,
    });

    //create copy of this user on service layer
    const requestConfig = {
      method: req.method.toLowerCase(),
      body: JSON.stringify(primaryAdmin),
      headers: {
        "content-type": "application/json",
        authorization:
          "Bearer " + generateServiceLayerTokens({ service: "SERVICE_LAYER" }),
        dbName: enterprise._id,
      },
    };

    const userCopyPromise = await fetch(
      "http://127.0.0.1:9000/api/signup",
      requestConfig
    );

    if (userCopyPromise.statusText !== "Created") {
      const error = new Error("Something went wrong");
      return errorHandler(error, 400, res);
    }

    // if admin copy successfully created then only send app live email
    let filePath = path.resolve(
      __dirname + "../../../lib/utils/templates/app-live.ejs"
    );
    const compiled = ejs.compile(fs.readFileSync(filePath, "utf8")),
      dataToCompile = {
        name: primaryAdmin.firstName + " " + primaryAdmin.lastName,
        domain: domainLink,
      },
      Subject = `APP LIVE ON NEXBLOC`;

    sendEjsEmail(
      primaryAdmin.email,
      primaryAdmin.firstName + " " + primaryAdmin.lastName,
      Subject,
      compiled(dataToCompile)
    );
    return res.status(200).json({ message: "Email Sent Successfully" });
  } catch (error) {
    return errorHandler(error, 400, res);
  }
};

export const getAllEnterprise = async (req, res, next) => {
  try {
    const enterprises = await EnterpriseModel.find().sort({ _id: -1 });
    return res.status(200).json({
      result: enterprises,
    });
  } catch (err) {
    return errorHandler(err, 400, res);
  }
};

export const chooseCurrentOrganization = async (req, res, next) => {
  try {
    const organizationId = req.body.enterpriseId;
    if (!organizationId) {
      const error = new Error("Please Provide Enterprise Id");
      return errorHandler(error, 400, res);
    }
    const updateUser = await UserModel.findByIdAndUpdate(
      req.me._id,
      {
        currentOrganization: organizationId,
      },
      { new: true }
    );
    return res.status(200).json({
      result: updateUser,
    });
  } catch (err) {
    return errorHandler(err, 400, res);
  }
};

//this api will set onboarding of status of an enterpise to Approved
export const setOSToApprove = async (req, res, next) => {
  try {
    const enterpriseId = req.params.enterpriseId;
    if (!enterpriseId) {
      const error = new Error("Please Provide EnterpriseId");
      return errorHandler(error, 400, res);
    }
    const updatedEnterprise = await EnterpriseModel.findByIdAndUpdate(
      enterpriseId,
      { onboardingStatus: "Approved" },
      { new: true }
    );

    const primaryAdmin = await UserModel.findOne({
      isPrimaryAdmin: true,
      enterpriseId,
    });
    console.log(primaryAdmin);

    let filePath = path.resolve(
      __dirname + "../../../lib/utils/templates/app-status.ejs"
    );
    const compiled = ejs.compile(fs.readFileSync(filePath, "utf8"));

    const dataToCompile = {
      name: primaryAdmin.firstName + " " + primaryAdmin.lastName,
      status: STATUS_CONST.Approved,
      org: updatedEnterprise.organizationName,
    };

    sendEjsEmail(
      primaryAdmin.email,
      primaryAdmin.firstName + " " + primaryAdmin.lastName,
      "Status Update",
      compiled(dataToCompile)
    );
    //setting up trigger pusher event
    const pusherEventObj = {
      toUserIds: primaryAdmin._id,
      fromEmail: req.me.email,
      fromName: `${req.me.firstName} ${req.me.lastName}`,
    };
    pusher.trigger(
      `Nexbloc-sdk-${enterpriseId}`,
      "status-update",
      pusherEventObj
    );
    return res.status(200).json({ result: updatedEnterprise });
  } catch (err) {
    console.log(err);
    return errorHandler(err, 400, res);
  }
};
//this api will set onboarding status of an enteprise to ApproveToPay
export const setOSToApproveToPay = async (req, res, next) => {
  try {
    const enterpriseId = req.params.enterpriseId;
    if (!enterpriseId) {
      const error = new Error("Please Provide EnterpriseId");
      return errorHandler(error, 400, res);
    }
    const updatedEnterprise = await EnterpriseModel.findByIdAndUpdate(
      enterpriseId,
      { onboardingStatus: "ApprovedToPay" },
      { new: true }
    );

    const primaryAdmin = await UserModel.findOne({
      isPrimaryAdmin: true,
      enterpriseId,
    });

    let filePath = path.resolve(
      __dirname + "../../../lib/utils/templates/approved-to-pay.ejs"
    );
    const compiled = ejs.compile(fs.readFileSync(filePath, "utf8"));

    const dataToCompile = {
      name: primaryAdmin.firstName + " " + primaryAdmin.lastName,
      status: STATUS_CONST.ApprovedToPay,
      org: updatedEnterprise.organizationName,
      price: req.body.price + "",
    };

    sendEjsEmail(
      primaryAdmin.email,
      primaryAdmin.firstName + " " + primaryAdmin.lastName,
      "Status Update",
      compiled(dataToCompile)
    );
    //setting up trigger pusher event
    const pusherEventObj = {
      toUserIds: primaryAdmin._id,
      fromEmail: req.me.email,
      fromName: `${req.me.firstName} ${req.me.lastName}`,
    };
    pusher.trigger(
      `Nexbloc-sdk-${enterpriseId}`,
      "status-update",
      pusherEventObj
    );
    return res.status(200).json({ result: updatedEnterprise });
  } catch (err) {
    console.log(err);
    return errorHandler(err, 400, res);
  }
};

//this api will set onboarding status of an enterprise to SettingUp
export const spinUpAnEnteprise = async (req, res, next) => {
  try {
    const enterpriseId = req.params.enterpriseId;

    if (!enterpriseId) {
      const error = new Error("Please Provide EnterpriseId");
      return errorHandler(error, 400, res);
    }

    const enterpriseMetaData = await EnterpriseMetaDataModel.findOne({
      enterpriseId,
    }).populate("enterpriseId");

    if (!enterpriseMetaData) {
      const error = new Error("Please Create Meta Data first");
      return errorHandler(error, 400, res);
    }

    const enterprise = enterpriseMetaData.enterpriseId;

    if (enterprise.onboardingStatus !== "Paid") {
      const error = new Error("Please Complete Your Payment first");
      return errorHandler(error, 400, res);
    }
    const user = await UserModel.findOne({
      isPrimaryAdmin: true,
      enterpriseId,
    });
    const sendDataForConfig = {};
    if (enterprise.brandLogo) {
      const brandLogoS3ObjParams = {
        Bucket: process.env.S3_bucket,
        Key: decodeURIComponent(enterprise.brandLogo.split("aws.com/")[1]),
      };
      let image = await getS3Obj(brandLogoS3ObjParams);
      sendDataForConfig.logo = Buffer.from(image.Body).toString("base64");
    }
    if (enterprise.favicon) {
      const faviconS3ObjParams = {
        Bucket: process.env.S3_bucket,
        Key: decodeURIComponent(enterprise.favicon.split("aws.com/")[1]),
      };
      let image = await getS3Obj(faviconS3ObjParams);
      sendDataForConfig.favicon = Buffer.from(image.Body).toString("base64");
    }
    sendDataForConfig._id = enterpriseId;
    sendDataForConfig.orgName = enterprise.organizationName;
    sendDataForConfig.primaryColor = enterprise.themePrimaryColor;
    sendDataForConfig.secondaryColor = enterprise.themeSecondaryColor;
    sendDataForConfig.tlds = enterpriseMetaData.tlds;
    sendDataForConfig.brandText = enterprise.brandText;
    sendDataForConfig.homepageH1Title = enterprise.homepageH1Title;
    sendDataForConfig.domain = [`${enterprise.organizationName}.nexbloc.com`];
    sendDataForConfig.email = user.email;
    sendDataForConfig.socialMedia = enterpriseMetaData.socialMedia;
    sendDataForConfig.componentsToEnable = enterpriseMetaData.componentsEnabled;
    sendDataForConfig.chainSupport = enterpriseMetaData.chainSupport;
    sendDataForConfig.landingPageTemplate =
      enterpriseMetaData.landingPageTemplate;
    console.log(sendDataForConfig);
    const configRespPromise = await fetch("http://127.0.0.1:8088/", {
      method: "POST",
      body: JSON.stringify(sendDataForConfig),
      headers: { "Content-Type": "application/json" },
    });

    // updating enterprise onboarding Status to ----SettingUp----
    enterprise.onboardingStatus = "SettingUp";
    //setting up trigger pusher event
    const primaryAdmin = await UserModel.findOne({
      enterpriseId,
      isPrimaryAdmin: true,
    });
    //sending pusher event for paid
    const pusherEventObj = {
      toUserIds: primaryAdmin._id,
      fromEmail: "support@nexbloc.com",
      fromName: `Dana Farbo`,
    };
    pusher.trigger(
      `Nexbloc-sdk-${enterpriseId}`,
      "status-update",
      pusherEventObj
    );
    return res.status(200).json({
      message: "Portal Spinned Successfuly",
    });
  } catch (err) {
    return errorHandler(err, 400, res);
  }
};

export const markPaidOffline = async (req, res, next) => {
  try {
    const enterpriseId = req.params.enterpriseId;
    if (!enterpriseId) {
      const error = new Error("Please Provide EnterpriseId");
      return errorHandler(error, 400, res);
    }
    const updateEnterprise = await EnterpriseModel.findByIdAndUpdate(
      enterpriseId,
      { onboardingStatus: "Paid" },
      { new: true }
    );
    if (!updateEnterprise) {
      const error = new Error("update enterprise failed");
      return errorHandler(error, 400, res);
    }
    const primaryAdmin = await UserModel.findOne({
      enterpriseId,
      isPrimaryAdmin: true,
    });
    //sending pusher event for paid
    const pusherEventObj = {
      toUserIds: primaryAdmin._id,
      fromEmail: req.me.email,
      fromName: `${req.me.firstName} ${req.me.lastName}`,
    };
    pusher.trigger(
      `Nexbloc-sdk-${enterpriseId}`,
      "status-update",
      pusherEventObj
    );
    return res.status(200).json({ result: updateEnterprise });
  } catch (err) {
    console.log(err);
    return errorHandler(error, 400, res);
  }
};

export const setupPaymentDetails = async (req, res, next) => {
  try {
    const enterpriseId = req.params.enterpriseId;
    if (!enterpriseId) {
      const error = new Error("Enterprise Id is required");
      return errorHandler(error, 400, res);
    }
    if (
      req.me.enterpriseId != enterpriseId ||
      req.me.isPrimaryAdmin === false
    ) {
      const error = new Error("you do not have permission to this service");
      return errorHandler(error, 400, res);
    }
    const body = { ...req.body };
    body.sparkpost_api_key = body.sparkpost_api_key || "";
    body.hubspot_api_key = body.hubspot_api_key || "";
    body.stripe_secret_key = body.stripe_secret_key || "";
    body.xdc_private_key = body.xdc_private_key || "";
    body.xdc_registrar_contract_address =
      body.xdc_registrar_contract_address || "";

    const updatedProfile = await EnterpriseModel.findByIdAndUpdate(
      enterpriseId,
      body,
      { new: true }
    );

    if (!updatedProfile) {
      const error = new Error("Payment Setup Operation failed");
      return errorHandler(error, 400, res);
    }
    //send mail to primary admin for payment details

    return res
      .status(200)
      .json({ result: { message: "Payment Details Added successfully" } });
  } catch (err) {}
};

export const updatePortalFrontendLooks = async (req, res, next) => {
  try {
    const enterpriseId = req.params.enterpriseId;

    if (!enterpriseId) {
      const error = new Error("Enterprise Id is required");
      return errorHandler(error, 400, res);
    }

    const enterpriseProfileKeys = [
      "brandLogo",
      "favicon",
      "brandText",
      "contactEmail",
      "themePrimaryColor",
      "themeSecondaryColor",
      "heroImage",
      "backgroundColor",
      "homepageH1Title",
      "navbarColor",
    ];

    const enterpriseMetaDataKeys = ["socialMedia", "domainLimit"];

    let enterpriseProfileBody = {};
    let enterpriseMetadataBody = {};
    //creating body for profile and metadata separately by filtering out from req.body
    for (let key in req.body) {
      if (enterpriseProfileKeys.includes(key)) {
        enterpriseProfileBody[key] = req.body[key];
      } else if (enterpriseMetaDataKeys.includes(key)) {
        enterpriseMetadataBody[key] = req.body[key];
      }
    }

    let updatedMetaData;
    //logo,favicon,primaryColor,secondaryColor,brandText,contactEmail,heroimage,backgroundColor(profile)

    //social media ( metadata)

    if (enterpriseMetadataBody.socialMedia) {
      const socialMedia = enterpriseMetadataBody.socialMedia;

      delete enterpriseMetadataBody.socialMedia;
      //update only the field that we got in socialMedia not entire social Media
      updatedMetaData = await EnterpriseMetaDataModel.findOneAndUpdate(
        { enterpriseId },
        {
          $set: {
            ...enterpriseMetadataBody,
            "socialMedia.linkedin": socialMedia.linkedin,
            "socialMedia.twitter": socialMedia.twitter,
            "socialMedia.facebook": socialMedia.facebook,
            "socialMedia.instagram": socialMedia.instagram,
          },
        },
        { new: true }
      );
    }

    const enterprise = await EnterpriseModel.findByIdAndUpdate(
      enterpriseId,
      enterpriseProfileBody,
      { new: true }
    );
    const sendDataToProvisioner = {};

    //converting logo,favicon and heroImage to buffer to sent to provisioner server
    if (req.body.logo) {
      const brandLogoS3ObjParams = {
        Bucket: process.env.S3_bucket,
        Key: decodeURIComponent(enterprise.brandLogo.split("aws.com/")[1]),
      };
      let image = await getS3Obj(brandLogoS3ObjParams);
      sendDataToProvisioner.logo = Buffer.from(image.Body).toString("base64");
    }
    if (req.body.favicon) {
      const faviconS3ObjParams = {
        Bucket: process.env.S3_bucket,
        Key: decodeURIComponent(enterprise.favicon.split("aws.com/")[1]),
      };
      let image = await getS3Obj(faviconS3ObjParams);
      sendDataToProvisioner.favicon = Buffer.from(image.Body).toString(
        "base64"
      );
    }
    if (req.body.heroImage) {
      const heroImageS3ObjParams = {
        Bucket: process.env.S3_bucket,
        Key: decodeURIComponent(enterprise.heroImage.split("aws.com/")[1]),
      };
      let image = await getS3Obj(heroImageS3ObjParams);
      sendDataToProvisioner.heroImage = Buffer.from(image.Body).toString(
        "base64"
      );
    }

    sendDataToProvisioner.primaryColor = req.body.themePrimaryColor;
    sendDataToProvisioner.secondaryColor = req.body.themeSecondaryColor;
    sendDataToProvisioner.title = req.body.homepageH1Title;
    sendDataToProvisioner.brandText = req.body.brandText;
    sendDataToProvisioner.heroImage = req.body.heroImage;
    sendDataToProvisioner.backgroundColor = req.body.backgroundColor;
    sendDataToProvisioner.contactEmail = req.body.contactEmail;
    sendDataToProvisioner.socialMedia =
      updatedMetaData && updatedMetaData.socialMedia;
    sendDataToProvisioner.navbarColor = req.body.navbarColor;
    console.log(sendDataToProvisioner.navbarColor);

    //send data to provisioner server for updating on cloudfare
    const configRespPromise = await fetch("http://127.0.0.1:8088/", {
      method: "POST",
      body: JSON.stringify(sendDataToProvisioner),
      headers: { "Content-Type": "application/json" },
    });

    return res.status(200).json({
      result: { message: "Data updated successfully" },
    });
  } catch (err) {
    return errorHandler(err, 400, res);
  }
};

export const searchTLDAvailable = async (req, res) => {
  const { tld } = req.query;
  const tldAvailable = await EnterpriseMetaDataModel.findOne({
    tlds: tld,
  });
  if (tldAvailable) {
    return res.status(200).json({ result: { available: false } });
  } else {
    return res.status(200).json({ result: { available: true } });
  }
};
