module.exports = {
    'Approved':'Approved',
    'ApprovedToPay':'Approved To Pay',
    'SpinedUp':"Spinned Up",
    'Complete':"Complete",
    "Paid":"Paid",
    "AddedbyAdmin":"Added By Admin",
    "SignedUp":"Signed Up",
    "SettingUp":"Setting Up",
    "Complete":"Complete"
}