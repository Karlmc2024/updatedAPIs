
const Joi = require('@hapi/joi');
export const validateEnterpriseSignUp = (req, res, next) => {
    
    const schema = Joi.object({
        organizationName:Joi.string().optional(),
        password: Joi.string().pattern(/(?=^.{6,64}$)(?=.*\d)(?!.*\s).*$/).required(),
        email: Joi.string().pattern(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/).required(),
        referBy : Joi.string().allow(null).optional(),
        firstName: Joi.string().required(),
        lastName: Joi.string().required(),
        fromSSO: Joi.string(),
        twoFA:Joi.optional(),
    });
    let {error} = schema.validate(req.body);
    if (error && error.details) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        return res.status(400).json({error:message});
    }
   next();
};

export const createEnterpriseProfileValidator = async(req,res,next) => {
    if(req.body.industryType){
        req.body.industryType = JSON.parse(req.body.industryType)
    }
    const schema = Joi.object({
       
        brandText : Joi.string().optional(),
        brandLogo :Joi.string().optional(),
        favicon : Joi.string().optional(),
        homepageH1Title:Joi.string().optional(),
        themePrimaryColor:Joi.string().optional(),
        themeSecondaryColor:Joi.string().optional(),
        platformName:Joi.string().optional(),
        description:Joi.string().optional(),
        industryType:Joi.object()


    });
    let {error} = schema.validate(req.body)
    if (error && error.details) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        return res.status(400).json({error:message});
    }
    
    if(req.body.themePrimaryColor){
        // if themeColor not starts with # or length is not 7 ie #616161 color check fail
        const hexCodeCheckFail = !req.body.themePrimaryColor.startsWith('#') || req.body.themePrimaryColor.length !==7
        if(hexCodeCheckFail){
            const message = "Only HexCode color format is allowed for primaryColor"
            return res.status(400).json({error:message})
        }
    }
    if(req.body.themeSecondaryColor){
        const hexCodeCheckFail = !req.body.themeSecondaryColor.startsWith('#') || req.body.themeSecondaryColor.length !==7
        if(hexCodeCheckFail){
            const message = "Only HexCode color format is allowed for secondaryColor"
            return res.status(400).json({error:message})
        }
    }
    next()
}

export const validateEnterpriseMetaData = (req, res, next) => {
    const schema = Joi.object({
        restrictedSignup:Joi.boolean().optional(),
        allowedEmailType:Joi.array().items( Joi.string().regex(/^[@][a-z]+\.[a-z]+$/)).optional(),
        domainLimit:Joi.number().optional(),
        socialMedia:Joi.object({linkedin:Joi.string().optional(),twitter:Joi.string().optional(),facebook:Joi.string().optional(),instagram:Joi.string().optional()}),
        tlds:Joi.array().items(Joi.string()).required(),
        additionalInfo:Joi.array().items({
            label:Joi.string().optional(),
            key:Joi.string().optional(),
            type:Joi.string().optional()
        }).optional(),
        componentsEnabled:Joi.object().optional(),
        chainSupport:Joi.string().optional(),
        landingPageTemplate:Joi.object().optional()

    });
    let {error} = schema.validate(req.body);
    if (error && error.details) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        return res.status(400).json({error:message});
    }
    if(req.body.tlds.length >0){
       const isTldValidationWrong = req.body.tlds.some(element => {
         // if any element that not starts with dot(.) or have more than one dot then there will be true in above variable
         return (element.startsWith('.')!= true || (element.split('.').length>2))
       })
       
       if(isTldValidationWrong){
        const message = "each tlds should starts with dot and have more than dot for each"
        return res.status(400).json({error:message})
       }
    }
next();
};



export const validateAdminRegistration = (req, res, next) => {
    const schema = Joi.object({
        password: Joi.string().pattern(/(?=^.{6,64}$)(?=.*\d)(?!.*\s).*$/).required(),
        email: Joi.string().pattern(/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/).required(),
        firstName: Joi.string().required(),
        lastName: Joi.string().required(),
        fromSSO: Joi.string(),
        twoFA:Joi.optional()
    });
    let {error} = schema.validate(req.body);
    if (error && error.details) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        return res.status(400).json({error:message});
    }
next();
}



export const updateOnboardingStatusValidate = (req, res, next) => {
    
    const schema = Joi.object({
        status:Joi.string().required(),
        
    });
    let {error} = schema.validate(req.body);
    if (error && error.details) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        return res.status(400).json({error:message});
    }
   next();
};


export const approveToPayValidate = (req, res, next) => {
    
    const schema = Joi.object({
        price:Joi.number().required(),
        
    });
    let {error} = schema.validate(req.body);
    if (error && error.details) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        return res.status(400).json({error:message});
    }
    console.log("here")
   next();
};


export const chooseOrganizationValidate = (req, res, next) => {
    
    const schema = Joi.object({
        enterpriseId:Joi.string().required(),
        
    });
    let {error} = schema.validate(req.body);
    if (error && error.details) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        return res.status(400).json({error:message});
    }
   next();
};


export const setupPaymentDetailsValidate = (req, res, next) => {
    
    const schema = Joi.object({
        stripe_secret_key:Joi.string().required(),
        sparkpost_api_key:Joi.string().required(),
        hubspot_api_key:Joi.string().optional(),
        xdc_private_key:Joi.string().required(),
        xdc_registrar_contract_address:Joi.string().required() 
    });
    let {error} = schema.validate(req.body);
    if (error && error.details) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        return res.status(400).json({error:message});
    }
   next();
};



export const updateFrontendPortalValidate = async(req,res,next) => {
    const schema = Joi.object({
        brandLogo:Joi.string().optional(),
        favicon:Joi.string().optional(),
        heroImage:Joi.string().optional(),
        backgroundColor:Joi.string().optional(),
        themePrimaryColor:Joi.string().optional(),
        themeSecondaryColor:Joi.string().optional(),
        homepageH1Title:Joi.string().optional(),
        brandText:Joi.string().optional(),
        contactEmail:Joi.string().optional(),
        socialMedia:Joi.object().optional(),
        navbarColor:Joi.string().optional()
    });
    if(req.body.socialMedia){
        req.body.socialMedia = JSON.parse(req.body.socialMedia)
    }
    let {error} = schema.validate(req.body);
    if (error && error.details) {
        const {details} = error;
        const message = details.map(i => i.message).join(',');
        return res.status(400).json({error:message});
    }
   next();
}
