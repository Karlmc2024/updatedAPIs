const router = require("express").Router();
const {
  isAdmin,
  isProvisioner,
  isSuperAdmin,
} = require("../../middleware/auth");
const {
  logoAndFaviconUpload,
  logoFaviconAndHeroImageUpload,
} = require("../../lib/utils/upload");

const {
  createEnterprise,
  getEnterprise,
  updateEnterprise,
  createEnterpriseProfile,
  createEnterpriseMetaData,
  getEnterpriseMetaData,
  updateEnterpriseMetaData,
  createEnterpriseApiKey,
  getActiveEnterpriseApiKey,
  getKeysByEnterprise,
  softDeleteKey,
  isEnterpriseMinted,
  updateCacheDataByEnterprise,
  sendAppLiveMail,
  updateOnboardingStatusOfEnterprise,
  getAllEnterprise,
  chooseCurrentOrganization,
  setOSToApprove,
  setOSToApproveToPay,
  spinUpAnEnteprise,
  getPrimaryAdminOfEnterprise,
  markPaidOffline,
  setupPaymentDetails,
  updatePortalFrontendLooks,
  updateSpinupStatus,
  searchTLDAvailable,
} = require("./controller");

const {
  validateEnterpriseSignUp,
  validateEnterpriseMetaData,
  createEnterpriseProfileValidator,
  updateOnboardingStatusValidate,
  approveToPayValidate,
  chooseOrganizationValidate,
  setupPaymentDetailsValidate,
  updateFrontendPortalValidate,
} = require("./validator");

const UserController = require("./../enterprise-user/controller");

router.post("/create", validateEnterpriseSignUp, createEnterprise);
router.get("/list", isSuperAdmin, getAllEnterprise);
router.put("/choose", isSuperAdmin, chooseCurrentOrganization);
router.get("/:id/profile", isAdmin, getEnterprise);
//router.put('/:id',isAdmin,updateEnterprise);
router.put(
  "/:enterpriseId/profile",
  isAdmin,
  logoAndFaviconUpload,
  createEnterpriseProfileValidator,
  createEnterpriseProfile
);
router.put("/meta-data/:id/mint", isEnterpriseMinted);
router.post(
  "/:enterpriseId/meta-data",
  isAdmin,
  validateEnterpriseMetaData,
  createEnterpriseMetaData
);
router.get("/:enterpriseId/meta-data", isAdmin, getEnterpriseMetaData);
router.put("/:enterpriseId/meta-data", isAdmin, updateEnterpriseMetaData);
router.put("/:enterpriseId/generate-key", isAdmin, createEnterpriseApiKey);

router.get("/:enterpriseId/get-key", isAdmin, getActiveEnterpriseApiKey);
router.get("/:enterpriseId/key-history", isAdmin, getKeysByEnterprise);
router.delete("/:enterpriseId/delete-keys/:keyId", isAdmin, softDeleteKey);

router.post("/admin/registration", isAdmin, UserController.adminRegistration);
router.post("/admin/login", UserController.adminLogin);
router.get(
  "/:enterpriseId/primary-admin",
  isAdmin,
  getPrimaryAdminOfEnterprise
);
router.get(
  "/:enterpriseId/admins",
  isAdmin,
  UserController.getAllAdminsByEnterprise
);
router.get("/admins/:id", isAdmin, UserController.getAdminDetails);
router.delete("/admins/:id", isAdmin, UserController.deleteAdmin);
router.put(
  "/admins/:id/revoke-access",
  isAdmin,
  UserController.revokeAdminAccess
);

router.put(
  "/:enterpriseId/update-cache",
  isProvisioner,
  updateCacheDataByEnterprise
);
router.post("/:enterpriseId/app-live-email", isProvisioner, sendAppLiveMail);

router.put(
  "/:enterpriseId/onboarding-status",
  isSuperAdmin,
  updateOnboardingStatusValidate,
  updateOnboardingStatusOfEnterprise
);

router.put(
  "/:enterpriseId/update-onboarding-status",
  isProvisioner,
  updateOnboardingStatusOfEnterprise
);
router.put(
  "/:enterpriseId/update-spinup-status",
  isProvisioner,
  updateSpinupStatus
);
router.post("/:enterpriseId/status-to-approved", isSuperAdmin, setOSToApprove);
router.post(
  "/:enterpriseId/status-to-approved-to-pay",
  isSuperAdmin,
  approveToPayValidate,
  setOSToApproveToPay
);
router.post("/:enterpriseId/spin-portal", isSuperAdmin, spinUpAnEnteprise);
router.post("/:enterpriseId/spin-portal-local", spinUpAnEnteprise);
router.put("/:enterpriseId/mark-paid-offline", isSuperAdmin, markPaidOffline);

router.put(
  "/:enterpriseId/set-payment-keys",
  isAdmin,
  setupPaymentDetailsValidate,
  setupPaymentDetails
);

router.get("/search-tld", searchTLDAvailable);

// router.put('/:enterpriseId/update-portal-frontend',isAdmin,logoFaviconAndHeroImageUpload,updateFrontendPortalValidate,updatePortalFrontendLooks)

module.exports = router;
