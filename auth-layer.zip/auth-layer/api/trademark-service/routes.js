
const router = require('express').Router();
import { commonHandler } from '@api/common-service/handler';
import {addTMReqValidator} from './validator';
router.get('/',commonHandler);
router.post('/request',addTMReqValidator,commonHandler);
router.route('/request/:id').get(commonHandler).put(commonHandler).delete(commonHandler);
router.route('/request/user/:id').get(commonHandler);

module.exports = router