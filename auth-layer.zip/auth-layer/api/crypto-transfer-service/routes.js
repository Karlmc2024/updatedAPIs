import { commonHandler } from "@api/common-service/handler";

const router = require("express").Router();


router.get("/", commonHandler);
router.patch("/:id", commonHandler);
router.post("/add", commonHandler);

module.exports = router;