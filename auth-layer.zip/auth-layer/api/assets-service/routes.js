import { commonHandler } from '@api/common-service/handler';
const router = require('express').Router();
import {createAssetValidator,updateAssetValidator} from "./validator"
router.post('/domain',createAssetValidator,commonHandler)
router.get('/:assetId',commonHandler)
router.get('/domain/:domainId',commonHandler)
router.get('/type/:domainId',commonHandler)
router.put('/:assetId',updateAssetValidator,commonHandler)

module.exports = router;